package pt.isec.amov.contacts.contacts

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
