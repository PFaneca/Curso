import 'dart:io';

import 'package:contacts/model/contact_list.dart';
import 'package:contacts/ui/screens/edit_screen.dart';
import 'package:contacts/ui/screens/history_screen.dart';
import 'package:contacts/ui/screens/homepage.dart';
import 'package:contacts/ui/screens/show_screen.dart';
import 'package:contacts/ui/viewmodels/contacts_viewmodel.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';

late Directory dir;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  dir = await getApplicationDocumentsDirectory();

  final contactList = ContactList(dir);
  await contactList.readData();

  runApp(
      ChangeNotifierProvider(
        create: (context) => ContactsViewModel(contactList),
        child: const MyApp(),
      )
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Contacts App',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.lightBlueAccent),
        useMaterial3: true,
      ),
      initialRoute: MyHomePage.routeName,
      routes: {
        MyHomePage.routeName : (context) => const MyHomePage(title: 'Contacts App'),
        EditScreen.routeName : (_) => const EditScreen(),
        ShowScreen.routeName : (_) => const ShowScreen(),
        HistoryScreen.routeName : (_) => const HistoryScreen(),
      }
    );
  }
}