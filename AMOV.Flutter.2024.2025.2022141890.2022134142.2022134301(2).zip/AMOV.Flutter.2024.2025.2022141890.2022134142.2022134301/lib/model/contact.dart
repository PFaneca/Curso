
import 'dart:io';

class MeetingPoint {
  final double latitude;
  final double longitude;
  final DateTime date;

  MeetingPoint({
    required this.latitude,
    required this.longitude,
    required this.date
  });

  // JSON Util
  Map<String, dynamic> toJson() {
    return {
      'latitude': latitude,
      'longitude': longitude,
      'date': date.toIso8601String(),
    };
  }

  factory MeetingPoint.fromJson(Map<String, dynamic> json) {
    return MeetingPoint(
      latitude: json['latitude'],
      longitude: json['longitude'],
      date: DateTime.parse(json['date']),
    );
  }
}

class Contact {
  String name;
  String email;
  String phone;
  DateTime? birthday;
  File? picture;
  List<MeetingPoint> history = [];

  Contact({
    required this.name,
    required this.email,
    required this.phone,
    this.birthday,
    this.picture
  });

  void addMeetingPoint(double latitude, double longitude, DateTime date) {
    history.add(MeetingPoint(latitude: latitude, longitude: longitude, date: date));
  }

  List<MeetingPoint> getMeetingPoints() {
    return history;
  }

  // JSON Util
  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'email': email,
      'phone': phone,
      'birthday': birthday?.toIso8601String(),
      'picture': picture?.path,
      'history': history.map((meeting) => meeting.toJson()).toList(),
    };
  }

  factory Contact.fromJson(Map<String, dynamic> json) {
    return Contact(
      name: json['name'],
      email: json['email'],
      phone: json['phone'],
      birthday: json['birthday'] != null ? DateTime.parse(json['birthday']) : null,
      picture: json['picture'] != null ? File(json['picture']) : null,
    )..history = (json['history'] as List<dynamic>)
        .map((item) => MeetingPoint.fromJson(item as Map<String, dynamic>))
        .toList();
  }
}