import 'dart:convert';
import 'dart:io';

import 'package:contacts/model/contact.dart';

class ContactList {
  List<Contact> contacts = [];

  final Directory dir;


  ContactList(this.dir);

  Future<void> readData() async {
    try {
      final file = File('${dir.path}/contacts.json');
      if (await file.exists()) {
        String content = await file.readAsString();
        List<dynamic> jsonList = jsonDecode(content);

        contacts = jsonList.map((json) => Contact.fromJson(json)).toList();
      }
    } catch (_) {}
  }


  void addContact(Contact contact) {
    contacts.add(contact);
  }

  List<Contact> getContacts() {
    return contacts..sort((a, b) => a.name.compareTo(b.name));
  }

  Future<void> saveData() async {
    try {
      File file = File('${dir.path}/contacts.json');

      List<Map<String, dynamic>> jsonList = contacts.map((contact) => contact.toJson()).toList();
      await file.writeAsString(jsonEncode(jsonList));
    } catch (_) {}
  }
}

