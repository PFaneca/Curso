import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../viewmodels/contacts_viewmodel.dart';

class EditScreen extends StatefulWidget {
  const EditScreen({super.key});
  static const String routeName = '/edit';

  @override
  State<StatefulWidget> createState() => _EditScreenState();
}

class _EditScreenState extends State<EditScreen> {
  late final contactsViewModel = Provider.of<ContactsViewModel>(context);
  late final TextEditingController _birthdayController = TextEditingController(text: contactsViewModel.birthday?.toString().split(' ')[0] ?? 'No birthday');
  late File file = contactsViewModel.picture ?? File('${contactsViewModel.contactList.dir.path}/userImage${UniqueKey()}');

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: contactsViewModel.birthday ?? DateTime.now(),
      firstDate: DateTime(1900),
      lastDate: DateTime(2100),
    );

    if (picked != null && picked != contactsViewModel.birthday) {
      setState(() {
        _birthdayController.text = picked.toString().split(' ')[0];
        contactsViewModel.birthday = picked;
      });
    }
  }

  @override
  void dispose() {
    super.dispose();
    _birthdayController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          contactsViewModel.selectedContact == null
            ? 'Create Contact'
            : 'Edit Contact',
        ),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        actions: [
          IconButton(
            icon: const Icon(Icons.done),
            onPressed: () {
              if (contactsViewModel.saveContact()) {
                Navigator.pop(context);
              }
            },
          )
        ],
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Padding(padding: const EdgeInsets.all(15),
          child: Column(
            children: [
              TextFormField(
                decoration: const InputDecoration(
                  labelText: 'Name',
                  border: OutlineInputBorder(),
                ),
                initialValue: contactsViewModel.name,
                onChanged: (value) => { contactsViewModel.name = value },
              ),
        
              const SizedBox(height: 20),
        
              TextFormField(
                decoration: const InputDecoration(
                  labelText: 'Phone',
                  border: OutlineInputBorder(),
                ),
                initialValue: contactsViewModel.phone,
                onChanged: (value) => { contactsViewModel.phone = value },
              ),
        
              const SizedBox(height: 20),
        
              TextFormField(
                decoration: const InputDecoration(
                  labelText: 'Email',
                  border: OutlineInputBorder(),
                ),
                initialValue: contactsViewModel.email,
                onChanged: (value) => { contactsViewModel.email = value },
              ),
        
              const SizedBox(height: 20),
        
              TextFormField(
                onTap: () => _selectDate(context),
                decoration: const InputDecoration(
                  labelText: 'Birthday',
                  border: OutlineInputBorder(),
                  suffixIcon: Icon(Icons.calendar_today)
                ),
                controller: _birthdayController,
                readOnly: true,
              ),
        
              const SizedBox(height: 20),
        
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton(
                    onPressed: () async {
                      final imgFile = await ImagePicker().pickImage(source: ImageSource.gallery);
                      if (imgFile != null) {
                        await imgFile.saveTo(file.path);
                        contactsViewModel.picture = file;
                        FileImage(file).evict();
                      }
                      setState(() {});
                    },
                    child: const Text('Select Picture'),
                  ),
                  ElevatedButton(
                    onPressed: () async {
                      final imgFile = await ImagePicker().pickImage(source: ImageSource.camera);
                      if (imgFile != null) {
                        await imgFile.saveTo(file.path);
                        contactsViewModel.picture = file;
                        FileImage(file).evict();
                      }
                      setState(() {});
                    },
                    child: const Text('Take Picture'),
                  )
                ],
              ),

              const SizedBox(height: 20),
        
              if (file.existsSync())
                ClipOval(
                  child: Image.file(key: UniqueKey(), file, fit: BoxFit.fill, width: 250, height: 250),
                ),
            ],
          ))
        ),
      )
    );
  }
}