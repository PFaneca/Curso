import 'package:contacts/ui/screens/show_screen.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../viewmodels/contacts_viewmodel.dart';

class HistoryScreen extends StatelessWidget {
  const HistoryScreen({super.key});
  static const String routeName = '/history';

  @override
  Widget build(BuildContext context) {
    final contactsViewModel = Provider.of<ContactsViewModel>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('History'),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      body: ListenableBuilder(
        listenable: contactsViewModel,
        builder: (context, child) {
          return Center(
            child: Column(
              children: <Widget>[
                Expanded(
                  child: ListView.separated(
                    padding: const EdgeInsets.all(8),
                    itemCount: contactsViewModel.historyContacts.length,
                    itemBuilder: (BuildContext context, int index) {
                      return Column(
                        children: [
                          Row(
                            children: [
                              ClipOval(
                                child: contactsViewModel.historyContacts[index].picture != null
                                    ? Image.file(contactsViewModel.historyContacts[index].picture!, fit: BoxFit.fill, width: 50, height: 50)
                                    : Image.asset('images/avatar_icon.png', fit: BoxFit.fill, width: 50, height: 50),
                              ),
                              const SizedBox(width: 10),
                              Text(contactsViewModel.historyContacts[index].name, style: const TextStyle(fontSize: 18)),
                            ]
                          ),
                        ],
                      );
                    },
                    separatorBuilder: (BuildContext context, int index) => const Divider(),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}