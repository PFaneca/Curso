import 'package:contacts/ui/screens/edit_screen.dart';
import 'package:contacts/ui/screens/show_screen.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../viewmodels/contacts_viewmodel.dart';
import 'history_screen.dart';

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});
  static const routeName = '/';

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  bool _expanded = false;

  void _changeExpanded() {
    setState(() {
      _expanded = !_expanded;
    });
  }

  @override
  Widget build(BuildContext context) {
    final contactsViewModel = Provider.of<ContactsViewModel>(context);

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text(widget.title),
        actions: [
          IconButton(
            icon: const Icon(Icons.history),
            onPressed: () {
              Navigator.pushNamed(context, HistoryScreen.routeName);
            },
          ),
          IconButton(
            icon: const Icon(Icons.expand_more),
            onPressed: _changeExpanded,
          )
        ],
      ),
      body: ListenableBuilder(
        listenable: contactsViewModel,
        builder: (context, child) {
          return Center(
            child: Column(
              children: <Widget>[
                Expanded(
                  child: ListView.separated(
                    padding: const EdgeInsets.all(8),
                    itemCount: contactsViewModel.contactList.getContacts().length,
                    itemBuilder: (BuildContext context, int index) {
                      return GestureDetector(
                          onTap: () {
                            contactsViewModel.selectContact(contactsViewModel.contactList.getContacts()[index]);
                            Navigator.pushNamed(context, ShowScreen.routeName);
                          },
                          child: Column(
                            children: [
                              Row(
                                  children: [
                                    ClipOval(
                                      child: contactsViewModel.contactList.getContacts()[index].picture != null
                                          ? Image.file(contactsViewModel.contactList.getContacts()[index].picture!, fit: BoxFit.fill, width: 50, height: 50)
                                          : Image.asset('images/avatar_icon.png', fit: BoxFit.fill, width: 50, height: 50),
                                    ),
                                    const SizedBox(width: 10),
                                    Text(contactsViewModel.contactList.getContacts()[index].name, style: const TextStyle(fontSize: 18)),
                                  ]
                              ),

                              if (_expanded) ...[
                                const SizedBox(height: 15),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                                  children: [
                                    Row(
                                      children: [
                                        const Icon(Icons.phone),
                                        const SizedBox(width: 5),
                                        Text(contactsViewModel.contactList.getContacts()[index].phone),
                                      ],
                                    ),

                                    Row(
                                      children: [
                                        const Icon(Icons.email),
                                        const SizedBox(width: 5),
                                        Text(contactsViewModel.contactList.getContacts()[index].email),
                                      ],
                                    )
                                  ],
                                ),
                                const SizedBox(height: 10), // Espaço entre os dados
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    const SizedBox(width: 10),
                                    const Icon(Icons.cake), // Ícone de aniversário
                                    const SizedBox(width: 5),
                                    // Verifica se o aniversário existe e formata a data ou exibe "----,--,--"
                                    Text(
                                      contactsViewModel.contactList.getContacts()[index].birthday != null
                                          ? contactsViewModel.contactList.getContacts()[index].birthday!.toString().split(' ')[0]
                                          : 'No birthday',
                                    ),
                                  ],
                                ),
                              ]
                            ],
                          )
                      );
                    },
                    separatorBuilder: (BuildContext context, int index) => const Divider(),
                  ),
                ),
              ],
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          contactsViewModel.createContact();
          Navigator.pushNamed(context, EditScreen.routeName);
        },
        tooltip: 'Increment',
        child: const Icon(Icons.add),
      ), // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}