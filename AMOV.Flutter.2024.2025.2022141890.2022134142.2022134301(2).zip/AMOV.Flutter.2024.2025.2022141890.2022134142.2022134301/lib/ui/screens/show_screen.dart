import 'dart:async';

import 'package:contacts/model/contact.dart';
import 'package:contacts/ui/screens/edit_screen.dart';
import 'package:contacts/ui/screens/homepage.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:location/location.dart';
import 'package:provider/provider.dart';

import '../viewmodels/contacts_viewmodel.dart';

class ShowScreen extends StatefulWidget {
  const ShowScreen({super.key});
  static const String routeName = '/show';

  @override
  State<StatefulWidget> createState() => _ShowScreenState();
}

class _ShowScreenState extends State<ShowScreen> {
  late final contactsViewModel = Provider.of<ContactsViewModel>(context);
  final Completer<GoogleMapController> _controller = Completer<GoogleMapController>();

  static const CameraPosition _kGooglePlex = CameraPosition(
    target: LatLng(40.1925, -8.4128),
    zoom: 6.0,
  );

  final List<Marker> _markers = [];

  @override
  Widget build(BuildContext context) {
    final Contact contact = contactsViewModel.selectedContact!;

    contact.getMeetingPoints().forEach((point) {
      _markers.add(
        Marker(
          markerId: MarkerId(point.date.toString()),
          position: LatLng(point.latitude, point.longitude),
          infoWindow: InfoWindow(title: point.date.toString().split(' ')[0])
        )
      );
    });

    return Scaffold(
        appBar: AppBar(
          title: const Text('Show Contact'),
          backgroundColor: Theme.of(context).colorScheme.inversePrimary,
          actions: [
            IconButton(
              icon: const Icon(Icons.location_on),
              onPressed: () {
                contactsViewModel.saveLocation();
              },
            ),
            IconButton(
              icon: const Icon(Icons.delete),
              onPressed: () {
                contactsViewModel.removeSelected();
                Navigator.pushNamed(context, MyHomePage.routeName);
              },
            ),
            IconButton(
              icon: const Icon(Icons.edit),
              onPressed: () {
                Navigator.pushNamed(context, EditScreen.routeName);
              },
            )
          ],
        ),
        body: ListenableBuilder(
          listenable: contactsViewModel,
          builder: (context, child) {
            return OrientationBuilder(
              builder: (context, orientation) {
                if (orientation == Orientation.portrait) {
                  return _buildPortrait(contact);
                } else {
                  return _buildLandscape(contact);
                }
              }
            );
          }
        )
    );
  }

  Widget _buildPortrait(Contact contact) {
    return SingleChildScrollView(
      child: Center(
          child: Column(
            children: [
              const SizedBox(height: 20),
              ClipOval(
                child: contact.picture != null
                    ? Image.file(contact.picture!, fit: BoxFit.fill, width: 250, height: 250)
                    : Image.asset('images/avatar_icon.png', fit: BoxFit.fill, width: 250, height: 250),
              ),
              const SizedBox(height: 20),
              Text(contact.name, style: const TextStyle(fontSize: 22)),
      
              const SizedBox(height: 20),
      
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  const SizedBox(width: 20),
                  const Icon(Icons.phone),
                  const SizedBox(width: 5),
                  Text(contact.phone),
                ],
              ),
      
              const SizedBox(height: 20),
      
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  const SizedBox(width: 20),
                  const Icon(Icons.email),
                  const SizedBox(width: 5),
                  Text(contact.email),
                ],
              ),
      
              const SizedBox(height: 20),
      
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  const SizedBox(width: 20),
                  const Icon(Icons.cake),
                  const SizedBox(width: 5),
                  Text(contact.birthday != null ? contact.birthday!.toString().split(' ')[0] : 'No birthday'),
                ],
              ),
      
              const SizedBox(height: 20),
      
              // Google maps
              SizedBox(
                width: 350,
                height: 350,
                child: GoogleMap(
                  mapType: MapType.normal,
                  initialCameraPosition: _kGooglePlex,
                  markers: Set<Marker>.of(_markers),
                  onMapCreated: (GoogleMapController controller) {
                    _controller.complete(controller);
                  },
                ),
              ),
            ],
          )
      ),
    );
  }

  Widget _buildLandscape(Contact contact) {
    return Center(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const SizedBox(width: 20),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ClipOval(
                  child: contact.picture != null
                      ? Image.file(contact.picture!, fit: BoxFit.fill, width: 200, height: 200)
                      : Image.asset('images/avatar_icon.png', fit: BoxFit.fill, width: 200, height: 200),
                ),
                const SizedBox(height: 20),
                Text(contact.name, style: const TextStyle(fontSize: 22)),
              ],
            ),

            const SizedBox(width: 40),

            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    const SizedBox(width: 20),
                    const Icon(Icons.phone),
                    const SizedBox(width: 5),
                    Text(contact.phone),
                  ],
                ),

                const SizedBox(height: 40),

                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    const SizedBox(width: 20),
                    const Icon(Icons.email),
                    const SizedBox(width: 5),
                    Text(contact.email),
                  ],
                ),

                const SizedBox(height: 40),

                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    const SizedBox(width: 20),
                    const Icon(Icons.cake),
                    const SizedBox(width: 5),
                    Text(contact.birthday != null ? contact.birthday!.toString().split(' ')[0] : 'No birthday'),
                  ],
                ),

              ],
            ),

            const SizedBox(width: 40),

            // Google maps
            SizedBox(
              width: 300,
              height: 300,
              child: GoogleMap(
                mapType: MapType.normal,
                initialCameraPosition: _kGooglePlex,
                markers: Set<Marker>.of(_markers),
                onMapCreated: (GoogleMapController controller) {
                  _controller.complete(controller);
                },
              ),
            ),
          ],
        )
    );
  }
}