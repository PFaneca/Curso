
import 'dart:convert';
import 'dart:io';

import 'package:contacts/model/contact.dart';
import 'package:contacts/model/contact_list.dart';
import 'package:flutter/foundation.dart';
import 'package:location/location.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ContactsViewModel extends ChangeNotifier {
  final ContactList contactList;
  Contact? selectedContact;
  String name = '';
  String phone = '';
  String email = '';
  DateTime? birthday;
  File? picture;

  ContactsViewModel(this.contactList) {
    initLocation();
    initHistory();

    location.onLocationChanged.listen(
      (LocationData currentLocation) {
        _locationData = currentLocation;
      }
    );

  }

  void createContact() {
    selectedContact = null;
    name = '';
    phone = '';
    email = '';
    birthday = null;
    picture = null;
  }

  void selectContact(Contact contact) {
    selectedContact = contact;
    name = contact.name;
    phone = contact.phone;
    email = contact.email;
    birthday = contact.birthday;
    picture = contact.picture;
  }

  bool saveContact() {
    if (name.isEmpty || phone.isEmpty || email.isEmpty) {
      return false;
    }

    if (selectedContact == null) {
      Contact newContact = Contact(
        name: name,
        email: email,
        phone: phone,
        birthday: birthday,
        picture: picture
      );

      contactList.addContact(newContact);
      saveRecentContact(newContact);
    } else {
      selectedContact!.name = name;
      selectedContact!.phone = phone;
      selectedContact!.email = email;
      selectedContact!.birthday = birthday;
      selectedContact!.picture = picture;

      saveRecentContact(selectedContact!);
    }

    notifyListeners();
    contactList.saveData();
    return true;
  }

  void removeSelected() {
    if (selectedContact != null) {
      contactList.contacts.remove(selectedContact);
      contactList.saveData();
      notifyListeners();
    }
  }

  // Location
  Location location = Location();
  bool _locationServiceEnabled = false;

  PermissionStatus _permissionGranted = PermissionStatus.denied;
  LocationData _locationData = LocationData.fromMap({
    'latitude' : 40.1925,
    'longitude' : -8.4128
  });

  Future<void> initLocation() async {
    _locationServiceEnabled = await location.serviceEnabled();
    if (!_locationServiceEnabled) {
      _locationServiceEnabled = await location.requestService();
      if (!_locationServiceEnabled) {
        return;
      }
    }

    _permissionGranted = await location.hasPermission();
    if (_permissionGranted == PermissionStatus.denied) {
      _permissionGranted = await location.requestPermission();
      if (_permissionGranted != PermissionStatus.granted) {
        return;
      }
    }
  }

  void saveLocation() {
    if (!_locationServiceEnabled || _permissionGranted != PermissionStatus.granted) {
      return;
    }

    selectedContact?.addMeetingPoint(_locationData.latitude!, _locationData.longitude!, DateTime.now());

    saveRecentContact(selectedContact!);
    contactList.saveData();
    notifyListeners();
  }

  // History
  static const String _historyContactsKey = 'recent_contacts';
  List<Contact> historyContacts = [];

  Future<void> initHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final String? storedContacts = prefs.getString(_historyContactsKey);

    if (storedContacts != null) {
      List<dynamic> jsonData = json.decode(storedContacts);
      historyContacts = jsonData.map((e) => Contact.fromJson(e)).toList();
    }
  }

  Future<void> saveRecentContact(Contact contact) async {
    final prefs = await SharedPreferences.getInstance();

    // Atualizar a lista
    historyContacts.removeWhere((c) => c.phone == contact.phone);
    historyContacts.insert(0, contact);
    if (historyContacts.length > 10) {
      historyContacts = historyContacts.sublist(0, 10);
    }

    String updatedContacts = json.encode(historyContacts.map((c) => c.toJson()).toList());
    await prefs.setString(_historyContactsKey, updatedContacts);
  }
}