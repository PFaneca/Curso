package pt.isec.pa.javalife.model;

import pt.isec.pa.javalife.model.command.*;
import pt.isec.pa.javalife.model.data.*;
import pt.isec.pa.javalife.model.gameengine.IGameEngine;
import pt.isec.pa.javalife.model.gameengine.IGameEngineEvolve;
import pt.isec.pa.javalife.model.memento.*;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.*;
import java.util.Set;

/**
 * Manager do projeto
 */
public class EcossistemaManager implements IOriginator, IGameEngineEvolve,Serializable{
    @Serial
    private static final long serialVersionUID = 1L;

    public static final String PROP_FIGURES = "_figures_";

    int largura,comprimento;
    Ecossistema receiver;
    CommandManager cm;
    private transient CareTaker careTaker;
    private PropertyChangeSupport pcs;

    /**
     * Constrói um EcossistemaManager com as dimensões especificadas.
     *
     * @param comprimento o comprimento do ecossistema
     * @param largura a largura do ecossistema
     */
    public EcossistemaManager(int comprimento,int largura){
        receiver = new Ecossistema(comprimento, largura);
        cm = new CommandManager();
        pcs = new PropertyChangeSupport(this);
        careTaker = new CareTaker(this);
    }

    /**
     * Obtém o comprimento do ecossistema.
     *
     * @return o comprimento do ecossistema
     */
    public int getComprimento() {
        return comprimento;
    }

    /**
     * Obtém a largura do ecossistema.
     *
     * @return a largura do ecossistema
     */
    public int getLargura() {
        return largura;
    }

    /**
     * Define a largura do ecossistema.
     *
     * @param largura a nova largura do ecossistema
     */
    public void setLargura(int largura) {
        this.largura = largura;
    }

    /**
     * Define o comprimento do ecossistema.
     *
     * @param comprimento o novo comprimento do ecossistema
     */
    public void setComprimento(int comprimento) {
        this.comprimento = comprimento;
    }

    /**
     * Adiciona um listener de mudança de propriedade para uma propriedade específica.
     *
     * @param property a propriedade para a qual adicionar o listener
     * @param listener o ouvinte a ser adicionado
     */
    public void addPropertyChangeListener(String property, PropertyChangeListener listener) {
        pcs.addPropertyChangeListener(property,listener);
    }

    /**
     * Adiciona um listener de mudança de propriedade.
     *
     * @param listener o listener a ser adicionado
     */
    public void addPropertyChangeListener(PropertyChangeListener listener) {
        pcs.addPropertyChangeListener(listener);
    }

    /**
     * Evolui o ecossistema com base no motor de jogo e no tempo atual.
     *
     * @param gameEngine o motor de jogo a ser usado para a evolução
     * @param currentTime o tempo atual
     */
    @Override
    public void evolve(IGameEngine gameEngine, long currentTime) {
        receiver.evolve(gameEngine,currentTime);
        pcs.firePropertyChange(PROP_FIGURES,null,null);
    }

    /**
     * Obtém o tipo atual do elemento.
     *
     * @return o tipo atual do elemento
     */
    public ElementoBase.Elemento getCurrentType() {
        return receiver.getCurrentType();
    }

    /**
     * Define o tipo atual do elemento.
     *
     * @param currentType o novo tipo do elemento
     */
    public void setCurrentType(ElementoBase.Elemento currentType) {
        receiver.setCurrentType(currentType);
    }

    /**
     * Cria um novo elemento na posição especificada.
     *
     * @param x a coordenada x da posição
     * @param y a coordenada y da posição
     */
    public void createElemento(double x, double y) {
        if(receiver.isPositionOccupiedByInanimado(x,y)){
            return;
        }
        cm.invokeCommand(new AddCommand(receiver,x,y));
        pcs.firePropertyChange(PROP_FIGURES,null,null);

    }

    /**
     * Atualiza a figura atual com novas coordenadas.
     *
     * @param x a coordenada x da nova posição
     * @param y a coordenada y da nova posição
     */
    public void updateCurrentFigure(double x, double y) {
        receiver.updateCurrentFigure(x, y);
        pcs.firePropertyChange(PROP_FIGURES,null,null);
    }

    /**
     * Finaliza a figura atual na posição especificada.
     *
     * @param x a coordenada x da posição final
     * @param y a coordenada y da posição final
     */
    public void finishCurrentFigure(double x,double y) {
        receiver.finishCurrentFigure(x, y);
        pcs.firePropertyChange(PROP_FIGURES,null,null);
        setCurrentType(null);
    }

    /**
     * Obtém a figura atual.
     *
     * @return a figura atual
     */
    public ElementoBase getCurrentFigure() {
        return receiver.getCurrentFigure();
    }

    /**
     * Obtém a lista de elementos no ecossistema.
     *
     * @return o conjunto de elementos no ecossistema
     */
    public Set<IElemento> getList() {
        return receiver.getList();
    }

    /**
     * Limpa todos os elementos do ecossistema.
     */
    public void clearAll() {
        receiver.clearAll();
        pcs.firePropertyChange(PROP_FIGURES,null,null);
    }


    /**
     * Altera a força de um elemento com nova força.
     *
     * @param elementoForca o elemento cuja força será alterada
     * @param forca o novo valor da força
     */
    public void alterarForca(IElementoComForca elementoForca,double forca){
        cm.invokeCommand(new EditionForcaCommand(receiver,elementoForca,forca));

    }

    /**
     * Altera a área de um elemento base especificado.
     *
     * @param elemento o elemento cuja área será alterada
     * @param area a nova área do elemento
     */
    public void alterarArea(ElementoBase elemento, Area area){
        cm.invokeCommand(new EditionAreaCommand(receiver,elemento,area));
        pcs.firePropertyChange(PROP_FIGURES,null,null);
    }

    /**
     * Altera a força perdida de uma flora especificada.
     *
     * @param flora a flora cuja força perdida será alterada
     * @param forcaPerdida o novo valor da força perdida
     */
    public void alterarForcaPerdidaFlora(Flora flora,double forcaPerdida){
        cm.invokeCommand(new EditionForcaPerdidaFloraCommand(receiver,flora,forcaPerdida));

    }

    /**
     * Altera a força de movimento de uma fauna especificada.
     *
     * @param fauna a fauna cuja força de movimento será alterada
     * @param forcaMovimento o novo valor da força de movimento
     */
    public void alterarForcaMovimento(Fauna fauna,double forcaMovimento){
        cm.invokeCommand(new EditionForcaMovimentoCommand(receiver,fauna,forcaMovimento));

    }

    /**
     * Verifica se há comandos para desfazer.
     *
     * @return true se houver comandos para desfazer, caso contrário false
     */
    public boolean hasUndo(){
        return cm.hasUndo();
    }

    /**
     * Desfaz o último comando.
     *
     * @return true se o comando foi desfeito com sucesso, caso contrário false
     */
    public boolean undo() {
        boolean result = cm.undo();
        pcs.firePropertyChange(PROP_FIGURES,null,null);
        return result;
    }

    /**
     * Refaz o último comando desfeito.
     *
     * @return true se o comando foi refeito com sucesso, caso contrário false
     */
    public boolean redo() {
        boolean result = cm.redo();
        pcs.firePropertyChange(PROP_FIGURES,null,null);
        return result;
    }

    /**
     * Verifica se há comandos para refazer.
     *
     * @return true se houver comandos para refazer, caso contrário false
     */
    public boolean hasredo(){
        return cm.hasRedo();
    }


    /**
     * Retorna a representação em string do ecossistema.
     *
     * @return a string representando o ecossistema
     */
    @Override
    public String toString() {
        return receiver.toStringSorted();
    }


    /**
     * Salva o estado atual do ecossistema em arquivo.
     *
     * @param file o arquivo no qual salvar o estado
     * @return true se o estado foi salvo com sucesso, caso contrário false
     */
    public boolean save(File file) {
        try (
                ObjectOutputStream oos = new ObjectOutputStream(
                        new FileOutputStream(file) )
        ) {
            oos.writeObject(receiver);
        } catch (Exception e) {
            System.err.println("Error writing ecossistema");
            return false;
        }
        return true;
    }

    /**
     * Carrega o estado do ecossistema de um arquivo.
     *
     * @param file o arquivo do qual carregar o estado
     * @return true se o estado foi carregado com sucesso, caso contrário false
     */
    public boolean load(File file) {
        try (
                ObjectInputStream ois = new ObjectInputStream(
                        new FileInputStream(file) )
        ) {
            receiver = (Ecossistema) ois.readObject();
        } catch (Exception e) {
            System.err.println("Error loading ecossistema");
            return false;
        }
        pcs.firePropertyChange(PROP_FIGURES,null,null);
        return true;
    }


    /**
     * Exporta o estado do ecossistema para um arquivo.
     *
     * @param file o arquivo no qual exportar o estado
     */
    public void exportar(File file) {
        receiver.exportar(file);
    }

    /**
     * Importa o estado do ecossistema de um arquivo.
     *
     * @param file o arquivo do qual importar o estado
     */
    public void importar(File file) {
        receiver.importar(file);
        pcs.firePropertyChange(PROP_FIGURES,null,null);
        //pcs.firePropertyChange(PROP_TOOLS,null,null);
    }


    /**
     * Salva um memento do estado atual do ecossistema.
     *
     * @return o memento do estado atual
     */
    @Override
    public IMemento save() {
        return new Memento(receiver);

    }

    /**
     * Restaura o estado do ecossistema a partir de um memento.
     *
     * @param memento o memento a partir do qual restaurar o estado
     */
    @Override
    public void restore(IMemento memento) {
        Object obj = memento.getSnapshot();
        if (obj instanceof Ecossistema) {
            this.receiver = (Ecossistema) obj;
            pcs.firePropertyChange(PROP_FIGURES, null, null);
            //pcs.firePropertyChange(PROP_TOOLS, null, null);
        }

    }

    /**
     * Salva um snapshot do estado atual do ecossistema.
     */
    public void saveSnapshot() {
        if (receiver != null) {
            careTaker.save();
        }
    }

    /**
     * Restaura o último snapshot salvo do estado do ecossistema.
     */
    public void restoreSnapshot() {
        if (careTaker.hasUndo()) {
            careTaker.undo();
        }

    }

    /**
     * Aplica o efeito do sol ao ecossistema.
     */
    public void efeitoSol(){
        receiver.efeitoSol();
    }

    /**
     * Seleciona um elemento no ecossistema na posição especificada.
     *
     * @param x a coordenada x da posição
     * @param y a coordenada y da posição
     */
    public void selecionarElemento(double x, double y) {
        receiver.selecionarElemento(x,y);
    }

    /**
     * Elimina o elemento selecionado do ecossistema.
     */
    public void eliminarElemento(){
        cm.invokeCommand(new RemoveCommand(receiver));
        pcs.firePropertyChange(PROP_FIGURES, null, null);
    }


    /**
     * Obtém o elemento atualmente selecionado no ecossistema.
     *
     * @return o elemento atualmente selecionado
     */
    public ElementoBase getSelecionado(){
        return receiver.getSelecionado();
    }

    /**
     * Elimina o elemento selecionado se for uma flora, utilizando herbicida.
     */
    public void eliminarcomHerbicida(){
        ElementoBase selecionado = receiver.getSelecionado();
        if (selecionado != null && selecionado.getType() == ElementoBase.Elemento.FLORA) {
            cm.invokeCommand(new RemoveCommand(receiver));
            pcs.firePropertyChange(PROP_FIGURES, null, null);

        }
    }

    /**
     * Injeta força no elemento selecionado se for uma fauna.
     */
    public void injetarForca(){
        ElementoBase selecionado = receiver.getSelecionado();
        if (selecionado != null && selecionado.getType() == ElementoBase.Elemento.FAUNA) {
            receiver.injetarForca();
        }
    }

/*
    public void undo() {
        careTaker.undo();
    }

    public void redo() {
        careTaker.redo();
    }

    public boolean hasUndo() {
        return careTaker.hasUndo();
    }

    public boolean hasRedo() {
        return careTaker.hasRedo();
    }*/

}

