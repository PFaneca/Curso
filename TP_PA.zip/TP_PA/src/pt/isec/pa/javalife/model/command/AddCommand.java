package pt.isec.pa.javalife.model.command;

import pt.isec.pa.javalife.model.data.Ecossistema;
import pt.isec.pa.javalife.model.data.ElementoBase;
import pt.isec.pa.javalife.model.data.IElemento;

import java.io.Serializable;

public class AddCommand extends AbstractCommand implements Serializable {
    private static final long serialVersionUID = 1L;
    private IElemento elemento;
    protected double x,y;


    public AddCommand(Ecossistema receiver,double x,double y){
        super(receiver);
        this.x=x;
        this.y=y;
        this.elemento = null;
    }

    @Override
    public boolean execute() {
        this.elemento = receiver.createElemento(x, y);
        return true;
    }

    @Override
    public boolean undo()  {
        if (this.elemento != null) {
            receiver.remove(elemento);
            this.elemento = null; // Reset elemento
            return true;
        }
        return false;
    }

}
