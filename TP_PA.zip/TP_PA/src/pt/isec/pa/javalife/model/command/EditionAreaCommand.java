package pt.isec.pa.javalife.model.command;

import pt.isec.pa.javalife.model.data.Area;
import pt.isec.pa.javalife.model.data.Ecossistema;
import pt.isec.pa.javalife.model.data.ElementoBase;

public class EditionAreaCommand extends AbstractCommand {

    private ElementoBase elemento;
    Area area,areaAnterior;

    public EditionAreaCommand(Ecossistema receiver, ElementoBase elemento,Area area){
        super(receiver);
        this.area=area;
        this.elemento=elemento;
        this.areaAnterior = new Area(elemento.getX1(), elemento.getX2(), elemento.getY1(), elemento.getY2());

    }


    @Override
    public boolean execute() {
        receiver.alterarArea(elemento,area);
        return true;
    }

    @Override
    public boolean undo() {
        receiver.alterarArea(elemento,areaAnterior);
        return true;
    }
}
