package pt.isec.pa.javalife.model.command;

import pt.isec.pa.javalife.model.data.Ecossistema;
import pt.isec.pa.javalife.model.data.IElementoComForca;

public class EditionForcaCommand extends AbstractCommand{

    private IElementoComForca elementoForca;
    private double forca,forcaAnterior;


    public EditionForcaCommand(Ecossistema receiver, IElementoComForca elementoForca, double forca){
        super(receiver);
        this.elementoForca=elementoForca;
        this.forca=forca;
        this.forcaAnterior=elementoForca.getForca();
    }


    @Override
    public boolean execute() {
        receiver.alterarforca(elementoForca,forca);
        return true;
    }

    @Override
    public boolean undo() {
        receiver.alterarforca(elementoForca,forcaAnterior);
        return true;
    }
}
