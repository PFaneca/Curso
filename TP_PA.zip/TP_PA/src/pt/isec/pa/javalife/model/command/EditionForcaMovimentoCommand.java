package pt.isec.pa.javalife.model.command;

import pt.isec.pa.javalife.model.data.Ecossistema;
import pt.isec.pa.javalife.model.data.Fauna;

public class EditionForcaMovimentoCommand extends AbstractCommand{

    private Fauna fauna;
    private double forcaMovimento,forcaMovimentoAnterior;

    public EditionForcaMovimentoCommand(Ecossistema receiver, Fauna fauna, double forcaMovimento){
        super(receiver);
        this.fauna=fauna;
        this.forcaMovimento=forcaMovimento;
        this.forcaMovimentoAnterior=fauna.getforcaMovimento();
    }


    @Override
    public boolean execute() {
        receiver.alterarForcaMovimento(fauna,forcaMovimento);
        return true;
    }

    @Override
    public boolean undo() {
        receiver.alterarForcaMovimento(fauna,forcaMovimentoAnterior);
        return true;
    }
}
