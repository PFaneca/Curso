package pt.isec.pa.javalife.model.command;

import pt.isec.pa.javalife.model.data.Ecossistema;
import pt.isec.pa.javalife.model.data.Flora;

public class EditionForcaPerdidaFloraCommand extends AbstractCommand{

    private Flora flora;
    double forcaPerdida,forcaPerdidaAnterior;

    public EditionForcaPerdidaFloraCommand(Ecossistema receiver, Flora flora, double forcaPerdida){
        super(receiver);
        this.flora=flora;
        this.forcaPerdida=forcaPerdida;
        this.forcaPerdidaAnterior=flora.getReducaoForcaFlora();
    }

    @Override
    public boolean execute() {
        receiver.alterarForcaPerdidaFlora(flora,forcaPerdida);
        return true;
    }

    @Override
    public boolean undo() {
        receiver.alterarForcaPerdidaFlora(flora,forcaPerdidaAnterior);
        return true;
    }
}
