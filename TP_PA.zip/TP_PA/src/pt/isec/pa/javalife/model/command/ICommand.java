package pt.isec.pa.javalife.model.command;

import java.io.Serializable;

public interface ICommand  {
    public boolean execute();
    public boolean undo();
}
