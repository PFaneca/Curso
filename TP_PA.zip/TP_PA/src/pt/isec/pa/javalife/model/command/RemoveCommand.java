package pt.isec.pa.javalife.model.command;

import pt.isec.pa.javalife.model.data.*;

import java.util.ArrayList;
import java.util.List;

public class RemoveCommand extends AbstractCommand{

    private IElemento elemento;

    public RemoveCommand(Ecossistema receiver){
        super(receiver);
        this.elemento=null;
    }


    @Override
    public boolean execute()  {
        this.elemento=receiver.deleteSelectedElement();
        return true;
}
    @Override
    public boolean undo() {
        receiver.adicionarElemento(elemento);
        return true;
    }
}
