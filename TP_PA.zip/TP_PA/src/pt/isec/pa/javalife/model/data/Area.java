package pt.isec.pa.javalife.model.data;

import java.io.Serializable;


public record Area(double x1, double x2, double y1, double y2) implements Serializable {
    private static final long serialVersionUID = 1L;

    public boolean intersects(Area outraArea) {
        return this.y2 > outraArea.y1 &&
                outraArea.y2 > this.y1 &&
                this.x2 > outraArea.x1 &&
                outraArea.x2 > this.x1;
    }

    public double calcularDistancia(Area outraArea) {
        double distanciaHorizontal = Math.abs(this.getCentroHorizontal() - outraArea.getCentroHorizontal());
        double distanciaVertical = Math.abs(this.getCentroVertical() - outraArea.getCentroVertical());
        return Math.sqrt(distanciaHorizontal * distanciaHorizontal + distanciaVertical * distanciaVertical);
    }

    private double getCentroHorizontal() {
        return (this.x1 + this.x2) / 2.0;
    }

    private double getCentroVertical() {
        return (this.y1 + this.y2) / 2.0;
    }

    public Area setP1(double x, double y) {
        return new Area(x, this.x2, y, this.y2);
    }

    public Area setP2(double x, double y) {
        return new Area(this.x1, x, this.y1, y);
    }

    public boolean isSobreposto(Area outra) {
        return !(x2 <= outra.x1 || outra.x2 <= x1 || y2 <= outra.y1 || outra.y2 <= y1);
    }

    public boolean isInside(double x, double y) {
        return x >= x1 && x <= x2 && y >= y1 && y <= y2;
    }
}
