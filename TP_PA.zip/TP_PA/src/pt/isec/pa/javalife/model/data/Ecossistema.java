package pt.isec.pa.javalife.model.data;
import pt.isec.pa.javalife.model.fsm.FaunaContext;
import pt.isec.pa.javalife.model.gameengine.IGameEngine;
import pt.isec.pa.javalife.model.gameengine.IGameEngineEvolve;
import java.io.*;
import java.util.*;


public class Ecossistema implements Serializable, IGameEngineEvolve {

    @Serial
    private static final long serialVersionUID = 1L;

    private ElementoBase.Elemento currentType;
    private int comprimento;
    private int largura;
    private Set<IElemento> elementos;
    private ElementoBase current;
    private ElementoBase selecionado;
    private FaunaContext fsm;


    public Ecossistema(int comprimento, int largura) {
        this.comprimento = comprimento;
        this.largura = largura;
        this.elementos = new HashSet<>();
        createCerca(comprimento, largura);
        fsm=new FaunaContext(this);

    }

    public ElementoBase.Elemento getCurrentType() {
        return currentType;
    }

    public void setCurrentType(ElementoBase.Elemento currentType) {
        this.currentType = currentType;
    }

    public void createCerca(int comprimento, int largura) {
        setCurrentType(ElementoBase.Elemento.INANIMADO);

        // Criar a pedra para a borda esquerda
        createElemento(0, 0);
        finishCurrentFigure(10, largura);

        // Criar a pedra para a borda superior
        createElemento(0, 0);
        finishCurrentFigure(comprimento, 10);

        // Criar a pedra para a borda direita
        createElemento(comprimento - 10, 0);
        finishCurrentFigure(comprimento, largura);

        // Criar a pedra para a borda inferior
        createElemento(0, largura - 35);
        finishCurrentFigure(comprimento, largura - 20);

        setCurrentType(null);

    }


    public IElemento createElemento(double x, double y) {
        if (x >= 0 && x <= comprimento && y >= 0 && y <= largura) {
            current = currentType.createElemento();
            current.setP1(x, y);
            current.setP2(x, y);
            elementos.add(current);
            return current;
        } else {
            return null;
        }
    }


    public void updateCurrentFigure(double x, double y) {
        if (current == null)
            return;
        current.setP2(x, y);
    }

    public ElementoBase finishCurrentFigure(double x, double y) {
        if (current == null)
            return null;
        current.setP2(x, y);
        ElementoBase finished = current;
        // elementos.add(current);
        current = null;
        return current;
    }


    public ElementoBase getCurrentFigure() {
        return current;
    }


    public Set<IElemento> getList() {
        Set<IElemento> retLst = new LinkedHashSet<>();
        for (IElemento elem : elementos) {
            try {
                retLst.add(elem.clone());
            } catch (CloneNotSupportedException ignored) {
            }
        }
        return retLst;
    }

    public int getComprimento() {
        return comprimento;
    }

    public int getLargura() {
        return largura;
    }

    public boolean adicionarElemento(IElemento elemento) {
        if (elementos.contains(elemento)) {
            return false; // Elemento já existe na lista
        }

        return elementos.add(elemento);
    }


    public void clearAll() {
        elementos.clear();
        ElementoBase.resetIds();
    }


    public IElemento remove(IElemento elemento) {
        // Implementação da remoção do elemento pela referência
        elementos.remove(elemento);
        return elemento;
    }


    public void alterarforca(IElementoComForca elemento, double forca) {
        elemento.setForca(forca);
    }

    public void alterarArea(ElementoBase elemento, Area area) {
        elemento.setP1(area.x1(), area.y1());
        elemento.setP2(area.x2(), area.y2());
    }

    public void alterarForcaMovimento(Fauna fauna, double forcaMovimento) {
        fauna.setForcaMovimento(forcaMovimento);
    }

    public void alterarForcaPerdidaFlora(Flora flora, double forcaPerdida) {
        flora.setForcaPerdidaFloraSobreposta(forcaPerdida);
    }

    public void alterarVelocidadeFauna(Fauna fauna, double velocidade) {
        fauna.setVelocidade(velocidade);
    }

    public void alterarForcaGanhaFauna(Flora flora, double forcaGanha) {
        flora.setForcaGanhaFaunaSobreposta(forcaGanha);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Ecossistema com " + comprimento + "de comprimento e" + largura + " de largura");
        sb.append("Elementos no Ecossistema:\n");
        for (IElemento elemento : elementos) {
            sb.append(elemento.toString()).append("\n");
        }
        return sb.toString();
    }

    public String toStringSorted() {
        StringBuilder sb = new StringBuilder("Ecossistema com " + comprimento + " de comprimento e " + largura + " de largura\"\n");
        sb.append("\nElementos:\n");
        if (elementos.isEmpty())
            sb.append("O Ecossistema está vazio");
        else {
            List<IElemento> orderList = new ArrayList<>(elementos);
            Collections.sort(orderList, new ElementoComparator());
            for (IElemento elemento : orderList)
                sb.append(String.format("-%s\n", elemento.toString()));
        }
        return sb.toString();
    }

    public Fauna encontrarFaunaMaisForte() {
        Fauna maisforte = null;
        double maiorForca = 0;
        for (IElemento elem : elementos) {
            if (elem instanceof Fauna fauna) {
                if (fauna.getForca() > maiorForca) {
                    maiorForca = fauna.getForca();
                    maisforte = fauna;
                }
            }
        }
        return maisforte;
    }



    public void efeitoSol(){
        for(IElemento elemento:elementos){
            elemento.aplicarEfeitoSol();
        }
    }

    public void injetarForca(){
        ElementoBase elementoSelecionado = getSelecionado();
        if (elementoSelecionado != null && elementoSelecionado instanceof Fauna) {
            Fauna fauna = (Fauna) elementoSelecionado;
            if (fauna.getType() == ElementoBase.Elemento.FAUNA) {
                fauna.setForca(fauna.getForca() + 50);
            }
        }
    }

    public void exportar(File file) {
        try (PrintWriter writer = new PrintWriter(file)) {
            // Escreve o cabeçalho do arquivo CSV
            writer.println("Tipo,Forca,X1,Y1,X2,--module-path \"C:\\Program Files\\Java\\javafx-sdk-22.0.1\\lib\" --add-modules javafx.controls,javafx.mediaY2");

            // Itera sobre os elementos da simulação
            for (IElemento elemento : elementos) {
                // Obtém informações do elemento
                String tipo = elemento.getType().toString();
                String forcaStr = "";

                if (elemento instanceof IElementoComForca) {
                    forcaStr = String.valueOf(((IElementoComForca) elemento).getForca());
                }

                String areaStr = "";
                double x1 = 0, y1 = 0, x2 = 0, y2 = 0;
                Area area = elemento.getArea();
                x1 = area.x1(); // Ajuste conforme necessário
                x2 = area.x2();   // Ajuste conforme necessário
                y2 = area.y2();       // Ajuste conforme necessário
                y1 = area.y1();         // Ajuste conforme necessário

                // Escreve as informações no arquivo CSV
                writer.printf("%s;%s;%.2f;%.2f;%.2f;%.2f%n", tipo, forcaStr, x1, y1,x2,y2);
            }


        } catch (IOException e) {

        }
    }

    public void importar(File file) {
        try (Scanner scanner = new Scanner(file)) {
            // Ignora a primeira linha (cabeçalho)
            if (scanner.hasNextLine()) {
                scanner.nextLine();
            }

            // Itera sobre as linhas do arquivo CSV
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] parts = line.split(";");
                if (parts.length != 6) {
                    continue;
                }
                String tipo = parts[0];
                double forca = parts[1].isEmpty() ? 0.0 : Double.parseDouble(parts[1].replace(',', '.'));
                double x1= Double.parseDouble(parts[2].replace(',', '.'));
                double y1 = Double.parseDouble(parts[3].replace(',', '.'));
                double x2= Double.parseDouble(parts[4].replace(',', '.'));
                double y2 = Double.parseDouble(parts[5].replace(',', '.'));

                double largura = x2 - x1;
                double altura = y2 - y1;

                // Verifique se a largura e a altura são positivas
                if (largura < 0 || altura < 0) {
                    continue;
                }

                Area novaArea=new Area(x1,x2,y1,y2);
                boolean sobreposicao = false;
                for (IElemento elemento : elementos) {
                    if (elemento.getArea().intersects(novaArea)) {
                        sobreposicao = true;
                        break;
                    }
                }
                if (sobreposicao) {
                    continue;
                }

                switch (tipo.toLowerCase()) {
                    case "inanimado":
                        setCurrentType(ElementoBase.Elemento.INANIMADO);
                        break;
                    case "flora":
                        setCurrentType(ElementoBase.Elemento.FLORA);
                        break;
                    case "fauna":
                        setCurrentType(ElementoBase.Elemento.FAUNA);
                        break;
                    default:
                        continue; // Continue para a próxima iteração do loop, evitando criar um elemento inválido
                }

                createElemento(x1, y1);
                finishCurrentFigure(x2, y2);


            }

        }catch (FileNotFoundException e) {

        }
    }


    public boolean isPositionOccupiedByInanimado(double x, double y) {
        for (IElemento elemento : elementos) {
            if (elemento instanceof ElementoBase) {
                ElementoBase elem = (ElementoBase) elemento;
                // Verificar se o ponto (x, y) está dentro da área do elemento
                if (x >= elem.getX1() && x <= elem.getX2() &&
                        y >= elem.getY1() && y <= elem.getY2() &&
                        elem.getType() == ElementoBase.Elemento.INANIMADO) {
                    return true;
                }
            }
        }
        return false;
    }


    public void selecionarElemento(double x, double y) {
        for(IElemento elemento:elementos){
            if(elemento.getArea().isInside(x,y)){
                elemento.changeSelected();
                selecionado=(ElementoBase)elemento;
            }
            else{
                elemento.setSelected(false);
            }
        }
    }

    public IElemento deleteSelectedElement() {
        if (selecionado != null) {
            elementos.remove(selecionado);

        }
        return selecionado;
    }

    public ElementoBase getSelecionado() {
        return selecionado;
    }


    public Flora[] getFloras() {
        List<Flora> listaFloras = new ArrayList<>();

        // Supondo que você tenha uma lista chamada "elementos" que contenha todos os elementos do ecossistema
        for (IElemento elemento : elementos) {
            // Verifica se o elemento é uma instância de Flora
            if (elemento instanceof Flora) {
                // Se for, adiciona à lista de floras
                listaFloras.add((Flora) elemento);
            }
        }

        // Converte a lista para um array de Flora e retorna
        return listaFloras.toArray(new Flora[0]);
    }

    public Fauna[] getFaunas() {
        List<Fauna> listaFaunas = new ArrayList<>();

        // Supondo que você tenha uma lista chamada "elementos" que contenha todos os elementos do ecossistema
        for (IElemento elemento : elementos) {
            // Verifica se o elemento é uma instância de Flora
            if (elemento instanceof Fauna) {
                // Se for, adiciona à lista de floras
                listaFaunas.add((Fauna) elemento);
            }
        }

        // Converte a lista para um array de Flora e retorna
        return listaFaunas.toArray(new Fauna[0]);

    }

    public boolean verificarSobreposicaoPedra(double x1, double y1, double x2, double y2) {
        for (IElemento elemento : elementos) {
            if (elemento instanceof Inanimado) {
                // Verifica se a área ocupada pela nova posição da fauna está sobreposta pela pedra
                if (isSobreposto((ElementoBase) elemento, x1, y1, x2, y2)) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean isSobreposto(ElementoBase pedra, double x1, double y1, double x2, double y2) {
        // Verifica se a área ocupada por (x1, y1) - (x2, y2) está sobreposta pela área da pedra
        // Supondo que pedra tem métodos getX1, getY1, getX2, getY2
        double pedraX1 = pedra.getX1();
        double pedraY1 = pedra.getY1();
        double pedraX2 = pedra.getX2();
        double pedraY2 = pedra.getY2();

        return !(x2 < pedraX1 || x1 > pedraX2 || y2 < pedraY1 || y1 > pedraY2);
    }



    public void vidaFlora(Flora flora) {
        flora.aumentarForca();

        if (flora.podeReproduzir()) {
            Area novaArea = flora.verificarPosicaoReproducao(elementos);
            if (novaArea != null) {
                // Verifica se a nova área está dentro dos limites do ecossistema
                if (novaArea.x1() >= 0 && novaArea.x2() <= largura && novaArea.y1() >= 0 && novaArea.y2() <= comprimento) {
                    //flora.reproduzir();
                    setCurrentType(ElementoBase.Elemento.FLORA);
                    IElemento novaFlora = createElemento(novaArea.x1(), novaArea.y1());
                    finishCurrentFigure(novaArea.x2(), novaArea.y2());
                    //novosElementos.add(novaFlora);
                } else {
                    return;
                }
            } else {
                return;
            }
        }
        if (flora.getForca() == 0) {
            elementos.remove(flora); // Remover flora com força zero
        }
    }


    public void vidaFauna(Fauna fauna) {
        fsm.evoluir(fauna);
        //System.out.println(fsm.getState());
        if (fauna.getForca() == 0) {
            remove(fauna);
        }
    }



    @Override
    public void evolve(IGameEngine gameEngine, long currentTime) {
        boolean efeitoSolAtivo = false;
        long tempoInicialSol = 0;

            for (IElemento elemento : elementos) {
                if (elemento.getSol()) {
                    efeitoSolAtivo = true;
                    tempoInicialSol = elemento.tempoSol();
                }

                if (elemento instanceof Flora) {
                    vidaFlora((Flora) elemento);
                }

                if (elemento instanceof Fauna) {
                    vidaFauna((Fauna) elemento);
                }

            }

            // Verifique e remova o efeito do sol se necessário
            if (efeitoSolAtivo && (currentTime - tempoInicialSol >= 10)) {
                for (IElemento elemento : elementos) {
                    elemento.removerEfeitoSol(); // Método para remover o efeito do sol
                }
            }

        }

}
