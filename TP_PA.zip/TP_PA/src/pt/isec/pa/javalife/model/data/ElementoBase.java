package pt.isec.pa.javalife.model.data;

import pt.isec.pa.javalife.model.data.tiposelementos.Animal;
import pt.isec.pa.javalife.model.data.tiposelementos.Erva;
import pt.isec.pa.javalife.model.data.tiposelementos.Pedra;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Comparator;
import java.util.List;

public abstract sealed class ElementoBase implements  IElemento, Cloneable,Serializable permits Inanimado,Flora,Fauna {
    private static final long serialVersionUID = 1L;
    private boolean solAplicado;
    private long tempoSolAplicado;
    private boolean selected;

    public enum Elemento{
        INANIMADO, FLORA, FAUNA;

    public ElementoBase createElemento(){
        return switch (this){
            case INANIMADO -> new Pedra();
            case FLORA -> new Erva();
            case FAUNA -> new Animal();
        };
    }

}


    private int id;
    private Elemento tipo;
    private Area area;
    protected double r,g,b;
    protected double x1,x2,y1,y2;




    // Contadores de ID para cada tipo de elemento
    private static int proximoIdInanimado = 0;
    private static int proximoIdFlora = 0;
    private static int proximoIdFauna = 0;

    public ElementoBase(ElementoBase.Elemento tipo){
        this.area = new Area(0, 0, 0, 0);
        this.tipo=tipo;
        id=getNextIdForType(tipo);
    }

    private int getNextIdForType(Elemento tipo) {
        int nextId;
        switch (tipo) {
            case INANIMADO:
                nextId = proximoIdInanimado;
                proximoIdInanimado++;
                break;
            case FLORA:
                nextId = proximoIdFlora;
                proximoIdFlora++;
                break;
            case FAUNA:
                nextId = proximoIdFauna;
                proximoIdFauna++;
                break;
            default:
                throw new IllegalArgumentException("Tipo de elemento inválido");
        }
        return nextId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public static void resetIds() {
        proximoIdInanimado = 0;
        proximoIdFauna = 0;
        proximoIdFlora = 0;
    }

    public Area getArea() {
        return area;
    }

    public void setArea(Area area) {
        this.area = area;
    }

    public void setP1(double x, double y) {
        if (this.area == null) {
          return;
        }
        this.area = this.area.setP1(x, y);
    }

    public void setP2(double x, double y) {
        if (this.area == null)
            return;
        this.area = this.area.setP2(x, y);
    }


    public double getX1(){
        return area.x1();
    }

    public double getX2(){
        return area.x2();
    }

    public double getY1(){
        return area.y1();
    }

    public double getY2(){
        return area.y2();
    }


    public double getCX() {
        return (area.x1() + area.x2()) / 2.0;
    }

    public double getCY() {
        return (area.y1() + area.y2()) / 2.0;
    }

    public double getWidth() {
        return Math.abs(area.x1() - area.x2());
    }

    public double getHeight() {
        return Math.abs(area.y1() - area.y2());
    }

    public abstract Elemento getType();

    public ElementoBase clone() throws CloneNotSupportedException {
        return (ElementoBase) super.clone();
    }

    public String toString() {
        return String.format("%s-%d: (%.2f,%.2f) - (%.2f,%.2f)",
                getClass().getSimpleName(),getId(),getX1(),getY1(),getX2(),getY2());
    }



    private void writeObject(ObjectOutputStream out) throws IOException {
        out.defaultWriteObject();
        out.writeInt(proximoIdInanimado);
        out.writeInt(proximoIdFlora);
        out.writeInt(proximoIdFauna);
    }

    private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
        in.defaultReadObject();
        proximoIdInanimado = in.readInt();
        proximoIdFlora = in.readInt();
        proximoIdFauna = in.readInt();
    }


    //public String toString() {
        //return "Tipo: " + tipo + ", ID: " + id + ", Área: " + area;
    //}


    public boolean getSol(){
        return solAplicado;
    }

    public long tempoSol(){
        return tempoSolAplicado;
    }

    public void aplicarEfeitoSol() {
        solAplicado = true;
    }

    public void removerEfeitoSol() {
        solAplicado = false;
    }

    @Override
    public void changeSelected() {
        this.selected = !this.selected;
    }

    @Override
    public void setSelected(boolean selected) {
        this.selected = selected;
    }




}




class ElementoComparator implements Comparator<IElemento> {

    public int compare(IElemento elemento1, IElemento elemento2) {
        // Aqui você define a lógica de comparação entre os elementos
        // Por exemplo, você pode comparar com base em seus IDs
        return Integer.compare(elemento1.getId(), elemento2.getId());
    }
}