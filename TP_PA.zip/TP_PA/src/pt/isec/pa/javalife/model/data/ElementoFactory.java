package pt.isec.pa.javalife.model.data;

import pt.isec.pa.javalife.model.data.tiposelementos.Animal;
import pt.isec.pa.javalife.model.data.tiposelementos.Erva;
import pt.isec.pa.javalife.model.data.tiposelementos.Pedra;

public class ElementoFactory {

    public static IElemento criarElemento(ElementoBase.Elemento tipo){
        return switch (tipo){
            case INANIMADO -> new Pedra();
            case FLORA -> new Erva();
            case FAUNA -> new Animal();
        };
    }


}
