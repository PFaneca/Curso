package pt.isec.pa.javalife.model.data;

import pt.isec.pa.javalife.model.data.tiposelementos.Animal;

import java.io.Serializable;
import java.util.Random;
import java.util.Set;

public non-sealed abstract class Fauna extends ElementoBase implements IElementoComForca,IElementoComImagem, Serializable {
    private static final long serialVersionUID = 1L;

    private static final double MAX_FORCA = 100;
    private static final double MIN_FORCA = 0;
    private static final double FORCA_INICIAL = 50;
    private static final double FORCA_REPRODUCAO = 90;
    private static final double FORCA_MOVIMENTO = 0.5;
    private static final double FORCA_PERDIDA_POR_FLORA = 1;
    private static final double FORCA_CUSTO_REPRODUCAO = 25;
    private static final double FORCA_CUSTO_ATAQUE = 10;
    private static final double FORCA_MINIMA_REPRODUCAO = 50;
    private static final int TEMPO_REPRODUCAO = 10;
    private static final int DISTANCIA_REPRODUCAO = 5;
    private boolean isDead = false;
    private double forca, forcaMovimento;
    private double velocidade;
    private double direcao;
    private String imagem;
    private Ecossistema ecossistema;
    private int tempoProximo;



    public Fauna() {
        super(Elemento.FAUNA);
        this.forca = FORCA_INICIAL;
        this.forcaMovimento = FORCA_MOVIMENTO;
        this.velocidade = 10;
        this.direcao = new Random().nextInt(360);
        this.imagem = "Ovelha.png";
        ecossistema=null;
        tempoProximo=0;


    }


    @Override
    public double getForca() {
        return forca;
    }

    @Override
    public void setForca(double forca) {
        this.forca = Math.max(MIN_FORCA, Math.min(MAX_FORCA, forca));
    }

    @Override
    public String getImagem() {
        return imagem;
    }

    @Override
    public void setImagem(String imagem) {
        this.imagem = imagem;
    }

    public double getforcaMovimento() {
        return forcaMovimento;
    }

    public void setForcaMovimento(double forcaMovimento) {
        this.forcaMovimento = forcaMovimento;
    }

    public boolean isDead() {
        return isDead;
    }

    public double getvelocidade() {
        return velocidade;
    }

    public void setVelocidade(double velocidade) {
        this.velocidade = velocidade;
    }



    public void move(Ecossistema ecossistema) {
        if (isDead)
            return;
        // Calcular o deslocamento em x e y com base na velocidade e direção
        double deltaX = velocidade * Math.cos(Math.toRadians(direcao));
        double deltaY = -velocidade * Math.sin(Math.toRadians(direcao));

        // Atualizar as coordenadas com o deslocamento
        double novoX1 = getX1() + deltaX;
        double novoY1 = getY1() + deltaY;
        double novoX2 = getX2() + deltaX;
        double novoY2 = getY2() + deltaY;


        if (ecossistema.verificarSobreposicaoPedra(novoX1, novoY1, novoX2, novoY2)) {
            // Se houver sobreposição, definir uma nova direção aleatória
            direcao = new Random().nextInt(360);
        } else {
            // Atualizar as coordenadas se não houver sobreposição
            setP1(novoX1, novoY1);
            setP2(novoX2, novoY2);
            setForca(getForca() - FORCA_MOVIMENTO);
        }
    }


    public boolean procura_comida(Ecossistema ecossistema) {
        // Inicialize a distância mínima como um valor muito grande
        Flora floraMaisProxima = encontrarFloraMaisProxima(ecossistema);

        if (floraMaisProxima != null) {
            // Se encontrou uma flora próxima, mova-se em direção a ela
            moverParaFlora(floraMaisProxima, ecossistema);
            return false; // Ainda em processo de busca de comida
        } else if (getForca() < 80) {
            // Se não encontrou flora e a força está abaixo de 80, procurar fauna mais fraca
            Fauna faunaMaisFraca = encontrarFaunaMaisFraca(ecossistema);

            if (faunaMaisFraca != null) {
                moverParaFaunaFraca(faunaMaisFraca, ecossistema);
                return false; // Ainda em processo de busca de comida
            }
        }

        // Se encontrou alguma flora ou força maior que 80, não continuar a busca de comida
        return true;
    }



    private Flora encontrarFloraMaisProxima(Ecossistema ecossistema) {
        double distanciaMinima = Double.MAX_VALUE;
        Flora floraMaisProxima = null;

        double faunaX = (this.getX1() + this.getX2()) / 2;
        double faunaY = (this.getY1() + this.getY2()) / 2;

        for (Flora flora : ecossistema.getFloras()) {
            double floraX = (flora.getX1() + flora.getX2()) / 2;
            double floraY = (flora.getY1() + flora.getY2()) / 2;
            double distancia = calcularDistancia(faunaX, faunaY, floraX, floraY);

            if (distancia < distanciaMinima) {
                distanciaMinima = distancia;
                floraMaisProxima = flora;
            }
        }

        return floraMaisProxima;
    }

    private void moverParaFlora(Flora flora, Ecossistema ecossistema) {
        // Coordenadas da flora
        double floraX = (flora.getX1() + flora.getX2()) / 2;
        double floraY = (flora.getY1() + flora.getY2()) / 2;

        // Coordenadas da fauna atual
        double faunaX = (this.getX1() + this.getX2()) / 2;
        double faunaY = (this.getY1() + this.getY2()) / 2;

        // Calcular a direção da fauna em relação à flora
        direcao = calcularAngulo(faunaX, faunaY, floraX, floraY);

        // Calcular o deslocamento em x e y com base na velocidade e direção
        double deltaX = velocidade * Math.cos(Math.toRadians(direcao));
        double deltaY = velocidade * Math.sin(Math.toRadians(direcao));

        // Atualizar as coordenadas com o deslocamento
        double novoX1 = getX1() + deltaX;
        double novoY1 = getY1() + deltaY;
        double novoX2 = getX2() + deltaX;
        double novoY2 = getY2() + deltaY;

        // Verificar se houve sobreposição com pedras
        if (!ecossistema.verificarSobreposicaoPedra(novoX1, novoY1, novoX2, novoY2)) {
            // Atualizar as coordenadas se não houver sobreposição
            setP1(novoX1, novoY1);
            setP2(novoX2, novoY2);
            setForca(getForca() - FORCA_MOVIMENTO);
        }
        // Verificar sobreposição com flora

        else {
            // Se houver sobreposição, definir uma nova direção aleatória
            direcao = new Random().nextInt(360);
        }
        if (isSobrepostoComFlora(flora)) {
            alimentar(flora,ecossistema);
        }
    }

    private double calcularAngulo(double x1, double y1, double x2, double y2) {
        // Calcula a diferença entre as coordenadas x e y
        double dx = x2 - x1;
        double dy = y2 - y1;

        // Calcula o ângulo em radianos usando a função arco tangente (atan2)
        double anguloEmRadianos = Math.atan2(dy, dx);

        // Converte o ângulo de radianos para graus e garante que esteja no intervalo [0, 360)
        double anguloEmGraus = Math.toDegrees(anguloEmRadianos);
        return (anguloEmGraus + 360) % 360;
    }




    private void alimentar(Flora flora, Ecossistema ecossistema) {
        if (isSobrepostoComFlora(flora)) {
            // Adicionar força incrementalmente à fauna
            setForca(Math.min(getForca() + FORCA_PERDIDA_POR_FLORA, 100));
            // Reduzir a força da flora
            flora.setForca(Math.max(flora.getForca() - FORCA_PERDIDA_POR_FLORA, 0));


            if (flora.getForca() <= 0) {
                // Se a flora esgotar, removê-la do ecossistema
                ecossistema.remove(flora);
            }

            // Verificar se a força atingiu 100
            if (getForca() >= 100) {
                return; // Parar de alimentar e retornar ao movimento normal
            }


            // Se a força da fauna ainda estiver abaixo de 80 e a flora estiver esgotada, continuar procurando comida
            if (getForca() < 80) {
                procura_comida(ecossistema);
            }
        }
    }
    private boolean isSobrepostoComFlora(Flora flora) {
        return getArea().intersects(flora.getArea());
    }

    private double calcularDistancia(double x1, double y1, double x2, double y2) {
        return Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
    }





    private void moverParaFaunaFraca(Fauna fauna, Ecossistema ecossistema) {
        double faunaX = (fauna.getX1() + fauna.getX2()) / 2;
        double faunaY = (fauna.getY1() + fauna.getY2()) / 2;

        double thisFaunaX = (this.getX1() + this.getX2()) / 2;
        double thisFaunaY = (this.getY1() + this.getY2()) / 2;

        direcao = calcularAngulo(thisFaunaX, thisFaunaY, faunaX, faunaY);

        double deltaX = velocidade * Math.cos(Math.toRadians(direcao));
        double deltaY = velocidade * Math.sin(Math.toRadians(direcao));

        double novoX1 = getX1() + deltaX;
        double novoY1 = getY1() + deltaY;
        double novoX2 = getX2() + deltaX;
        double novoY2 = getY2() + deltaY;

        if (!ecossistema.verificarSobreposicaoPedra(novoX1, novoY1, novoX2, novoY2)) {
            setP1(novoX1, novoY1);
            setP2(novoX2, novoY2);
            setForca(getForca() - FORCA_MOVIMENTO);
        } else {
            direcao = new Random().nextInt(360);
        }

        if (isAdjacente(fauna)) {
            atacar(fauna,ecossistema);
        }

    }

    private Fauna encontrarFaunaMaisFraca(Ecossistema ecossistema) {
        Fauna faunaMaisFraca = null;
        double forcaMinima = Double.MAX_VALUE;

        for (Fauna fauna : ecossistema.getFaunas()) {
            if (fauna != this && fauna.getForca() < forcaMinima) {
                forcaMinima = fauna.getForca();
                faunaMaisFraca = fauna;
            }
        }

        return faunaMaisFraca;
    }

    private boolean isAdjacente(Fauna fauna) {
        double thisFaunaX = (this.getX1() + this.getX2()) / 2;
        double thisFaunaY = (this.getY1() + this.getY2()) / 2;

        double outraFaunaX = (fauna.getX1() + fauna.getX2()) / 2;
        double outraFaunaY = (fauna.getY1() + fauna.getY2()) / 2;

        double distancia = calcularDistancia(thisFaunaX, thisFaunaY, outraFaunaX, outraFaunaY);
        return distancia <= velocidade; // Considera adjacente se estiver a uma distância menor ou igual à velocidade de movimento
    }



    public void atacar(Fauna outraFauna,Ecossistema ecossistema){
        if(isDead || outraFauna.isDead())
            return;

        if (this.getForca() > 10) {
            setForca(getForca() - 10);
            outraFauna.setForca(outraFauna.getForca() + this.getForca());

            if (outraFauna.getForca() <= 0) {
                ecossistema.remove(outraFauna);
            }
        } else {
            outraFauna.setForca(outraFauna.getForca() + this.getForca());
            ecossistema.remove(this);
        }
    }



    //REPRODUCAO

    private Fauna encontrarFaunaMaisForte(Ecossistema ecossistema) {
        Fauna faunaMaisForte = null;
        double forcaMaxima = 0;

        for (Fauna fauna : ecossistema.getFaunas()) {
            if (fauna.getForca() > forcaMaxima) {
                forcaMaxima = fauna.getForca();
                faunaMaisForte = fauna;
            }
        }

        return faunaMaisForte;
    }


    private void moverParaFaunaForte(Fauna alvo, Ecossistema ecossistema) {
        // Coordenadas da fauna alvo
        double alvoX = (alvo.getX1() + alvo.getX2()) / 2;
        double alvoY = (alvo.getY1() + alvo.getY2()) / 2;

        // Coordenadas da fauna atual
        double faunaX = (this.getX1() + this.getX2()) / 2;
        double faunaY = (this.getY1() + this.getY2()) / 2;

        // Calcular a direção da fauna em relação ao alvo
         direcao = calcularAngulo(faunaX, faunaY, alvoX, alvoY);

        // Calcular o deslocamento em x e y com base na velocidade e direção
        double deltaX = velocidade * Math.cos(Math.toRadians(direcao));
        double deltaY = velocidade * Math.sin(Math.toRadians(direcao));

        // Atualizar as coordenadas com o deslocamento
        double novoX1 = getX1() + deltaX;
        double novoY1 = getY1() + deltaY;
        double novoX2 = getX2() + deltaX;
        double novoY2 = getY2() + deltaY;

        // Verificar se houve sobreposição com pedras
        if (!ecossistema.verificarSobreposicaoPedra(novoX1, novoY1, novoX2, novoY2)) {
            // Atualizar as coordenadas se não houver sobreposição
            setP1(novoX1, novoY1);
            setP2(novoX2, novoY2);
            setForca(getForca() - FORCA_MOVIMENTO);
        } else {
            // Se houver sobreposição, definir uma nova direção aleatória
            direcao = new Random().nextInt(360);
        }

        if(verificarReproducao(ecossistema,tempoProximo)){
            reproduzir(ecossistema);
            System.out.println("oi");
        }


    }

    private boolean estaProximo(Fauna outraFauna) {
        double x1 = (this.getX1() + this.getX2()) / 2;
        double y1 = (this.getY1() + this.getY2()) / 2;
        double x2 = (outraFauna.getX1() + outraFauna.getX2()) / 2;
        double y2 = (outraFauna.getY1() + outraFauna.getY2()) / 2;

        double distancia = calcularDistancia(x1, y1, x2, y2);
        System.out.println(distancia);
        return distancia < 10;
    }


    public void reproduzir(Ecossistema ecossistema){
        if (getForca() >= 25) {
            setForca(getForca() - FORCA_CUSTO_REPRODUCAO);

            Area novaPosicao = verificarPosicaoReproducao(ecossistema.getList());
            if (novaPosicao != null) {

                if (novaPosicao.x1() >= 0 && novaPosicao.x2() <= ecossistema.getLargura() && novaPosicao.y1() >= 0 && novaPosicao.y2() <= ecossistema.getComprimento()) {
                    ecossistema.setCurrentType(Elemento.FAUNA);
                    IElemento novaFauna = ecossistema.createElemento(novaPosicao.x1(), novaPosicao.y1());
                    ecossistema.finishCurrentFigure(novaPosicao.x2(), novaPosicao.y2());

                }else {
                    return;
                }
            }

        }

    }


    private boolean verificarReproducao(Ecossistema ecossistema, int unidadesDeTempo) {
        boolean reproduziu = false;
        boolean proximo = false;

        for (Fauna outraFauna : ecossistema.getFaunas()) {
            if (outraFauna != this && estaProximo(outraFauna)) {
                proximo = true;
                break;
            }
        }

        if (proximo) {
           // tempoProximo += unidadesDeTempo;

           // if (tempoProximo >= 10) {
            //    tempoProximo = 0;
                reproduziu = true;

           // }
        } else {
            tempoProximo = 0;
        }

        return reproduziu;
    }


    public Area verificarPosicaoReproducao(Set<IElemento> elementos) {
        Area[] posicoesAdjacentes = criarPosicoesAdjacentes();

        for (Area novaArea : posicoesAdjacentes) {
            boolean sobreposto = false;
            for (IElemento ele : elementos) {
                if (novaArea.isSobreposto(ele.getArea())) {
                    sobreposto = true;
                    break;
                }
            }
            if (!sobreposto) {
                return novaArea; // Encontrou uma posição livre
            }
        }

//        Area posicaoFloraMaisProxima = null;
//        double distanciaMinima = Double.MAX_VALUE;
//
//        for (IElemento elemento : elementos) {
//            if (elemento instanceof Flora) {
//                Flora flora = (Flora) elemento;
//                double floraX = (flora.getX1() + flora.getX2()) / 2;
//                double floraY = (flora.getY1() + flora.getY2()) / 2;
//                double x = (getX1() + getX2()) / 2;
//                double y = (getY1() + getY2()) / 2;
//                double distancia = calcularDistancia(x, y, floraX, floraY);
//
//                if (distancia < distanciaMinima) {
//                    distanciaMinima = distancia;
//                    posicaoFloraMaisProxima = new Area(floraX - (getX2() - getX1()) / 2, floraY - (getY2() - getY1()) / 2,
//                            floraX + (getX2() - getX1()) / 2, floraY + (getY2() - getY1()) / 2);
//                }
//            }
//        }

        return null;
    }

    public Area[] criarPosicoesAdjacentes() {
        double x1 = getX1();
        double y1 = getY1();
        double largura = getX2() - getX1();
        double altura = getY2() - getY1();

        Area[] posicoesAdjacentes = new Area[4];
        posicoesAdjacentes[0] = new Area(x1, y1 - altura, x1 + largura, y1); // Cima
        posicoesAdjacentes[1] = new Area(x1, y1 + altura, x1 + largura, y1 + 2 * altura); // Baixo
        posicoesAdjacentes[2] = new Area(x1 - largura, y1, x1, y1 + altura); // Esquerda
        posicoesAdjacentes[3] = new Area(x1 + largura, y1, x1 + 2 * largura, y1 + altura); // Direita

        return posicoesAdjacentes;
    }


    public boolean reproducao(Ecossistema ecossistema){
        Fauna faunaforte=encontrarFaunaMaisForte(ecossistema);
        if(faunaforte !=null){
            moverParaFaunaForte(faunaforte,ecossistema);
            verificarReproducao(ecossistema,tempoProximo);
            return false;
        }

        return true;

    }


    @Override
    public Elemento getType() {
        return Elemento.FAUNA;
    }

    public String toString() {
        return super.toString() + ", Forca: "+ forca + "PERDA: " + forcaMovimento;
    };

    public void setEcossistema(Ecossistema ecossistema) {
        this.ecossistema = ecossistema;
    }

    public Ecossistema getEcossistema() {
        return ecossistema;
    }


}

