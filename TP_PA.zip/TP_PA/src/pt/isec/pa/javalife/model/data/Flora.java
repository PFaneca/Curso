package pt.isec.pa.javalife.model.data;

import pt.isec.pa.javalife.model.data.tiposelementos.Erva;

import java.io.Serializable;
import java.util.Set;

public  non-sealed abstract class Flora extends ElementoBase implements IElementoComForca, Serializable {
    private static final long serialVersionUID = 1L;
    private static final double FORCA_MINIMA = 0;
    private static final double FORCA_MAXIMA = 100;
    private static final double FORCA_INICIAL = 50;
    private static final double CRESCIMENTO_FORCA = 0.5;
    private static final double FORCA_REPRODUCAO = 90;
    private static final int MAX_REPRODUCOES = 2;
    private static final double REDUCAO_FORCA_FLORA = 1; // Valor por omissão
    private static final double GANHO_FORCA_FAUNA = 1; // Valor por omissão

    private double forca,forcaPerdidaFloraSobreposta,forcaGanhaFaunaSobreposta;
    private int reproducoes;


    public Flora(){
        super(Elemento.FLORA);
        this.forca = FORCA_INICIAL; // Força inicial por omissão
        this.forcaPerdidaFloraSobreposta=REDUCAO_FORCA_FLORA;
        this.forcaGanhaFaunaSobreposta=GANHO_FORCA_FAUNA;
        this.reproducoes=0;
    }

    @Override
    public double getForca() {
        return forca;
    }

    @Override
    public void setForca(double forca) {
        this.forca = Math.max(FORCA_MINIMA, Math.min(FORCA_MAXIMA, forca));
    }



    public double getReducaoForcaFlora() {
        return forcaPerdidaFloraSobreposta;
    }

    public void setForcaPerdidaFloraSobreposta(double forcaPerdidaFloraSobreposta) {
        this.forcaPerdidaFloraSobreposta = forcaPerdidaFloraSobreposta;
    }

    public double getGanhoForcaFauna() {
        return forcaGanhaFaunaSobreposta;
    }

    public void setForcaGanhaFaunaSobreposta(double forcaGanhaFaunaSobreposta) {
        this.forcaGanhaFaunaSobreposta = forcaGanhaFaunaSobreposta;
    }

    public void aumentarForca(){
        if(forca <100){
            if (getSol()) {
                this.forca += 2; // Aumenta ao dobro da velocidade
            } else {
                setForca(forca + CRESCIMENTO_FORCA);
            }
        }

    }



    public boolean podeReproduzir(){
        return forca > FORCA_REPRODUCAO && reproducoes <= MAX_REPRODUCOES;
    }

    public Flora reproduzir(){
        if(podeReproduzir()){
            reproducoes++;
            setForca(60);
            return new Erva();
        }
        return null;

    }

    public void reduzirForcaPorFauna() {
        setForca(forca - REDUCAO_FORCA_FLORA);
    }


    @Override
    public Elemento getType() {
        return Elemento.FLORA;
    }

    public String toString() {
        return super.toString() + ", Forca: "+ forca + "Perda: " + forcaPerdidaFloraSobreposta;
    }


   public void aumentoforcaSol(){
       if(getSol()){
           this.forca+=2;
       }
    }

    public Area[] criarPosicoesAdjacentes() {
        double x1 = getX1();
        double y1 = getY1();
        double largura = getX2() - getX1();
        double altura = getY2() - getY1();

        Area[] posicoesAdjacentes = new Area[4];
        posicoesAdjacentes[0] = new Area(x1, y1 - altura, x1 + largura, y1); // Cima
        posicoesAdjacentes[1] = new Area(x1, y1 + altura, x1 + largura, y1 + 2 * altura); // Baixo
        posicoesAdjacentes[2] = new Area(x1 - largura, y1, x1, y1 + altura); // Esquerda
        posicoesAdjacentes[3] = new Area(x1 + largura, y1, x1 + 2 * largura, y1 + altura); // Direita

        return posicoesAdjacentes;
    }

    public Area verificarPosicaoReproducao(Set<IElemento> elementos) {
        Area[] posicoesAdjacentes = criarPosicoesAdjacentes();

        for (Area novaArea : posicoesAdjacentes) {
            boolean sobreposto = false;
            for (IElemento ele : elementos) {
                if (novaArea.isSobreposto(ele.getArea())) {
                    sobreposto = true;
                    break;
                }
            }
            if (!sobreposto) {
                return novaArea; // Encontrou uma posição livre
            }
        }

        return null; // Todas as posições estão ocupadas
    }

    public boolean podeReproduzir(Set<IElemento> elementos) {
        return verificarPosicaoReproducao(elementos) != null;
    }







}
