package pt.isec.pa.javalife.model.data;

import java.io.Serializable;

public sealed interface IElemento extends Serializable,Cloneable permits ElementoBase{
    int getId(); // retorna o identificador
    ElementoBase.Elemento getType(); // retorna o tipo
    Area getArea(); // retorna a área ocupada

    IElemento clone() throws CloneNotSupportedException;

    public boolean getSol();
    public long tempoSol();
    public void removerEfeitoSol();
    public void aplicarEfeitoSol();

    void changeSelected();
    void setSelected(boolean selected);


}
