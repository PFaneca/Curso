package pt.isec.pa.javalife.model.data;

import pt.isec.pa.javalife.model.data.Area;

import pt.isec.pa.javalife.model.data.ElementoBase;

public  non-sealed abstract class Inanimado extends ElementoBase {

    private static final long serialVersionUID = 1L;

    public Inanimado() {
        super(Elemento.INANIMADO);
    }

    @Override
    public Elemento getType() {
        return Elemento.INANIMADO;
    }

    @Override
    public String toString() {
        return super.toString();
    }

}
