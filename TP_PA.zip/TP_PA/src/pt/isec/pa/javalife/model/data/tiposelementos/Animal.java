package pt.isec.pa.javalife.model.data.tiposelementos;

import pt.isec.pa.javalife.model.data.Fauna;

public class Animal extends Fauna {

    public Animal(){

    }

    //public String toString(){
    //    return "Animal- " + super.toString();
    //}
}
