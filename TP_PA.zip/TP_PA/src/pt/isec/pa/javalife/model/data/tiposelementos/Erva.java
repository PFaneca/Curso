package pt.isec.pa.javalife.model.data.tiposelementos;

import pt.isec.pa.javalife.model.data.Flora;

public class Erva extends Flora {

    public Erva(){

    }


}
