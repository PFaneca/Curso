package pt.isec.pa.javalife.model.data.tiposelementos;

import pt.isec.pa.javalife.model.data.Inanimado;

public class Pedra extends Inanimado {

    public Pedra(){

    }


}
