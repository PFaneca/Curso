package pt.isec.pa.javalife.model.fsm;

import pt.isec.pa.javalife.model.data.Ecossistema;
import pt.isec.pa.javalife.model.data.Fauna;
import pt.isec.pa.javalife.model.data.tiposelementos.Animal;
import pt.isec.pa.javalife.model.fsm.states.NaturalState;
import pt.isec.pa.javalife.model.fsm.states.ProcuraComidaState;
import pt.isec.pa.javalife.model.fsm.states.ReproducaoState;

import java.io.Serializable;

public class FaunaContext implements Serializable {
    private static final long serialVersionUID = 1L;
    private IFaunaState atual;
    private Fauna data;
    private Ecossistema ecossistema;
    public FaunaContext(Ecossistema ecossistema){
        this.data = new Animal();
        this.ecossistema=ecossistema;
        this.atual= new NaturalState(this,data,ecossistema);
        //this.atual= new ProcuraComidaState(this,data,ecossistema);
        //this.atual=new ReproducaoState(this,data,ecossistema);
    }

    void changeState(IFaunaState novoEstado){
        atual=novoEstado;

    }

    public void move(Fauna data){
        atual.move(data,ecossistema);

    }

    public void procura_comida(Fauna data){
        atual.procura_comida(data);

    }

    public void feed(){
        atual.feed();
    }

    public boolean reproducao(){
        return atual.reproducao(data);
    }

    public void dead(){
        atual.dead();
    }

    public void evoluir(Fauna data){
        atual.evoluir(data);

    }


    //getters
    public double getForca(){
        return data.getForca();
    }


    public FaunaState getState(){
        return atual.getState();
    }
}
