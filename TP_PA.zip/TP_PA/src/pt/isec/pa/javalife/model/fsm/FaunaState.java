package pt.isec.pa.javalife.model.fsm;

import pt.isec.pa.javalife.model.data.Ecossistema;
import pt.isec.pa.javalife.model.data.Fauna;
import pt.isec.pa.javalife.model.fsm.states.NaturalState;
import pt.isec.pa.javalife.model.fsm.states.ProcuraComidaState;
import pt.isec.pa.javalife.model.fsm.states.ReproducaoState;


public enum
FaunaState {
    PROCURA_COMIDA, REPRODUCAO,NATURAL;

    Ecossistema ecossistema;

    public  IFaunaState getInstance(FaunaContext context, Fauna data){
        return switch (this){
            case NATURAL -> new NaturalState(context, data,ecossistema);
            case PROCURA_COMIDA ->new ProcuraComidaState(context, data,ecossistema);
            case REPRODUCAO -> new ReproducaoState(context,data,ecossistema);
        };
    }
}
