package pt.isec.pa.javalife.model.fsm;

import pt.isec.pa.javalife.model.data.Ecossistema;
import pt.isec.pa.javalife.model.data.Fauna;

public class FaunaStateAdapter implements IFaunaState{

    protected FaunaContext context;
    protected Fauna data;
    Ecossistema ecossistema;


    public FaunaStateAdapter(FaunaContext context,Fauna data,Ecossistema ecossistema){
        this.context=context;
        this.data=data;
        this.ecossistema=ecossistema;

    }

    protected void changeState(FaunaState novoEstado){
        context.changeState(novoEstado.getInstance(context,data));
    }

    @Override
    public void move(Fauna data,Ecossistema ecossistema) {

    }

    @Override
    public boolean procura_comida(Fauna data) {
        return false;
    }

    @Override
    public void feed() {

    }

    @Override
    public void attack() {

    }

    @Override
    public boolean reproducao(Fauna data) {
        return false;
    }

    @Override
    public void dead() {

    }

    @Override
    public boolean evoluir(Fauna data) {
        return false;
    }

    @Override
    public FaunaState getState() {
        return null;
    }
}
