package pt.isec.pa.javalife.model.fsm;

import pt.isec.pa.javalife.model.data.Ecossistema;
import pt.isec.pa.javalife.model.data.Fauna;

import java.io.Serializable;

public interface IFaunaState extends Serializable {

    void move(Fauna data,Ecossistema ecossistema);

    boolean procura_comida(Fauna data);

    void feed();

    void attack();

    boolean reproducao(Fauna data);

    void dead();

    boolean evoluir(Fauna data);

    FaunaState getState();


}
