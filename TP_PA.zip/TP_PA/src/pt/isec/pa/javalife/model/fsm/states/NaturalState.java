package pt.isec.pa.javalife.model.fsm.states;

import pt.isec.pa.javalife.model.data.Ecossistema;
import pt.isec.pa.javalife.model.data.Fauna;
import pt.isec.pa.javalife.model.fsm.FaunaContext;
import pt.isec.pa.javalife.model.fsm.FaunaState;
import pt.isec.pa.javalife.model.fsm.FaunaStateAdapter;

public class NaturalState extends FaunaStateAdapter {
    Ecossistema ecossistema;

    public NaturalState(FaunaContext context, Fauna data,Ecossistema ecossistema) {
        super(context, data,ecossistema);
        this.ecossistema=ecossistema;
    }
    @Override
    public boolean evoluir(Fauna data){
        move(data,ecossistema);
        //if(data.getForca()<35)
         //   changeState(FaunaState.PROCURA_COMIDA);


        return true;
    }

    @Override
    public void move(Fauna data,Ecossistema ecossistema) {
        data.move(ecossistema);
    }

    @Override


    public FaunaState getState(){
        return FaunaState.NATURAL;
    }
}
