package pt.isec.pa.javalife.model.fsm.states;

import pt.isec.pa.javalife.model.data.Ecossistema;
import pt.isec.pa.javalife.model.data.Fauna;
import pt.isec.pa.javalife.model.fsm.FaunaContext;
import pt.isec.pa.javalife.model.fsm.FaunaState;
import pt.isec.pa.javalife.model.fsm.FaunaStateAdapter;

public class ProcuraComidaState extends FaunaStateAdapter {
    Ecossistema ecossistema;
    public ProcuraComidaState(FaunaContext context, Fauna data,Ecossistema ecossistema) {
        super(context, data,ecossistema);
        this.ecossistema=ecossistema;
    }

    @Override
    public boolean evoluir(Fauna data) {
        procura_comida(data);
        if(data.getForca()>50){
            changeState(FaunaState.REPRODUCAO);
        }
        return true;
    }


    @Override
    public boolean procura_comida(Fauna data) {
        data.procura_comida(ecossistema);
        return true;
    }

    @Override
    public FaunaState getState() {
        return FaunaState.PROCURA_COMIDA;
    }
}
