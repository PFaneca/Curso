package pt.isec.pa.javalife.model.fsm.states;

import pt.isec.pa.javalife.model.data.Ecossistema;
import pt.isec.pa.javalife.model.data.Fauna;
import pt.isec.pa.javalife.model.fsm.FaunaContext;
import pt.isec.pa.javalife.model.fsm.FaunaState;
import pt.isec.pa.javalife.model.fsm.FaunaStateAdapter;

public class ReproducaoState extends FaunaStateAdapter {
    Ecossistema ecossistema;
    public ReproducaoState(FaunaContext context, Fauna data, Ecossistema ecossistema) {
        super(context, data,ecossistema);
        this.ecossistema=ecossistema;
    }

    @Override
    public boolean evoluir(Fauna data) {
        reproducao(data);
        return true;
    }

    @Override
    public boolean reproducao(Fauna data) {
        data.reproducao(ecossistema);
        return true;
    }

    @Override
    public FaunaState getState() {
        return FaunaState.REPRODUCAO;
    }
}
