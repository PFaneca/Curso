package pt.isec.pa.javalife.model.gameengine;

public enum GameEngineState {
    READY, RUNNING, PAUSED
}
