package pt.isec.pa.javalife.ui.gui;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Modality;
import javafx.stage.Stage;
import pt.isec.pa.javalife.model.EcossistemaManager;
import pt.isec.pa.javalife.model.data.*;
import pt.isec.pa.javalife.model.data.tiposelementos.Pedra;
import pt.isec.pa.javalife.ui.gui.resources.ImageManager;
import pt.isec.pa.javalife.ui.gui.resources.SoundManager;

public class EcossistemaArea extends Canvas {

    EcossistemaManager model;

    public EcossistemaArea(EcossistemaManager model){
        super(500,500);
        this.model=model;
        registerHandlers();
        update();
    }

    public void registerHandlers(){
        model.addPropertyChangeListener(EcossistemaManager.PROP_FIGURES,evt->update());

        this.setOnMousePressed(mouseEvent -> {
            if (model.getCurrentType() != null) {
                model.createElemento(mouseEvent.getX(), mouseEvent.getY());
            } else {
                 model.selecionarElemento(mouseEvent.getX(), mouseEvent.getY());
            }
        });
        this.setOnMouseDragged(mouseEvent -> model.updateCurrentFigure(mouseEvent.getX(), mouseEvent.getY()));
        this.setOnMouseReleased(mouseEvent -> model.finishCurrentFigure(mouseEvent.getX(), mouseEvent.getY()));

    }

    public void update(){
        GraphicsContext gc = this.getGraphicsContext2D();
        clearScreen(gc);
        model.getList().forEach( elemento-> drawFigure(gc,(ElementoBase) elemento));
        drawFigure(gc,model.getCurrentFigure());
        //SoundManager.play("Ovelha.mp3");

    }

    private void clearScreen(GraphicsContext gc) {
        gc.setFill(Color.LIGHTYELLOW);
        gc.fillRect(0,0,getWidth(),getHeight());
    }

    private void drawFigure(GraphicsContext gc, ElementoBase elemento) {
        if (elemento == null) return;
        Color color;
        switch (elemento.getType()) {
            case INANIMADO -> color = Color.GRAY; // Cor cinza para INANIMADO
            //case FLORA -> color = Color.GREEN; // Cor verde para FLORA

            default -> color = Color.RED; // Cor padrão se o tipo não for identificado
        }

        gc.setFill(color);
        gc.setLineWidth(3);
        switch (elemento.getType()){
            case INANIMADO ->{

                gc.fillRect(elemento.getX1(),elemento.getY1(),elemento.getWidth(),elemento.getHeight());
                gc.setStroke(color.darker());
                gc.strokeRect(elemento.getX1(),elemento.getY1(),elemento.getWidth(),elemento.getHeight());

            }
            case FLORA -> {
                Flora flora = (Flora) elemento;
                Color colorF = Color.GREEN;
                double transparency = (flora.getForca() / 100.0);
                Color colorWithOpacity = colorF.deriveColor(0, 1, 1, transparency);
                gc.setFill(colorWithOpacity);
                gc.fillRect(elemento.getX1(),elemento.getY1(),elemento.getWidth(),elemento.getHeight());
                gc.setStroke(colorF.darker());
                gc.strokeRect(elemento.getX1(),elemento.getY1(),elemento.getWidth(),elemento.getHeight());
            }

            case FAUNA -> {
                if (elemento instanceof Fauna) {
                    Fauna fauna = (Fauna) elemento;
                    Image image = ImageManager.getImage(fauna.getImagem());
                    if (image != null) {
                        gc.drawImage(image, elemento.getX1(), elemento.getY1(), elemento.getWidth(), elemento.getHeight());

                    }
                }
            }
        }
    }

    public void updateSize(double newWidth, double newHeight) {
        setWidth(newWidth);
        setHeight(newHeight);
        update();
    }


}
