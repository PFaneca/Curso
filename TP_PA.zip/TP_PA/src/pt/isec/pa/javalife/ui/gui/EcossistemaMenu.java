package pt.isec.pa.javalife.ui.gui;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import pt.isec.pa.javalife.model.EcossistemaManager;
import pt.isec.pa.javalife.model.data.*;
import pt.isec.pa.javalife.model.gameengine.GameEngine;
import pt.isec.pa.javalife.model.gameengine.GameEngineState;

import java.io.File;

public class EcossistemaMenu extends MenuBar {

    private EcossistemaManager ecossistema;
    private GameEngine gameEngine;
    private static final int TOGGLE_SIZE = 30;
    private static final int TOGGLE_WIDTH = 80;
    private static final int TOGGLE_IMG_SIZE = TOGGLE_SIZE-10;
    private long tempoInicial = 250;


    private Menu menuFicheiro,menuEcossistema,menuSimulacao,menuEventos;
    private MenuItem criarMenuFicheiro,abrirMenuFicheiro,gravarMenuFicheiro,exportarMenuFicheiro,importarMenuFicheiro,sairMenuFicheiro;
    private MenuItem ConfiguracoesEcossistema,AddInanimado,AddFlora,AddFauna,EditElemento,EliminarElemento,Undo,Redo;
    private MenuItem ConfiguracaoSimulacao,ExecutarParar,PausarContinuar,GravarSnap,RestaurarSnap;
    private MenuItem AplicarSol,AplicarHerbicida,InjetarForca;


    public EcossistemaMenu(EcossistemaManager ecossistema,GameEngine gameEngine){
        this.ecossistema=ecossistema;
        this.gameEngine=gameEngine;
        createViews();
        registerHandlers();
        update();

    }

    private void createViews(){

        // Menu suspenso dentro do botão Ficheiro
         menuFicheiro = new Menu("Ficheiro");
         criarMenuFicheiro = new MenuItem("Criar");
         abrirMenuFicheiro = new MenuItem("Abrir");
         gravarMenuFicheiro = new MenuItem("Gravar");
         exportarMenuFicheiro = new MenuItem("Exportar");
         importarMenuFicheiro = new MenuItem("Importar");
         sairMenuFicheiro = new MenuItem("Sair");

        // Adicionando as opções de menu ao menu suspenso
        menuFicheiro.getItems().addAll(criarMenuFicheiro, abrirMenuFicheiro, gravarMenuFicheiro,
                exportarMenuFicheiro, importarMenuFicheiro, sairMenuFicheiro);



        menuEcossistema= new Menu("Ecossistema");
        ConfiguracoesEcossistema = new MenuItem("Configurações");
        AddInanimado = new MenuItem("Adicionar Inanimado");
        AddFlora = new MenuItem("Adicionar Flora");
        AddFauna = new MenuItem("Adicionar Fauna");
        EditElemento = new MenuItem("Editar Elemento");
        EliminarElemento = new MenuItem("Eliminar Elemento");
        Undo = new MenuItem("Undo");
        Redo = new MenuItem("Redo");

        menuEcossistema.getItems().addAll(ConfiguracoesEcossistema,AddInanimado,AddFlora,AddFauna,EditElemento,EliminarElemento,Undo,Redo);



        menuSimulacao = new Menu("Simulacao");
        ConfiguracaoSimulacao = new MenuItem("Configurar");
        ExecutarParar = new MenuItem("Executar");

        PausarContinuar = new MenuItem("Pausar");

        GravarSnap = new MenuItem("Gravar snapshhot");
        RestaurarSnap = new MenuItem("Restaurar snapshot");

        menuSimulacao.getItems().addAll(ConfiguracaoSimulacao,ExecutarParar,PausarContinuar,GravarSnap,RestaurarSnap);


        menuEventos = new Menu("Eventos");
        AplicarSol = new MenuItem("Aplicar Sol");
        AplicarHerbicida = new MenuItem("Aplicar Herbicida");
        InjetarForca = new MenuItem("Injetar Força");

        menuEventos.getItems().addAll(AplicarSol,AplicarHerbicida,InjetarForca);


        this.getMenus().addAll(menuFicheiro,menuEcossistema,menuSimulacao,menuEventos);

    }

    private void registerHandlers() {

        AddInanimado.setOnAction(actionEvent -> ecossistema.setCurrentType(ElementoBase.Elemento.INANIMADO));
        AddFlora.setOnAction(actionEvent -> ecossistema.setCurrentType(ElementoBase.Elemento.FLORA));
        AddFauna.setOnAction(actionEvent -> ecossistema.setCurrentType(ElementoBase.Elemento.FAUNA));


        sairMenuFicheiro.setOnAction(actionEvent -> {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Sair da Simulação");
            alert.setHeaderText(null);
            alert.setContentText("Deseja gravar a simulação antes de sair?");

            // Adiciona botões de ação no diálogo
            ButtonType gravarButton = new ButtonType("Gravar");
            ButtonType sairSemGravarButton = new ButtonType("Sair sem Gravar");
            ButtonType cancelarButton = new ButtonType("Cancelar", ButtonBar.ButtonData.CANCEL_CLOSE);
            alert.getButtonTypes().setAll(gravarButton, sairSemGravarButton, cancelarButton);

            // Exibe o diálogo e aguarda a resposta do usuário
            alert.showAndWait().ifPresent(buttonType -> {
                if (buttonType == gravarButton) {
                    FileChooser fileChooser = new FileChooser();
                    fileChooser.setTitle("Salvar Simulação");
                    fileChooser.getExtensionFilters().addAll(
                            new FileChooser.ExtensionFilter("Ecossistema (*.dat)", "*.dat"),
                            new FileChooser.ExtensionFilter("All", "*.*")
                    );
                    File selectedFile = fileChooser.showSaveDialog(getScene().getWindow());

                    // Se o usuário selecionar um arquivo, salve a simulação
                    if (selectedFile != null) {
                        ecossistema.save(selectedFile);
                    }
                } else if (buttonType == sairSemGravarButton) {
                    // Fecha a janela da simulação sem salvar, se o usuário escolher
                    Stage stage = (Stage) this.getScene().getWindow();
                    stage.close();
                }
                // Se o botão pressionado for "Cancelar", não faça nada
            });
        });


        criarMenuFicheiro.setOnAction(e->{
            ecossistema.clearAll();

        });

        gravarMenuFicheiro.setOnAction(e->{
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("File save...");
            fileChooser.setInitialDirectory(new File("."));
            fileChooser.getExtensionFilters().addAll(
                    new FileChooser.ExtensionFilter("Ecossistema (*.dat)", "*.dat"),
                    new FileChooser.ExtensionFilter("All", "*.*")
            );
            File hFile = fileChooser.showSaveDialog(this.getScene().getWindow());
            if (hFile != null) {
                ecossistema.save(hFile);
            }
        });

        abrirMenuFicheiro.setOnAction(e->{
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("File open...");
            fileChooser.setInitialDirectory(new File("."));
            fileChooser.getExtensionFilters().addAll(
                    new FileChooser.ExtensionFilter("Ecossistema (*.dat)", "*.dat"),
                    new FileChooser.ExtensionFilter("All", "*.*")
            );
            File hFile = fileChooser.showOpenDialog(this.getScene().getWindow());
            if (hFile != null) {
                ecossistema.load(hFile);
            }

        });

        exportarMenuFicheiro.setOnAction(e->{
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Exportar Simulação para CSV");
            fileChooser.getExtensionFilters().addAll(
                    new FileChooser.ExtensionFilter("Arquivo (*.csv)", "*.csv")
            );
            File selectedFile = fileChooser.showSaveDialog(getScene().getWindow());

            if (selectedFile != null) {
                ecossistema.exportar(selectedFile);
            }
        });


        importarMenuFicheiro.setOnAction(e->{
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Importar Arquivo CSV...");
            fileChooser.setInitialDirectory(new File("."));
            fileChooser.getExtensionFilters().addAll(
                    new FileChooser.ExtensionFilter("Arquivo (*.csv)", "*.csv"),
                    new FileChooser.ExtensionFilter("All", "*.*")
            );
            File hFile = fileChooser.showOpenDialog(this.getScene().getWindow());
            if (hFile != null) {
                ecossistema.importar(hFile);
            }
        });


        //ECOSSISTEMA
        ConfiguracoesEcossistema.setOnAction(e->{
            ConfigEcossistema();
        });

        EliminarElemento.setOnAction(e->{
            if (gameEngine.getCurrentState() == GameEngineState.PAUSED || gameEngine.getCurrentState() == GameEngineState.READY) {
                ecossistema.eliminarElemento();
            }

        });

        EditElemento.setOnAction(e->{
            if (gameEngine.getCurrentState() == GameEngineState.PAUSED || gameEngine.getCurrentState() == GameEngineState.READY) {
                edicao();
            }
        });


        Undo.setOnAction(e->{
            if (gameEngine.getCurrentState() == GameEngineState.PAUSED || gameEngine.getCurrentState() == GameEngineState.READY) {
                ecossistema.undo();
            }
        });

        Redo.setOnAction(e->{
            if (gameEngine.getCurrentState() == GameEngineState.PAUSED || gameEngine.getCurrentState() == GameEngineState.READY) {
                ecossistema.redo();
            }
        });



        //SIMULACAO
        GravarSnap.setOnAction(e->{
            ecossistema.saveSnapshot();
        });

        RestaurarSnap.setOnAction(e->{
            ecossistema.restoreSnapshot();
        });

        ConfiguracaoSimulacao.setOnAction(e->{
            if (gameEngine.getCurrentState() == GameEngineState.PAUSED || gameEngine.getCurrentState() == GameEngineState.READY) {
                showConfiguracaoDialog();
            }

        });

        ExecutarParar.setOnAction(e->{
            if (ExecutarParar.getText().equals("Executar")) {
                gameEngine.start(tempoInicial); // Inicia a simulação com intervalo de 250ms
                ExecutarParar.setText("Parar");
            } else {
                gameEngine.stop();
                //ecossistema.reset(); // Reseta o estado da simulação
                ExecutarParar.setText("Executar");
            }
        });

        PausarContinuar.setOnAction(e -> {
            if (PausarContinuar.getText().equals("Pausar")) {
                gameEngine.pause();
                PausarContinuar.setText("Continuar");
            } else {
                gameEngine.resume();
                PausarContinuar.setText("Pausar");
            }
        });


        //EVENTOS
        AplicarSol.setOnAction(e->{
            ecossistema.efeitoSol();
        });

        AplicarHerbicida.setOnAction(e->{
            ecossistema.eliminarcomHerbicida();
        });

        InjetarForca.setOnAction(e->{
            ecossistema.injetarForca();
        });

    }

    private void update() {

    }

    public void edicao(){
        ElementoBase elemento=ecossistema.getSelecionado();
        if (elemento == null) return;

        if (elemento instanceof Flora) {
            editarFlora((Flora) elemento);
        } else if (elemento instanceof Inanimado) {
            editarInanimado((Inanimado) elemento);
        }
        else if(elemento instanceof Fauna){
            editarFauna((Fauna) elemento);
        }

    }

    private void editarInanimado(Inanimado elementoBase) {
        Stage dlg = new Stage();
        if (elementoBase == null)
            return;

        TextField x1Field = new TextField(Double.toString(elementoBase.getX1()));
        TextField y1Field = new TextField(Double.toString(elementoBase.getY1()));
        TextField x2Field = new TextField(Double.toString(elementoBase.getX2()));
        TextField y2Field = new TextField(Double.toString(elementoBase.getY2()));

        Button changeBtn = new Button("Ok");
        changeBtn.setOnAction(evt->{
            try {

                Area novaArea = new Area(Double.parseDouble(x1Field.getText()), Double.parseDouble(x2Field.getText()),
                        Double.parseDouble(y1Field.getText()), Double.parseDouble(y2Field.getText()));

                // Atualiza a área do elemento
               ecossistema.alterarArea(elementoBase,novaArea );

            } catch (NumberFormatException e) {
                System.out.println("Por favor, insira valores válidos.");
                return;
            }


            dlg.close();
        });
        VBox rootPane = new VBox(
                new Label("X1:"), x1Field,
                new Label("Y1:"), y1Field,
                new Label("X2:"), x2Field,
                new Label("Y2:"), y2Field,
                changeBtn
        );
        rootPane.setAlignment(Pos.CENTER);
        Scene scene = new Scene(rootPane, 300, 400);
        dlg.setScene(scene);
        dlg.initModality(Modality.APPLICATION_MODAL);
        dlg.initOwner(this.getScene().getWindow());
        dlg.setAlwaysOnTop(true);
        dlg.showAndWait();

    }

    public void editarFlora(Flora elementoBase){
        Stage dlg = new Stage();
        if (elementoBase == null)
            return;


        TextField x1Field = new TextField(Double.toString(elementoBase.getX1()));
        TextField y1Field = new TextField(Double.toString(elementoBase.getY1()));
        TextField x2Field = new TextField(Double.toString(elementoBase.getX2()));
        TextField y2Field = new TextField(Double.toString(elementoBase.getY2()));
        TextField forca = new TextField(Double.toString(elementoBase.getForca()));
        TextField perdaforca = new TextField(Double.toString(elementoBase.getReducaoForcaFlora()));
        //TextField ganhoforca = new TextField(Double.toString(elementoBase.getGanhoForcaFauna()));

        Button changeBtn = new Button("Ok");
        changeBtn.setOnAction(evt->{
            try {

                Area novaArea = new Area(Double.parseDouble(x1Field.getText()), Double.parseDouble(x2Field.getText()),
                        Double.parseDouble(y1Field.getText()), Double.parseDouble(y2Field.getText()));


                ecossistema.alterarForca(elementoBase,Double.parseDouble(forca.getText()));

                ecossistema.alterarArea(elementoBase,novaArea);

                ecossistema.alterarForcaPerdidaFlora(elementoBase,Double.parseDouble(perdaforca.getText()));


            } catch (NumberFormatException e) {
                System.out.println("Por favor, insira valores válidos.");
                return;
            }

            dlg.close();
        });
        VBox rootPane = new VBox(
                new Label("X1:"), x1Field,
                new Label("Y1:"), y1Field,
                new Label("X2:"), x2Field,
                new Label("Y2:"), y2Field,
                new Label("Força:"), forca,
                new Label("Perda de Força:"), perdaforca,
                changeBtn
        );
        rootPane.setAlignment(Pos.CENTER);
        Scene scene = new Scene(rootPane, 300, 400);
        dlg.setScene(scene);
        dlg.initModality(Modality.APPLICATION_MODAL);
        dlg.initOwner(this.getScene().getWindow());
        dlg.setAlwaysOnTop(true);
        dlg.showAndWait();

    }

    void editarFauna(Fauna elementoBase){
        Stage dlg = new Stage();
        if (elementoBase == null)
            return;


        TextField x1Field = new TextField(Double.toString(elementoBase.getX1()));
        TextField y1Field = new TextField(Double.toString(elementoBase.getY1()));
        TextField x2Field = new TextField(Double.toString(elementoBase.getX2()));
        TextField y2Field = new TextField(Double.toString(elementoBase.getY2()));
        TextField forca = new TextField(Double.toString(elementoBase.getForca()));
        TextField perdaMovimento = new TextField(Double.toString(elementoBase.getforcaMovimento()));


        Button changeBtn = new Button("Ok");
        changeBtn.setOnAction(evt->{
            try {

                Area novaArea = new Area(Double.parseDouble(x1Field.getText()), Double.parseDouble(x2Field.getText()),
                        Double.parseDouble(y1Field.getText()), Double.parseDouble(y2Field.getText()));


                ecossistema.alterarArea(elementoBase,novaArea );

                ecossistema.alterarForca(elementoBase,Double.parseDouble(forca.getText()));

                ecossistema.alterarForcaMovimento(elementoBase,Double.parseDouble(perdaMovimento.getText()));


            } catch (NumberFormatException e) {
                System.out.println("Por favor, insira valores válidos.");
                return;
            }


            dlg.close();
        });
        VBox rootPane = new VBox(
                new Label("X1:"), x1Field,
                new Label("Y1:"), y1Field,
                new Label("X2:"), x2Field,
                new Label("Y2:"), y2Field,
                new Label("Força:"), forca,
                new Label("Perda Movimento:"), perdaMovimento,
                changeBtn
        );
        rootPane.setAlignment(Pos.CENTER);
        Scene scene = new Scene(rootPane, 300, 400);
        dlg.setScene(scene);
        dlg.initModality(Modality.APPLICATION_MODAL);
        dlg.initOwner(this.getScene().getWindow());
        dlg.setAlwaysOnTop(true);
        dlg.showAndWait();



    }


    private void showConfiguracaoDialog() {
        Stage dialogStage = new Stage();
        dialogStage.setTitle("Configurações do Ecossistema");

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(20));
        grid.setHgap(10);
        grid.setVgap(10);

        Label labelTempo = new Label("Unidade de Tempo:");
        TextField tempoField = new TextField();

        Label labelLargura = new Label("Largura:");
        TextField larguraField = new TextField();

        Label labelAltura = new Label("Altura:");
        TextField alturaField = new TextField();

        Button okButton = new Button("OK");
        Button cancelButton = new Button("Cancelar");

        HBox buttonBox = new HBox(10, okButton, cancelButton);
        buttonBox.setAlignment(Pos.CENTER_RIGHT);

        grid.add(labelTempo, 0, 0);
        grid.add(tempoField, 1, 0);
        grid.add(labelLargura, 0, 1);
        grid.add(larguraField, 1, 1);
        grid.add(labelAltura, 0, 2);
        grid.add(alturaField, 1, 2);
        grid.add(buttonBox, 1, 3);

        Scene scene = new Scene(grid, 400, 200);
        dialogStage.setScene(scene);

        // Define ação para o botão OK
        okButton.setOnAction(e -> {
            try {
                double tempo = Double.parseDouble(tempoField.getText());
                double largura = Double.parseDouble(larguraField.getText());
                double altura = Double.parseDouble(alturaField.getText());
                tempoInicial = (long) tempo;

                //ecossistema.setDimensoesSimulacao(largura, altura);
                dialogStage.close();
            } catch (NumberFormatException ex) {
                ex.printStackTrace();
                // Mostrar mensagem de erro para o usuário
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Erro de Formato");
                alert.setHeaderText("Formato inválido");
                alert.setContentText("Por favor, insira valores numéricos válidos.");
                alert.showAndWait();
            }
        });

        // Define ação para o botão Cancelar
        cancelButton.setOnAction(e -> dialogStage.close());

        dialogStage.showAndWait();
    }



    private void ConfigEcossistema() {

        Stage dialogStage = new Stage();
        dialogStage.setTitle("Tamanho Inicial da Janela");

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(20));
        grid.setHgap(10);
        grid.setVgap(10);

        Label comprimnetoLabel = new Label("Comprimento:");
        TextField comprimentoField = new TextField();
        Label larguraLabel = new Label("Largura:");
        TextField larguraField = new TextField();
        Button okButton = new Button("OK");

        grid.add(comprimnetoLabel, 0, 0);
        grid.add(comprimentoField, 1, 0);
        grid.add(larguraLabel, 0, 1);
        grid.add(larguraField, 1, 1);
        grid.add(okButton, 0, 2, 2, 1);

        okButton.setOnAction(e -> {
            try {
                ecossistema.setLargura( Integer.parseInt(comprimentoField.getText()));
                ecossistema.setComprimento(Integer.parseInt(larguraField.getText()));
                dialogStage.close();
            } catch (NumberFormatException ex) {
                ex.printStackTrace();
                // Tratamento de erro se os valores inseridos não forem números
            }
        });

        Scene scene = new Scene(grid, 250, 150);
        dialogStage.setScene(scene);
        dialogStage.showAndWait();

    }



}
