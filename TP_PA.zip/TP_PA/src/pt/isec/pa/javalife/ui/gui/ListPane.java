package pt.isec.pa.javalife.ui.gui;

import javafx.application.Platform;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import pt.isec.pa.javalife.model.EcossistemaManager;
import pt.isec.pa.javalife.model.data.*;

import javafx.scene.control.*;

import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.Scene;


import javafx.stage.Modality;

public class ListPane extends ListView<IElemento> {

    private EcossistemaManager ecossistema;

    public ListPane(EcossistemaManager ecossistema) {
        this.ecossistema = ecossistema;
        createViews();
        registerHandlers();
        update();
    }

    private void createViews() {

    }

    private void registerHandlers(){
        ecossistema.addPropertyChangeListener(EcossistemaManager.PROP_FIGURES,
                evt-> Platform.runLater(()->update()));

    }

    private void update(){
        this.getItems().clear();
        this.getItems().addAll(ecossistema.getList());
    }

}

