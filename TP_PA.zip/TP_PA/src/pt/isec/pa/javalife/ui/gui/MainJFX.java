package pt.isec.pa.javalife.ui.gui;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import pt.isec.pa.javalife.model.EcossistemaManager;
import pt.isec.pa.javalife.model.data.ElementoBase;
import pt.isec.pa.javalife.model.data.tiposelementos.Pedra;
import pt.isec.pa.javalife.model.gameengine.GameEngine;

public class MainJFX extends Application {

    private EcossistemaManager manager;
    private GameEngine gameEngine;
    private int comprimento,largura;

    @Override
    public void init() throws Exception {

        super.init();
        Platform.runLater(() -> {
            int[] size = ConfigEcossistema();
            synchronized (this) {
                comprimento = size[0];
                largura = size[1];
                this.notify();  // Notify the waiting init thread to proceed
            }
        });

        // Wait until the configuration is done
        synchronized (this) {
            this.wait();
        }

        manager=new EcossistemaManager(comprimento,largura);
        gameEngine=new GameEngine();
        gameEngine.registerClient(manager);

    }

    @Override
    public void start(Stage stage) throws Exception {
        createOneStage(stage);
        createListStage(stage.getX()+stage.getWidth(),stage.getY());
        stage.setResizable(false);
    }

    private int[] ConfigEcossistema() {
        Stage dialogStage = new Stage();
        dialogStage.setTitle("Tamanho do Ecossistema");

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(20));
        grid.setHgap(10);
        grid.setVgap(10);

        Label comprimentoLabel = new Label("Comprimento:");
        TextField comprimentoField = new TextField();
        Label larguraLabel = new Label("Largura:");
        TextField larguraField = new TextField();
        Button okButton = new Button("OK");

        grid.add(comprimentoLabel, 0, 0);
        grid.add(comprimentoField, 1, 0);
        grid.add(larguraLabel, 0, 1);
        grid.add(larguraField, 1, 1);
        grid.add(okButton, 0, 2, 2, 1);

        final int[] size = new int[2];

        okButton.setOnAction(e -> {
            try {
                String comprimentoText = comprimentoField.getText();
                String larguraText = larguraField.getText();

                // Check if the fields are not empty and contain valid numbers
                if (comprimentoText.isEmpty() || larguraText.isEmpty()) {
                    showAlert("Erro", "Por favor, insira valores em ambos os campos.");
                } else {
                    size[0] = Integer.parseInt(comprimentoText);
                    size[1] = Integer.parseInt(larguraText);

                    // Additional validation for positive numbers
                    if (size[0] <= 0 || size[1] <= 0) {
                        showAlert("Erro", "Por favor, insira valores positivos.");
                    } else {
                        dialogStage.close();
                    }
                }
            } catch (NumberFormatException ex) {
                showAlert("Erro", "Por favor, insira números válidos.");
            }
        });

        Scene scene = new Scene(grid, 400, 200);
        dialogStage.setScene(scene);
        dialogStage.showAndWait();

        return size;
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }


    private void createOneStage(Stage stage) {
        RootPane root = new RootPane(manager,gameEngine);
        Scene scene = new Scene(root,comprimento,largura);
        stage.setScene(scene);
        stage.setTitle("Ecossistema@PA");
        stage.show();
    }

    private void createListStage(double x, double y) {
        Stage stage = new Stage();
        ListPane listPane = new ListPane(manager);
        Scene scene = new Scene(listPane,300,400);
        stage.setScene(scene);
        stage.setTitle("Ecossistema List");
        stage.setX(x);
        stage.setY(y);
        stage.show();
    }

    @Override
    public void stop() throws Exception {
        gameEngine.stop();
        gameEngine.waitForTheEnd();
    }
}
