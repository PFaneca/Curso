package pt.isec.pa.javalife.ui.gui;

import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import pt.isec.pa.javalife.model.EcossistemaManager;
import pt.isec.pa.javalife.model.gameengine.GameEngine;

public class RootPane extends BorderPane {

    private EcossistemaManager model;
    private EcossistemaArea modelArea;
    private Pane areaPane;
    private GameEngine gameEngine;


    public RootPane(EcossistemaManager model,GameEngine gameEngine){
        this.gameEngine=gameEngine;
        this.model=model;
        createViews();
        registerHandlers();
        update();
    }



    public void createViews(){
        setTop(new EcossistemaMenu(model,gameEngine));
        modelArea = new EcossistemaArea(model);
        areaPane = new Pane(modelArea);
        setCenter(areaPane);
    }



    public void registerHandlers(){
        areaPane.widthProperty().addListener(observable -> modelArea.updateSize(areaPane.getWidth(),areaPane.getHeight()));
        areaPane.heightProperty().addListener(observable -> modelArea.updateSize(areaPane.getWidth(),areaPane.getHeight()));
    }

    public void update(){


    }


}
