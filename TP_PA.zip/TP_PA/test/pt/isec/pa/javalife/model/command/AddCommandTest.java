package pt.isec.pa.javalife.model.command;

import org.junit.Before;
import org.junit.Test;
import pt.isec.pa.javalife.model.data.Ecossistema;
import pt.isec.pa.javalife.model.data.ElementoBase;
import pt.isec.pa.javalife.model.data.IElemento;

import static org.junit.Assert.*;


public class AddCommandTest {

    private Ecossistema ecossistema;
    private IElemento elemento;
    private AddCommand addCommand;

    @Before
    public void setUp() {
        ecossistema = new Ecossistema(200,200);
        addCommand = new AddCommand(ecossistema, 10.0, 20.0);
    }


    @Test
    public void testExecute() {
        assertEquals(4, ecossistema.getList().size());

        ecossistema.setCurrentType(ElementoBase.Elemento.INANIMADO);
        boolean result = addCommand.execute();

        assertTrue(result);
        assertEquals(5, ecossistema.getList().size());

    }

    @Test
    public void testUndo(){
        ecossistema.setCurrentType(ElementoBase.Elemento.INANIMADO);
        addCommand.execute();
        assertEquals(5, ecossistema.getList().size());

        // Undo the command to remove the element
        boolean result = addCommand.undo();

        // After undo, the element should no longer exist in the ecosystem
        assertTrue(result);
        assertEquals(4, ecossistema.getList().size());
    }

    @Test
    public void testUndoSemExecute() {
        // Try to undo without executing the command
        boolean result = addCommand.undo();

        // Undo should fail as there is nothing to undo
        assertFalse(result);
    }




}
