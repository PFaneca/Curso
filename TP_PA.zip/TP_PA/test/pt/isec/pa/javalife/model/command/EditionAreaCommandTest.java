package pt.isec.pa.javalife.model.command;

import org.junit.Before;
import org.junit.Test;
import pt.isec.pa.javalife.model.data.Area;
import pt.isec.pa.javalife.model.data.Ecossistema;
import pt.isec.pa.javalife.model.data.ElementoBase;
import pt.isec.pa.javalife.model.data.IElemento;
import pt.isec.pa.javalife.model.data.tiposelementos.Pedra;

import static org.junit.Assert.*;

public class EditionAreaCommandTest {

    private Ecossistema ecossistema;
    private ElementoBase elemento;
    private Area novaArea;
    private Area areaAnterior;
    private EditionAreaCommand command;

    @Before
    public void setUp() {
        ecossistema = new Ecossistema(200, 200);
        ecossistema.setCurrentType(ElementoBase.Elemento.INANIMADO);
        elemento= (ElementoBase)ecossistema.createElemento(100,100);
        ecossistema.finishCurrentFigure(200,200);

        areaAnterior = new Area(elemento.getX1(), elemento.getX2(), elemento.getY1(), elemento.getY2());
        novaArea = new Area(30, 30, 40, 40);
        command = new EditionAreaCommand(ecossistema, elemento, novaArea);


    }

    @Test
    public void testExecute() {
        boolean result = command.execute();
        assertTrue(result);
        assertEquals(novaArea, elemento.getArea());
    }

    @Test
    public void testUndo(){
        command.execute();
        // Desfaz o comando e verifica se a área do elemento foi revertida
        boolean result = command.undo();
        assertTrue(result);
        assertEquals(areaAnterior, elemento.getArea());
    }


}
