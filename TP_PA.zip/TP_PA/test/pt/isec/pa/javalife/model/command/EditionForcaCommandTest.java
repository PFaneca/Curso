package pt.isec.pa.javalife.model.command;

import org.junit.Before;
import org.junit.Test;
import pt.isec.pa.javalife.model.data.Ecossistema;
import pt.isec.pa.javalife.model.data.ElementoBase;
import pt.isec.pa.javalife.model.data.IElementoComForca;
import pt.isec.pa.javalife.model.data.tiposelementos.Animal;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class EditionForcaCommandTest {

    private Ecossistema ecossistema;
    private IElementoComForca elementoForca;
    private double forcaInicial;
    private double forcaNova;

    private EditionForcaCommand command;

    @Before
    public void setUp() {
        // Inicialize o ambiente de teste
        ecossistema = new Ecossistema(200, 200);
        ecossistema.setCurrentType(ElementoBase.Elemento.FAUNA);
        elementoForca= (IElementoComForca) ecossistema.createElemento(100,100);
        ecossistema.finishCurrentFigure(200,200);
        forcaNova = 75.0;

        // Crie o comando
        command = new EditionForcaCommand(ecossistema, elementoForca, forcaNova);
    }

    @Test
    public void testExecute() {
        // Verifique se o comando é executado corretamente
        assertTrue(command.execute());
        assertEquals(forcaNova, elementoForca.getForca(), 0.001); // Use delta para comparar doubles
    }

    @Test
    public void testUndo() {
        // Execute o comando
        boolean result = command.undo();
        // Verifique se o comando é desfeito corretamente
        assertTrue(result);
        assertEquals(50, elementoForca.getForca(), 0.001); // Use delta para comparar doubles
    }



}
