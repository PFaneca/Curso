package pt.isec.pa.javalife.model.command;

import pt.isec.pa.javalife.model.data.Ecossistema;
import pt.isec.pa.javalife.model.data.Fauna;
import org.junit.Before;
import org.junit.Test;
import pt.isec.pa.javalife.model.data.tiposelementos.Animal;

import static org.junit.Assert.*;

public class EditionForcaMovimentoCommandTest {

    private Ecossistema ecossistema;
    private Fauna fauna;
    private EditionForcaMovimentoCommand command;

    @Before
    public void setUp() {
        ecossistema = new Ecossistema(200, 200);
        fauna = new Animal(); // Ou qualquer instância válida de Fauna
        command = new EditionForcaMovimentoCommand(ecossistema, fauna, 50); // Por exemplo, força de movimento de 50
    }

    @Test
    public void testExecute() {
        command.execute();
        assertEquals(50, fauna.getforcaMovimento(), 0); // Verifica se a força de movimento foi alterada para 50
    }

    @Test
    public void testUndo() {
        boolean result = command.undo();
        // Verifique se o comando é desfeito corretamente
        assertTrue(result);
        assertEquals(0.5, fauna.getforcaMovimento(), 0); // Verifica se a força de movimento foi revertida para o valor anterior
    }



}
