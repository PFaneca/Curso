package pt.isec.pa.javalife.model.command;

import org.junit.Before;
import org.junit.Test;
import pt.isec.pa.javalife.model.data.Ecossistema;
import pt.isec.pa.javalife.model.data.Flora;
import pt.isec.pa.javalife.model.data.tiposelementos.Erva;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class EditionForcaPerdidaFloraCommandTest {

    private Ecossistema ecossistema;
    private Flora flora;
    private EditionForcaPerdidaFloraCommand command;

    @Before
    public void setUp() {
        ecossistema = new Ecossistema(200, 200);
        flora = new Erva();
        ecossistema.adicionarElemento(flora);
        command = new EditionForcaPerdidaFloraCommand(ecossistema, flora, 10);
    }

    @Test
    public void testExecute() {
        boolean result = command.execute();
        assertTrue(result);
        assertEquals(10, flora.getReducaoForcaFlora(), 0.01); // Utiliza delta para lidar com imprecisões de ponto flutuante
    }


    @Test
    public void testUndo() {
        double forcaPerdidaInicial = flora.getReducaoForcaFlora();
        boolean result = command.undo();
        assertTrue(result);
        assertEquals(forcaPerdidaInicial, flora.getReducaoForcaFlora(), 0.01); // Utiliza delta para lidar com imprecisões de ponto flutuante
    }

}
