package pt.isec.pa.javalife.model.command;

import org.junit.Before;
import org.junit.Test;
import pt.isec.pa.javalife.model.data.*;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class RemoveCommandTest{

    private Ecossistema ecossistema;
    private ElementoBase elemento;
    private RemoveCommand removeCommand;

    @Before
    public void setUp() {
        ecossistema = new Ecossistema(200, 200);

        ecossistema.setCurrentType(ElementoBase.Elemento.FLORA);
        elemento = (ElementoBase) ecossistema.createElemento(100, 100);
        ecossistema.finishCurrentFigure(150, 150);

        removeCommand = new RemoveCommand(ecossistema);

    }

    @Test
    public void testExecute() {

        // Verifique se o ecossistema contém o elemento antes da remoção
        assertTrue(ecossistema.getList().contains(elemento));

        // Execute o comando de remoção
        boolean result = removeCommand.execute();
        assertTrue(result); // Verifique se a execução foi bem-sucedida

        // Verifique se o elemento foi removido do ecossistema
        assertFalse(ecossistema.getList().contains(elemento));
    }

    @Test
    public void testUndo() {
        // Execute o comando de remoção
        removeCommand.execute();

        // Verifique se o ecossistema não contém o elemento após a remoção
        assertFalse(ecossistema.getList().contains(elemento));

        // Desfaça a remoção
        boolean result = removeCommand.undo();
        assertTrue(result); // Verifique se o desfazer foi bem-sucedido

        // Verifique se o elemento foi adicionado de volta ao ecossistema
        assertTrue(ecossistema.getList().contains(elemento));
    }


}
