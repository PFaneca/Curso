#include "../bolsa/utils.h"
#include "board.h"


void verificacomando(TCHAR* cmd) {
    if (_tcsclen(cmd) == 0)
        return;
    TCHAR straux[TAM];
    _tcscpy_s(straux, TAM, cmd);

    TCHAR delim[] = _T(" \n");
    TCHAR* context = NULL; // Inicializando o ponteiro de contexto
    TCHAR* ptr = _tcstok_s(straux, delim, &context); // Usando _tcstok_s para strings wide
    //_tprintf(_T("%s"), ptr);
    int cmd_len = (sizeof comandos / sizeof(struct comando));
    for (DWORD i = 0; i < cmd_len; i++) {
        if (_tcscmp(comandos[i].nome, ptr) == 0) {
            comandos[i].func(cmd); // Passando ptr como argumento
            return;
        }
    }
    _tprintf(_T("Comando desconhecido: %s\n"), cmd);

}


void Sair() {
    _tprintf_s(_T("Sair..."));
    exit(1);
}

// Fun��o de compara��o para qsort (ordem decrescente de pre�o da a��o)
int comparar_empresas(const void* a, const void* b) {
    const Empresa* empresaA = (const Empresa*)a;
    const Empresa* empresaB = (const Empresa*)b;

    // Compara os pre�os das a��es em ordem decrescente
    if (empresaA->preco_acao < empresaB->preco_acao) {
        return 1;
    }
    else if (empresaA->preco_acao > empresaB->preco_acao) {
        return -1;
    }
    else {
        return 0;
    }
}
// Fun��o para encontrar a empresa menos valiosa na lista
int encontrarMenosValiosa(const Empresa* pEmpresas, int numempresas) {
    float menorPreco = pEmpresas[0].preco_acao;
    int idxMenosValiosa = 0;
    for (int i = 1; i < numempresas; i++) {
        if (pEmpresas[i].preco_acao < menorPreco) {
            menorPreco = pEmpresas[i].preco_acao;
            idxMenosValiosa = i;
        }
    }
    return idxMenosValiosa;
}

// Fun��o para adicionar uma nova empresa mais valiosa � lista
void adicionarNovaEmpresaMaisValiosa(Empresa* pEmpresas, int numempresas, Empresa novaEmpresa) {
    int idxMenosValiosa = encontrarMenosValiosa(pEmpresas, numempresas);
    if (novaEmpresa.preco_acao > pEmpresas[idxMenosValiosa].preco_acao) {
        pEmpresas[idxMenosValiosa] = novaEmpresa;
    }
}

// Fun��o para remover a empresa menos valiosa da lista
void removerMenosValiosa(Empresa* pEmpresas, int numempresas) {
    int idxMenosValiosa = encontrarMenosValiosa(pEmpresas, numempresas);
    for (int i = idxMenosValiosa; i < numempresas - 1; i++) {
        pEmpresas[i] = pEmpresas[i + 1];
    }
}

DWORD WINAPI LerComandos(LPVOID lpParam) {
    TCHAR cmd[TAM];
    do {
        _fgetts(cmd, TAM, stdin);
        cmd[_tcslen(cmd) - 1] = '\0'; // Remove o caractere de nova linha 
        verificacomando(cmd);
        if (_tcscmp(cmd, "sair") == 0) break;
       

    } while (TRUE);
    return 0;
}



int _tmain(int argc, LPTSTR argv[]) {
    HANDLE hFich, hMap,hMapUltimaTransacao, hTrinco, hWriteSem, hReadSem, hEventoSair;
    Empresa* pEmpresas;
    UltimaTransacao* pUltimaTransacao;
    TCHAR str[TAM_SHN], cmd[TAM];


#ifdef UNICODE
    _setmode(_fileno(stdin), _O_WTEXT);
    _setmode(_fileno(stdout), _O_WTEXT);
#endif


    if (argc < 2) {
        _tprintf(_T("\nFalta o valor de N"));
        return 1;
    }
    int numempresas = _tstoi(argv[1]);

    if (numempresas < 0 || numempresas > 10) {
        _tprintf(_T("\nO valor de N deve estar entre 0 e 10"));
        return 1;
    }

    HANDLE hThread = CreateThread(NULL, 0, LerComandos, NULL, 0, NULL);
    if (hThread == NULL) {
        _tprintf_s(_T("Erro ao criar a thread. C�digo de erro: %d\n"), GetLastError());
        return 1;

    }

    
    
    

    hTrinco = OpenMutex(SYNCHRONIZE | MUTEX_MODIFY_STATE, FALSE, NOME_MUTEX);
    if (hTrinco == NULL) {
        _tprintf_s(_T("Erro ao abrir o mutex\n"));
        return 1;
    }

    hWriteSem = CreateSemaphore(NULL, TAM_SHN, TAM_SHN, SEM_WRITE_NAME);
    if (hWriteSem == NULL) {
        _tprintf_s(_T("Erro ao criar semaforo para escrita\n"));
        CloseHandle(hTrinco);
        return 1;
    }

    hReadSem = CreateSemaphore(NULL, 0, TAM_SHN, SEM_READ_NAME);
    if (hReadSem == NULL) {
        _tprintf_s(_T("Erro ao criar semaforo para leitura\n"));
        CloseHandle(hWriteSem);
        CloseHandle(hTrinco);
        return 1;
    }
    hEventoSair = CreateEvent(NULL, TRUE, FALSE, EVENTO_SAIR);
    if (hEventoSair == NULL) {
        _tprintf_s(_T("Erro ao criar evento\n"));
        CloseHandle(hWriteSem);
        CloseHandle(hTrinco);
        CloseHandle(hReadSem);
        return 1;
    }


    hMap = OpenFileMapping(FILE_MAP_READ | FILE_MAP_WRITE, FALSE, NOME_SHN);
    if (hMap == NULL) {
        _tprintf_s(_T("Erro ao abrir o mapeamento de arquivo\n"));
        CloseHandle(hTrinco);
        return 1;
    }

    hMapUltimaTransacao = OpenFileMapping(FILE_MAP_READ | FILE_MAP_WRITE, FALSE, NOME_SHNM);
    if (hMapUltimaTransacao == NULL) {
        _tprintf_s(_T("Erro ao abrir o mapeamento de arquivo para a �ltima transa��o\n"));
        CloseHandle(hMap);
        CloseHandle(hTrinco);
        return 1;
    }




    pEmpresas = (Empresa*)MapViewOfFile(hMap, FILE_MAP_READ | FILE_MAP_WRITE, 0, 0, TAM_SHN * sizeof(Empresa));
    if (pEmpresas == NULL) {
        _tprintf_s(_T("Erro ao mapear arquivo na mem�ria\n"));
        CloseHandle(hMap);
        return 1;
    }

    pUltimaTransacao = (UltimaTransacao*)MapViewOfFile(hMapUltimaTransacao, FILE_MAP_READ | FILE_MAP_WRITE, 0, 0, TAM_SHN * sizeof(UltimaTransacao));
    if (pUltimaTransacao == NULL) {
        _tprintf_s(_T("Erro ao mapear arquivo na mem�ria\n"));
        CloseHandle(hMap);
        return 1;
    }

   

    while (TRUE){
        //Sleep(5000);

        WaitForSingleObject(hReadSem, INFINITE);

        WaitForSingleObject(hTrinco, INFINITE);

        qsort(pEmpresas, numempresas, sizeof(Empresa), comparar_empresas);
        _tprintf_s(_T("-----------------------------------\n"));

        for (int i = 0; i < numempresas; i++) {
            _tprintf_s(_T("Nome da Empresa: %s\n"), pEmpresas[i].nome);
            _tprintf_s(_T("N�mero de A��es: %d\n"), pEmpresas[i].num_acoes);
            _tprintf_s(_T("Pre�o da A��o: %.2f\n"), pEmpresas[i].preco_acao);
            _tprintf_s(_T("\n"));
        }

        // Verifica se h� uma �ltima transa��o dispon�vel e imprime seus dados
        if (pUltimaTransacao != NULL) {
            _tprintf_s(_T("�ltima Transa��o:\n"));
            _tprintf_s(_T("Nome da Empresa: %s\n"), pUltimaTransacao->nome);
            _tprintf_s(_T("N�mero de A��es: %d\n"), pUltimaTransacao->num_acoes);
            _tprintf_s(_T("Valor da Transa��o: %.2f\n"), pUltimaTransacao->valor_transacao);
            //_tprintf_s(_T("Tipo de Transa��o: %s\n"), pUltimaTransacao->tipo_transacao);
            _tprintf_s(_T("\n"));
        }



        Sleep(5000);

     
        ReleaseMutex(hTrinco);

        ReleaseSemaphore(hWriteSem, 1, NULL);

        if (WaitForSingleObject(hEventoSair, 0) == WAIT_OBJECT_0) {
            break; // Sai do loop se o evento de sa�da foi sinalizado
        }
    } 

    UnmapViewOfFile(pEmpresas);
    UnmapViewOfFile(pUltimaTransacao);
    CloseHandle(hMap);
  
    CloseHandle(hWriteSem);
    CloseHandle(hReadSem);
    CloseHandle(hTrinco);

    return 0;
}