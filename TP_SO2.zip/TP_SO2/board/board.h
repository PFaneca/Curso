#pragma once

#include "../bolsa/utils.h"

void Sair();


static const struct comando comandos[] = {
   {_T("sair"),_T("Sair do sistema"),&Sair}

};
