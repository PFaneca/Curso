#include <windows.h>
#include <tchar.h>
#include "resource.h"
#include "../bolsa/utils.h"



LRESULT CALLBACK TrataEventos(HWND, UINT, WPARAM, LPARAM);

TCHAR szProgName[] = TEXT("Base");

int WINAPI _tWinMain(HINSTANCE hInst, HINSTANCE hPrevInst, LPTSTR lpCmdLine, int nCmdShow) {

	HWND hWnd;
	MSG lpMsg;
	WNDCLASSEX wcApp;
	HANDLE hFich, hMap, hMapUltimaTransacao, hTrinco, hWriteSem, hReadSem, hEventoSair;
	Empresa* pEmpresas;
	UltimaTransacao* pUltimaTransacao;
	TCHAR str[TAM_SHN];

	

	hEventoSair = CreateEvent(NULL, TRUE, FALSE, EVENTO_SAIR);
	if (hEventoSair == NULL) {
		_tprintf_s(_T("Erro ao criar evento\n"));
		return 1;
	}

	wcApp.cbSize = sizeof(WNDCLASSEX);
	wcApp.hInstance = hInst;
	wcApp.lpszClassName = szProgName;
	wcApp.lpfnWndProc = TrataEventos;
	wcApp.style = CS_HREDRAW | CS_VREDRAW;
	wcApp.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	wcApp.hIconSm = LoadIcon(NULL, IDI_INFORMATION);
	wcApp.hCursor = LoadCursor(NULL, IDC_ARROW);
	wcApp.lpszMenuName = MAKEINTRESOURCE(IDR_MENU1);
	wcApp.cbClsExtra = 0;
	wcApp.cbWndExtra = sizeof(INFO *);
	wcApp.hbrBackground = CreateSolidBrush(RGB(255, 255, 255));

	if (!RegisterClassEx(&wcApp))
		return(0);

	hWnd = CreateWindow(
		szProgName,
		TEXT("BoardGUI"),
		WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT,
		CW_USEDEFAULT,
		CW_USEDEFAULT,
		CW_USEDEFAULT,
		(HWND)HWND_DESKTOP,
		(HMENU)NULL,
		(HINSTANCE)hInst,
		0);



	ShowWindow(hWnd, nCmdShow);

	UpdateWindow(hWnd);

	while (GetMessage(&lpMsg, NULL, 0, 0) > 0) {
		TranslateMessage(&lpMsg);
		DispatchMessage(&lpMsg);

		if (WaitForSingleObject(hEventoSair, 0) == WAIT_OBJECT_0) {
			PostQuitMessage(0); // Sai do loop se o evento de sa�da foi sinalizado
			break; // Sai do loop de mensagens
		}
	}

	return (int)lpMsg.wParam;
}


BOOL CALLBACK DialogInicial(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam) {
	HWND hComboBox;
	TCHAR limite_inferior[TAM], limite_superior[TAM];
	INFO *info = (INFO*)GetWindowLongPtr(GetParent(hDlg), 0);


	switch (uMsg) {

	case WM_INITDIALOG:
		
		// Identificador do controle de combobox
		hComboBox = GetDlgItem(hDlg, IDC_COMBO1);

		// Adicionar n�meros de 0 a 10 � lista suspensa do controle de combobox
		for (int i = 1; i <= 10; ++i) {
			TCHAR szNumber[16]; // String para armazenar o n�mero como texto
			_itot_s(i, szNumber, sizeof(szNumber) / sizeof(szNumber[0]), 10); // Converter o n�mero para uma string
			SendMessage(hComboBox, CB_ADDSTRING, 0, (LPARAM)szNumber); // Adicionar a string � lista suspensa
		}

		// Definir o valor inicial para 5, por exemplo
		SendMessage(hComboBox, CB_SETCURSEL, 5, 0); // Define a sele��o inicial para o �ndice 5 (valor 5)

		
	
	case WM_COMMAND:

		switch (LOWORD(wParam)) {
		case IDOK:

		
			GetDlgItemText(hDlg, IDC_EDIT3, limite_inferior , TAM);
			GetDlgItemText(hDlg, IDC_EDIT4, limite_superior,TAM);
			info->data.limite_inferior = _wtof(limite_inferior);
			info->data.limite_superior = _wtof(limite_superior);

			hComboBox = GetDlgItem(hDlg, IDC_COMBO1);
			// Obter o �ndice do item selecionado na combobox
			int nIndex = SendMessage(hComboBox, CB_GETCURSEL, 0, 0);

			// Verificar se um item foi selecionado
			if (nIndex != CB_ERR) {
				info->data.num_empresas = nIndex;
	
			}

			EndDialog(hDlg, LOWORD(wParam));
			break;


		case IDCANCEL:
			EndDialog(hDlg, LOWORD(wParam));
			break;

		}
		break;

	case WM_CLOSE:
		EndDialog(hDlg, LOWORD(wParam));
		break;


	default:
		return FALSE;
	}
	return FALSE;
}




BOOL CALLBACK DialogGrupo(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam) {
	HDC hdc;
	RECT rect;
	PAINTSTRUCT ps;
	MINMAXINFO* mmi;
	static HDC bmpDC1 = NULL, bmpDC2 = NULL;
	HBITMAP hBmp1 = NULL, hBmp2 = NULL;
	static BITMAP bmp;
	static int xBitmap1, xBitmap2;
	static int yBitmap1, yBitmap2;
	HWND hComboBox;
	//int newWidth = 100;
		//int newHeight = 100;
	switch (uMsg) {
	
	case WM_INITDIALOG:
		hBmp1 = (HBITMAP)LoadImage(NULL,
			TEXT("Martim.bmp"),
			IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);

		hBmp2 = (HBITMAP)LoadImage(NULL,
		TEXT("Pedro.bmp"),
			IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);

		GetObject(hBmp1, sizeof(bmp), &bmp);
		GetObject(hBmp2, sizeof(bmp), &bmp);
		

		hdc = GetDC(hDlg);
		bmpDC1 = CreateCompatibleDC(hdc);
		bmpDC2 = CreateCompatibleDC(hdc);
		SelectObject(bmpDC1, hBmp1);
		SelectObject(bmpDC2, hBmp2);
		

		ReleaseDC(hDlg, hdc);
		GetClientRect(hDlg, &rect);
		// Defina um tamanho menor para a imagem (por exemplo, 100x100 pixels)
		
		xBitmap1 = 50;
		yBitmap1 = 15;

		xBitmap2 = 280;
		yBitmap2 = 15;
		// Identificador do controle de combobox
		hComboBox = GetDlgItem(hDlg, IDC_COMBO2);

		// Adicionar n�meros de 0 a 10 � lista suspensa do controle de combobox
		for (int i = 0; i <= 10; ++i) {
			TCHAR szNumber[16]; // String para armazenar o n�mero como texto
			_itot_s(i, szNumber, sizeof(szNumber) / sizeof(szNumber[0]), 10); // Converter o n�mero para uma string
			SendMessage(hComboBox, CB_ADDSTRING, 0, (LPARAM)szNumber); // Adicionar a string � lista suspensa
		}

		// Definir o valor inicial para 5, por exemplo
		SendMessage(hComboBox, CB_SETCURSEL, 6, 0); // Define a sele��o inicial para o �ndice 5 (valor 5)
		break;
	
	case WM_GETMINMAXINFO:
		mmi = (MINMAXINFO*)lParam;
		mmi->ptMinTrackSize.x = bmp.bmWidth + 2;
		mmi->ptMinTrackSize.y = bmp.bmHeight + 24 + 2;
		break;

	
	
	case WM_COMMAND:

		switch (LOWORD(wParam)) {
		case IDOK:
			EndDialog(hDlg, LOWORD(wParam));
			break;

		
		}
		break;
	
	case WM_PAINT:
		hdc = BeginPaint(hDlg, &ps);//inicio do desenho
		GetClientRect(hDlg, &rect);
		FillRect(hdc, &rect,
			CreateSolidBrush(RGB(255, 255, 255)));
		BitBlt(hdc, xBitmap1, yBitmap1, bmp.bmWidth,
			bmp.bmHeight, bmpDC1, 0, 0, SRCCOPY);

		BitBlt(hdc, xBitmap2, yBitmap2, bmp.bmWidth,
			bmp.bmHeight, bmpDC2, 0, 0, SRCCOPY);
		
		EndPaint(hDlg, &ps);
		break;

	
	case WM_CLOSE:
		EndDialog(hDlg, LOWORD(wParam));
		break;

		
	default:
		return FALSE;
	}
	return FALSE;
}

BOOL CALLBACK DialogEmpresas(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam) {
	//DATA data;
	INFO* info = GetWindowLongPtr(GetParent(hDlg), 0);
	HWND hComboBox;
	switch (uMsg) {
	
	case WM_INITDIALOG:
		// Identificador do controle de combobox
		hComboBox = GetDlgItem(hDlg, IDC_COMBO2);

		// Adicionar n�meros de 0 a 10 � lista suspensa do controle de combobox
		for (int i = 1; i <= 10; ++i) {
			TCHAR szNumber[16]; // String para armazenar o n�mero como texto
			_itot_s(i, szNumber, sizeof(szNumber) / sizeof(szNumber[0]), 10); // Converter o n�mero para uma string
			SendMessage(hComboBox, CB_ADDSTRING, 0, (LPARAM)szNumber); // Adicionar a string � lista suspensa
		}

		// Definir o valor inicial para 5, por exemplo
		SendMessage(hComboBox, CB_SETCURSEL, 5, 0); // Define a sele��o inicial para o �ndice 5 (valor 5)
	
	
	case WM_COMMAND:

		switch (LOWORD(wParam)) {
		case IDOK:

			hComboBox = GetDlgItem(hDlg, IDC_COMBO2);
			// Obter o �ndice do item selecionado na combobox
			int nIndex = SendMessage(hComboBox, CB_GETCURSEL, 0, 0);
			
			// Verificar se um item foi selecionado
			if (nIndex != CB_ERR) {
				info->data.num_empresas = nIndex ;

			}

			EndDialog(hDlg, LOWORD(wParam));
			
			break;

		case IDCANCEL:
			EndDialog(hDlg, LOWORD(wParam));
			break;

		}
		break;
	case WM_CLOSE:
		EndDialog(hDlg, LOWORD(wParam));
		break;


	default:
		return FALSE;
	}
	return FALSE;
}

BOOL CALLBACK DialogEscala(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam) {
	//DATA data;
	TCHAR limite_inferior[TAM], limite_superior[TAM];
	INFO* info = GetWindowLongPtr(GetParent(hDlg), 0);

	switch (uMsg) {

	case WM_INITDIALOG:
		//SetDlgItemText(hDlg, IDC_EDIT1, info->data.limite_inferior);
		//SetDlgItemText(hDlg, IDC_EDIT2, info->data.limite_superior);
		return TRUE;


	case WM_COMMAND:

		switch (LOWORD(wParam)) {
		case IDOK:
			
			GetDlgItemText(hDlg, IDC_EDIT1, limite_inferior, TAM);
			GetDlgItemText(hDlg, IDC_EDIT2, limite_superior, TAM);
			info->data.limite_inferior = _wtof(limite_inferior);
			info->data.limite_superior = _wtof(limite_superior);

			//TCHAR message[128];
			//_stprintf_s(message, 128, _T("Limite Inferior: %d\nLimite Superior: %d"), data.limite_inferior, data.limite_superior);
			//MessageBox(hDlg, message, _T("Valores Inseridos"), MB_OK);
			
			// Aqui voc� pode fazer algo com os valores (por exemplo, pass�-los de volta para o procedimento principal)
			EndDialog(hDlg, LOWORD(wParam));

			
			
			break;

		case IDCANCEL:
			EndDialog(hDlg, LOWORD(wParam));
			break;

		}
		break;
	case WM_CLOSE:
		EndDialog(hDlg, LOWORD(wParam));
		break;


	default:
		return FALSE;
	}
	return FALSE;
}

DWORD WINAPI EsperaInfo(LPVOID lpParam) {
	INFO *pInfo = (INFO*)lpParam;
	
	
	while (TRUE) {
			
		WaitForSingleObject(pInfo->hReadSem, INFINITE);
		WaitForSingleObject(pInfo->hTrinco, INFINITE);

			// Quando o evento ocorrer, fazer algo, como invalidar a �rea de cliente da janela
		InvalidateRect(pInfo->hWnd, NULL, TRUE);

		Sleep(5000);


		ReleaseMutex(pInfo->hTrinco);
		ReleaseSemaphore(pInfo->hWriteSem, 1, NULL);

		
	}
	

	

	return 0;

}

double MapValue(double value, double fromLow, double fromHigh, double toLow, double toHigh) {
	return (toLow + (value - fromLow) * (toHigh - toLow) / (fromHigh - fromLow));
}

LRESULT CALLBACK TrataEventos(HWND hWnd, UINT messg, WPARAM wParam, LPARAM lParam) {
//	HANDLE hFich, hMap, hMapUltimaTransacao, hTrinco, hWriteSem, hReadSem, hEventoSair;
//	Empresa* pEmpresas;
//	UltimaTransacao* pUltimaTransacao;
	TCHAR str[TAM_SHN];
	PAINTSTRUCT ps;
	HDC hdc;
	RECT rect;
	TCHAR nomeEmpresaTransacionada[TAM];
	INFO *info = GetWindowLongPtr(hWnd, 0);   // CONVEM VERIFICAR SE � DIFERENTE DE NULL
	HANDLE hThread;
	switch (messg) {
	case WM_CREATE:
		info = (INFO*)malloc(sizeof(INFO));
		SetWindowLongPtr(hWnd, 0, (LONG_PTR)info);

		info->hWnd = hWnd;


		info->hTrinco = CreateMutex(NULL, FALSE, NOME_MUTEX);
		if (info->hTrinco == NULL) {
			_tprintf_s(_T("Erro ao criar mutex\n"));
			return 1;
		}

		info->hWriteSem = CreateSemaphore(NULL, TAM_SHN, TAM_SHN, SEM_WRITE_NAME);
		if (info->hWriteSem == NULL) {
			_tprintf_s(_T("Erro ao criar semaforo para escrita\n"));
			CloseHandle(info->hTrinco);
			return 1;
		}

		info->hReadSem = CreateSemaphore(NULL, 0, TAM_SHN, SEM_READ_NAME);
		if (info->hReadSem == NULL) {
			_tprintf_s(_T("Erro ao criar semaforo para leitura\n"));
			CloseHandle(info->hWriteSem);
			CloseHandle(info->hTrinco);
			return 1;
		}



		info->hMap = OpenFileMapping(FILE_MAP_READ | FILE_MAP_WRITE, FALSE, NOME_SHN);
		if (info->hMap == NULL) {
			_tprintf_s(_T("Erro ao abrir o mapeamento de arquivo\n"));
			CloseHandle(info->hTrinco);
			return 1;
		}

		info->hMapUltimaTransacao = OpenFileMapping(FILE_MAP_READ | FILE_MAP_WRITE, FALSE, NOME_SHNM);
		if (info->hMapUltimaTransacao == NULL) {
			_tprintf_s(_T("Erro ao abrir o mapeamento de arquivo para a �ltima transa��o\n"));
			CloseHandle(info->hMap);
			CloseHandle(info->hTrinco);
			return 1;
		}



		info->pEmpresas = (Empresa*)MapViewOfFile(info->hMap, FILE_MAP_READ | FILE_MAP_WRITE, 0, 0, TAM_SHN * sizeof(Empresa));
		if (info->pEmpresas == NULL) {
			_tprintf_s(_T("Erro ao mapear arquivo na mem�ria\n"));
			CloseHandle(info->hMap);
			CloseHandle(info->hTrinco);
			return 1;
		}

		info->pUltimaTransacao = (UltimaTransacao*)MapViewOfFile(info->hMapUltimaTransacao, FILE_MAP_READ | FILE_MAP_WRITE, 0, 0, TAM_SHN*sizeof(UltimaTransacao));
		if (info->pUltimaTransacao == NULL) {
			_tprintf_s(_T("Erro ao mapear arquivo na mem�ria para a �ltima transa��o\n"));
			CloseHandle(info->hMapUltimaTransacao);
			CloseHandle(info->hMap);
			CloseHandle(info->hTrinco);
			return 1;
		}



		if (DialogBox(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_DIALOG4), hWnd, DialogInicial) == IDOK) {
			
			
			
		}
		else {
			// Se o usu�rio pressionar "Cancelar" ou fechar a caixa de di�logo, encerre a aplica��o
			PostQuitMessage(0);
		}

		// CRIAR THREAD (PASSAR INFO) PARA ESTAR � ESPERA DO EVENTO DO BOLSA... E FAZER: InvalidateRect(hWnd, NULL, TRUE); 
		// MUTEX???
		info->hThread = CreateThread(NULL, 0, EsperaInfo, info, 0, NULL);
		if (info->hThread == NULL) {
			CloseHandle(info->hTrinco);
			CloseHandle(info->hWriteSem);
			CloseHandle(info->hReadSem);
			CloseHandle(info->hMap);
			CloseHandle(info->hMapUltimaTransacao);
			free(info);
			return 1;
		}
		
		break;

	case WM_COMMAND:
		switch (LOWORD(wParam)) {
		case ID_FICHEIRO_SAIR:
			if (MessageBox(hWnd, _T("Deseja sair?"), _T("Confirma��o"), MB_YESNO | MB_ICONQUESTION) == IDYES) {
				PostQuitMessage(0); // PostQuitMessage com 0 como par�metro indica uma sa�da normal do programa
			}
			break;

		case ID_ACERCA_GRUPO:
			DialogBox(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_DIALOG1), hWnd, DialogGrupo);
			break;

		case ID_REDEFENIRPORMENORESVISUALIZA40004:
			DialogBox(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_DIALOG2), hWnd, DialogEmpresas);
			break;

		case ID_REDEFENIRPORMENORESVISUALIZA40003:
			DialogBox(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_DIALOG3), hWnd, DialogEscala);
			break;

		}
		break;


	case WM_PAINT:
		
		hdc=BeginPaint(hWnd, &ps);
		GetClientRect(hWnd, &rect);
		int clientWidth = rect.right - rect.left;
		int clientHeight = rect.bottom - rect.top;

		// N�mero de barras e seus valores (substitua pelos seus dados reais)
		int numBarras = info->data.num_empresas;
		double valoresBarras[10] = { 0 }; // Inicialize com zero

		

		
		

		for (int i = 0; i < numBarras; ++i) {
			valoresBarras[i] = MapValue(info->pEmpresas[i].preco_acao, info->data.limite_inferior, info->data.limite_superior, 0.0, 100.0);
		}
		
	
		
		// Calcule as dimens�es de cada barra
		int larguraBarra = clientWidth / numBarras;
		int alturaBarra;
		
		HBRUSH hBrush = CreateSolidBrush(RGB(255, 0, 0)); 
		SelectObject(hdc, hBrush);
		
		// Desenhe as barras
		for (int i = 0; i < numBarras; ++i) {
			// Calcule a altura da barra proporcional ao valor
			alturaBarra = (int)((valoresBarras[i] / 100.0) * clientHeight);

			// Desenhe a barra
			Rectangle(hdc, i * larguraBarra, clientHeight - alturaBarra,
				(i + 1) * larguraBarra, clientHeight);

			RECT textRect = { i * larguraBarra, clientHeight - alturaBarra - 60, (i + 1) * larguraBarra, clientHeight };
			DrawText(hdc, info->pEmpresas[i].nome, -1, &textRect, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
		}

		if (info->pUltimaTransacao != NULL) {
			// Atualiza a vari�vel com o nome da empresa mais recente
			wcscpy_s(nomeEmpresaTransacionada, TAM, info->pUltimaTransacao->nome);
		}

		// Define as coordenadas para desenhar o texto "�ltima Empresa Transacionada:"
		RECT textRectTitle;
		textRectTitle.right = clientWidth; // Alinha o texto � direita da janela
		textRectTitle.top = 0;
		textRectTitle.bottom = 30;
		textRectTitle.left = textRectTitle.right - 350; // Ajuste conforme necess�rio para o espa�amento

		// Desenha o texto "�ltima Empresa Transacionada:"
		DrawText(hdc, _T("�ltima Empresa Transacionada:"), -1, &textRectTitle, DT_LEFT | DT_VCENTER | DT_SINGLELINE);

		// Define as coordenadas para desenhar o nome da empresa mais recentemente transacionada � direita do texto acima
		RECT textRect;
		textRect.left = clientWidth - 240; // Ajuste conforme necess�rio para posicionar o texto
		textRect.top = 0;
		textRect.right = clientWidth;
		textRect.bottom = 30;

		// Desenha o nome da empresa mais recentemente transacionada
		DrawText(hdc, nomeEmpresaTransacionada, -1, &textRect, DT_RIGHT | DT_VCENTER | DT_SINGLELINE);


		EndPaint(hWnd, &ps);
	
		break;
	case WM_CLOSE:
		if (MessageBox(hWnd, _T("Deseja sair?"), _T("Confirma��o"), MB_YESNO | MB_ICONQUESTION) == IDYES) {
			PostQuitMessage(0); // PostQuitMessage com 0 como par�metro indica uma sa�da normal do programa
		}
	
		free(info);
		break;

	case WM_DESTROY: // Destruir a janela e terminar o programa
		// "PostQuitMessage(Exit Status)"
		free(info);
		PostQuitMessage(0);
		break;
	default:
		// Neste exemplo, para qualquer outra mensagem (p.e. "minimizar","maximizar","restaurar")
		// n�o � efectuado nenhum processamento, apenas se segue o "default" do Windows
		return(DefWindowProc(hWnd, messg, wParam, lParam));
		break; // break tecnicamente desnecess�rio por causa do return
		}
		
		return 0;

		
	}


