//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by boardGUI.rc
//
#define IDR_MENU1                       101
#define IDD_DIALOG1                     102
#define IDD_DIALOG2                     104
#define IDD_DIALOG3                     107
#define IDD_DIALOG4                     109
#define IDC_COMBO2                      1008
#define IDC_EDIT2                       1010
#define IDC_EDIT3                       1011
#define IDC_COMBO1                      1012
#define IDC_EDIT4                       1013
#define IDC_EDIT1                       1014
#define ID_FICHEIRO_REDEFENIRPORMENORESVISUALIZA40001 40001
#define ID_FICHEIRO_SAIR                40002
#define ID_REDEFENIRPORMENORESVISUALIZA40003 40003
#define ID_REDEFENIRPORMENORESVISUALIZA40004 40004
#define ID_ACERCA_GRUPO                 40005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        111
#define _APS_NEXT_COMMAND_VALUE         40006
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
