
#include "../bolsa/utils.h"
#include "bolsa.h"
BOOL pausado = FALSE;



DWORD CriarChave() {

	HKEY hkey;
	LSTATUS res;
	DWORD estado;
	DWORD num_clientes=5;

	res = RegCreateKeyEx(HKEY_CURRENT_USER, _T("SO2\\TP"), 0, NULL, REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &hkey, &estado);
	if (res == ERROR_SUCCESS) {
		if (estado == REG_OPENED_EXISTING_KEY)
			_tprintf(TEXT("Abri chave existente\n"));

		else if (estado == REG_CREATED_NEW_KEY)
			_tprintf(TEXT("Chave criada\n"));
	}


	RegCloseKey(&hkey);

	if (hkey != 0) {
		res = RegSetValueEx(hkey, _T("NCLIENTES"), NULL, REG_DWORD, (LPBYTE)&num_clientes, sizeof(DWORD));
		if (res == ERROR_SUCCESS)
			_tprintf_s(TEXT("Sucesso\n"));
		else
			_tprintf_s(TEXT("Insucesso\n"));

	}

	else
		_tprintf_s(TEXT("Chave n�o aberta\n"));

	return num_clientes;
}




void verificacomando(TCHAR* cmd) {
	if (_tcsclen(cmd) == 0)
		return;

	TCHAR straux[TAM];
	_tcscpy_s(straux, TAM, cmd);

	TCHAR delim[] = _T(" \n");
	TCHAR* context = NULL; // Inicializando o ponteiro de contexto
	TCHAR* ptr = _tcstok_s(straux, delim, &context); // Usando _tcstok_s para strings wide
	//_tprintf(_T("%s"), ptr);
	int cmd_len = (sizeof comandos / sizeof(struct comando));
	for (DWORD i = 0; i < cmd_len; i++) {
		if (_tcscmp(comandos[i].nome, ptr) == 0) {
			
			comandos[i].func(cmd); // Passando ptr como argumento
			return;
		}
	}
		
	_tprintf(_T("Comando desconhecido: %s\n"),cmd);
				
}

void comandos_cmd() {
	_tprintf_s(_T("Lista de comandos permitidos\n"));
	for (DWORD i = 0; i < (sizeof comandos / sizeof(struct comando)); i++) {
		_tprintf_s(_T("%s - %s\n"), comandos[i].nome, comandos[i].descricao);
	}

}

void addEmpresa(TCHAR* input) {
	TCHAR nomeEmpresa[TAM];
	DWORD num_acoes;
	float preco_acao;


	// Usar sscanf_s para extrair os par�metros
	if (_stscanf_s(input, _T("addc %99s %d %f"), nomeEmpresa, TAM, &num_acoes, &preco_acao) != 3) {
		_tprintf_s(_T("Formato de comando inv�lido. Utilize o seguinte formato para o comando: addc <nome_empresa> <num_a��es> <pre�o_a��o>\n"));
		return;
	}

	// Verificar se o nome da empresa j� existe
	for (int i = 0; i < num_empresas; i++) {
		if (_tcscmp(empresas[i].nome, nomeEmpresa) == 0) {
			_tprintf_s(_T("A empresa %s j� existe.\n"), nomeEmpresa);
			return;
		}
	}

	if (num_empresas > MAX_EMPRESAS) {
		_tprintf_s(_T("Limite m�ximo de empresas alcan�ado.\n"));
		return;
	}

	Empresa novaEmpresa;
	_tcscpy_s(novaEmpresa.nome, TAM, nomeEmpresa);
	novaEmpresa.num_acoes = num_acoes;
	novaEmpresa.preco_acao = preco_acao;

	empresas[num_empresas++] = novaEmpresa;

	// Imprimir os par�metros
	_tprintf_s(_T("Empresa %s com %d a��es e pre�o-a��o: %.2f adicionada com sucesso\n"), nomeEmpresa, num_acoes, preco_acao);
}


void loadEmpresas() {
	
	FILE* file;
	if (_wfopen_s(&file, _T("..\\empresas.txt"), _T("r")) != 0) {
		_tprintf(_T("Erro ao abrir o arquivo.\n"));
		return;
	}

	TCHAR nomeEmpresa[TAM];
	DWORD num_acoes;
	float preco_acao;
	Empresa novaEmpresa;
	while (_ftscanf_s(file, _T("%s %d %f"), nomeEmpresa, TAM, &num_acoes, &preco_acao) == 3) {
		// Verifica se excedeu o n�mero m�ximo de empresas
		if (num_empresas >= MAX_EMPRESAS) {
			_tprintf(_T("N�mero m�ximo de empresas excedido.\n"));
			break;
		}

		
		_tcscpy_s(novaEmpresa.nome, TAM, nomeEmpresa);
		novaEmpresa.num_acoes = num_acoes;
		novaEmpresa.preco_acao = preco_acao;

		empresas[num_empresas++] = novaEmpresa;

		_tprintf_s(_T("Empresa: %s, N�mero de a��es: %d, Pre�o da a��o: %.2f\n"),
			novaEmpresa.nome, novaEmpresa.num_acoes, novaEmpresa.preco_acao);
	}


	fclose(file);
	_tprintf_s(_T("Ficheiro lido com sucesso\n"));
	
	
}
void listEmpresas() {
	_tprintf_s(_T("Lista de Empresas: \n"));
	for (DWORD i = 0; i < num_empresas; i++) {
		_tprintf_s(_T("Empresa: %s, %d a��es, pre�o-a��o: %.2f\n"), empresas[i].nome, empresas[i].num_acoes, empresas[i].preco_acao);
	}
}

void RedefineCusto(TCHAR *input) {
	TCHAR nomeEmpresa[100];
	float preco_acao;

	// Usar sscanf_s para extrair os par�metros
	if (_stscanf_s(input, _T("stock %99s %f"), nomeEmpresa, 100, &preco_acao) != 2) {
		_tprintf_s(_T("Formato de comando inv�lido. Utilize o seguinte formato para o comando: stock <nome_empresa> <pre�o_a��o>\n"));
		return;
	}


	for (DWORD i = 0; i < num_empresas; i++) {
		if (_tcscmp(nomeEmpresa, empresas[i].nome) == 0) {
			empresas[i].preco_acao = preco_acao;
			_tprintf_s(_T("Pre�o da a��o da empresa %s atualizado para %.2f\n"), nomeEmpresa, preco_acao);

			// Atualizar o pre�o das vendas pendentes da empresa
			for (DWORD j = 0; j < num_vendas_pendentes; j++) {
				if (_tcscmp(nomeEmpresa, vendas_pendentes[j].nome_empresa) == 0) {
					vendas_pendentes[j].valor_venda = preco_acao;
					_tprintf_s(_T("Pre�o das vendas pendentes da empresa %s atualizado para %.2f\n"), nomeEmpresa, preco_acao);
				}
			}

			return;
		}
	}
	
	_tprintf_s(_T("Empresa %s n�o encontrada.\n"), nomeEmpresa);


}

void MostraUtilizadores() {
	_tprintf_s(_T("Lista de Utilizadores registados: \n"));
	for (DWORD i = 0; i < num_utilizadores; i++) {
		_tprintf_s(_T("Username: %s, Saldo: %.2f, Estado: %s\n"), utilizadores[i].username, utilizadores[i].saldo, utilizadores[i].ligado ? _T("Ligado") : _T("Desligado"));
	}
}


// Fun��o para manipular o evento de timer
VOID CALLBACK fimTempo(LPVOID lpArg, DWORD dwTimerLowValue, DWORD dwTimerHighValue) {
	
	// Desativar a pausa ap�s o tempo especificado
	pausado = FALSE;

	_tprintf_s(_T("As opera��es de compra e venda foram retomadas.\n"));
}


DWORD WINAPI PauseThread(LPVOID lpParam) {
    DWORD segundos = *(DWORD*)lpParam;

    _tprintf_s(_T("As opera��es de compra e venda est�o suspensas por %d segundos\n"), segundos);

    HANDLE hTimer = CreateWaitableTimer(NULL, FALSE, NULL);
    if (hTimer == NULL) {
        _tprintf_s(_T("Erro ao criar o waitable timer. C�digo de erro: %d\n"), GetLastError());
        return 1;
    }

    LARGE_INTEGER liDueTime;
    liDueTime.QuadPart = -(LONGLONG)segundos * 10000000LL;

    if (!SetWaitableTimer(hTimer, &liDueTime, 0, fimTempo, NULL, FALSE)) {
        _tprintf_s(_T("Erro ao configurar o waitable timer. C�digo de erro: %d\n"), GetLastError());
        CloseHandle(hTimer);
        return 1;
    }

    // Aguardar o evento do timer
    WaitForSingleObject(hTimer, INFINITE);	
	
	

    // Fechar o handle do timer
    CloseHandle(hTimer);



    return 0;
}

void Pause(TCHAR* input) {
    DWORD segundos;
    if (_stscanf_s(input, _T("pause %d"), &segundos) != 1) {
        _tprintf_s(_T("Formato de comando inv�lido. Utilize o seguinte formato para o comando: pause <numero_segundos>\n"));
        return;
    }

	
    //HANDLE hThread = CreateThread(NULL, 0, PauseThread, &segundos, 0, NULL);
    //if (hThread == NULL) {
    //    _tprintf_s(_T("Erro ao criar a thread de pausa. C�digo de erro: %d\n"), GetLastError());
    //    return;
    //}

	_tprintf_s(_T("As opera��es de compra e venda est�o suspensas por %d segundos\n"), segundos);
	pausado = TRUE;

	HANDLE hTimer = CreateWaitableTimer(NULL, FALSE, NULL);
	if (hTimer == NULL) {
		_tprintf_s(_T("Erro ao criar o waitable timer. C�digo de erro: %d\n"), GetLastError());
		return 1;
	}

	LARGE_INTEGER liDueTime;
	liDueTime.QuadPart = -(LONGLONG)segundos * 10000000LL;

	if (!SetWaitableTimer(hTimer, &liDueTime, 0, fimTempo, NULL, FALSE)) {
		_tprintf_s(_T("Erro ao configurar o waitable timer. C�digo de erro: %d\n"), GetLastError());
		CloseHandle(hTimer);
		return 1;
	}

	// Aguardar o evento do timer
	WaitForSingleObject(hTimer, INFINITE);
	pausado = FALSE;


	CloseHandle(hTimer);
    //CloseHandle(hThread);
}




void Close(HANDLE hPipe) {


	_tprintf(_T("Encerrar sistema...\n"));
	HANDLE hEventoSair = CreateEvent(NULL, TRUE,FALSE, EVENTO_SAIR);
	if (hEventoSair == NULL) {
		_tprintf_s(_T("Erro ao abrir evento\n"));
		return 1;
	}


	// Defina o evento para sinalizar que o sistema est� sendo encerrado
	SetEvent(hEventoSair);

	
	// Fechar o evento
	CloseHandle(hEventoSair);

	// Encerrar o processo, se necess�rio
	exit(1);
	
	
}





void loadUtilizadores(TCHAR *filename) {
	FILE* file;
	if (_wfopen_s(&file, filename, _T("r")) != 0) {
		_tprintf(_T("Erro ao abrir o arquivo de utilizadores.\n"));
		return;
	}

	TCHAR username[TAM];
	TCHAR password[TAM];
	float saldo;
	BOOL ligado;
	Utilizador utilizador;
	while (_ftscanf_s(file, _T("%99s %99s %f"), username, TAM, password, TAM, &saldo) == 3) {
		if (num_utilizadores >= MAX_UTILIZADORES) {
			_tprintf(_T("N�mero m�ximo de utilizadores excedido.\n"));
			break;
		}

		_tcscpy_s(utilizador.username, TAM, username);
		_tcscpy_s(utilizador.password, TAM, password);
		utilizador.saldo = saldo;
		utilizador.ligado = FALSE;
		utilizador.num_empresas = 0;
		for (int i = 0; i < MAX_EMPRESAS_CARTEIRA; i++) {
			_tcscpy_s(utilizador.carteira[i].nome_empresa, TAM, _T(""));
			utilizador.carteira[i].num_acoes = 0;
		}


		utilizadores[num_utilizadores++]=utilizador;
	}

	fclose(file);
	_tprintf(_T("Utilizadores lidos do arquivo:\n"));
	for (DWORD i = 0; i < num_utilizadores; i++) {
		_tprintf(_T("Username: %s, Password: %s, Saldo: %.2f, Estado: %s\n"),
			utilizadores[i].username,
			utilizadores[i].password,
			utilizadores[i].saldo,
			utilizadores[i].ligado ? _T("ligado") : _T("Desligado"));
	}
}

BOOL VerificaUtilizador(Utilizador utilizador) {
	for (int i = 0; i < num_utilizadores; i++) {
		if (_tcscmp(utilizador.username, utilizadores[i].username) == 0 && _tcscmp(utilizador.password, utilizadores[i].password) == 0) {
			utilizadores[i].ligado = TRUE;
			return TRUE;
		}

	}
	return FALSE;
}

BOOL VerificaDisponibilidadeAcoes(Empresa empresa) {
	for (int i = 0 ; i < num_empresas; i++) {
		if (_tcscmp(empresa.nome, empresas[i].nome) == 0 && empresa.num_acoes <= empresas[i].num_acoes) {
			return TRUE;
			
		}
		
	}
	return FALSE;
}

BOOL VerificaDisponibilidadeCarteira(Carteira carteira, TCHAR* username) {
	for (int i = 0; i < num_utilizadores; i++) {
		if (_tcscmp(utilizadores[i].username, username) == 0) {
			for (int j = 0; j < utilizadores[i].num_empresas; j++) {
				if (_tcscmp(carteira.nome_empresa, utilizadores[i].carteira[j].nome_empresa) == 0 && carteira.num_acoes <= utilizadores[i].carteira[j].num_acoes) {
					return TRUE;
				}
			}
			break; 
		}
	}
	return FALSE;
}



void DeduzirAcoesCarteira(TCHAR* username, DWORD num_acoes) {
	for (int i = 0; i < num_utilizadores; i++) {
		if (_tcscmp(utilizadores[i].username, username) == 0) {
			for (int j = 0; j < utilizadores[i].num_empresas; j++) {
				// Aqui voc� pode deduzir o n�mero de a��es diretamente da carteira encontrada
				utilizadores[i].carteira[j].num_acoes -= num_acoes;
				return; // A��es deduzidas com sucesso
			}
		}
	}
}

void AtualizarSaldoAposVenda(TCHAR* username, float valorTotalVenda) {
	for (int i = 0; i < num_utilizadores; i++) {
		if (_tcscmp(utilizadores[i].username, username) == 0) {
				utilizadores[i].saldo += valorTotalVenda;
				break;
		}
	}
	
}

void DiminuirPrecoAcoesEmpresa(Carteira* carteira) {
	// Encontrar a empresa na lista de empresas
	for (int i = 0; i < num_empresas; i++) {
		if (_tcscmp(empresas[i].nome, carteira->nome_empresa) == 0) {
			// Diminuir o pre�o das a��es em 20%
			empresas[i].preco_acao *= 0.8; // 20% de desconto
			return;
		}
	}
}

void DiminuirPrecoVendasPendentes(Empresa empresa) {
	for (int i = 0; i < num_vendas_pendentes; i++) {
		if (_tcscmp(vendas_pendentes[i].nome_empresa, empresa.nome) == 0) {
			vendas_pendentes[i].valor_venda *= 0.8; // Diminui o pre�o em 20%
		}
	}
}

float ObterPrecoAcaoEmpresa(TCHAR* nome_empresa) {
	for (int i = 0; i < num_empresas; i++) {
		if (_tcscmp(empresas[i].nome, nome_empresa) == 0) {
			return empresas[i].preco_acao;
		}
	}
	return 0; // Retornar 0 se o nome da empresa n�o for encontrado
}

float CalculaValorVenda(Carteira carteira) {
	float preco_acao = ObterPrecoAcaoEmpresa(carteira.nome_empresa);
	if (preco_acao == 0) {
		// Nome da empresa n�o encontrado ou pre�o da a��o igual a zero
		return 0;
	}
	return carteira.num_acoes * preco_acao;
}

float ConsultaSaldo(TCHAR* username) {
	// Percorre o array de utilizadores para encontrar o saldo correspondente ao nome de utilizador
	for (int i = 0; i < num_utilizadores; i++) {
		if (_tcscmp(username, utilizadores[i].username) == 0) {
			return utilizadores[i].saldo;
		}
	}

	// Se o utilizador n�o for encontrado, retorna um saldo inv�lido (-1, por exemplo)
	return -1.0f; // Modifique conforme necess�rio

}
float CalculaValorCompra(Empresa empresa) {
	return empresa.num_acoes * empresa.preco_acao;
}

BOOL RetirarSaldoCliente(TCHAR* username, float valorTotalCompra) {
	for (int i = 0; i < num_utilizadores; i++) {
		if (_tcscmp(utilizadores[i].username, username) == 0) {
			if (utilizadores[i].saldo >= valorTotalCompra) {
				utilizadores[i].saldo -= valorTotalCompra;
				return TRUE; // Saldo deduzido com sucesso
			}
			else {
				return FALSE; // Saldo insuficiente
			}
		}
	}
	return FALSE; // Utilizador  n�o encontrado
}

void AvisarClientes(TCHAR* mensagem) {
	DWORD bytesWrite;
	for (int i = 0; i < num_utilizadores; i++) {
		WriteFile(utilizadores[i].hPipe, mensagem, (_tcslen(mensagem) + 1) * sizeof(TCHAR), &bytesWrite, NULL);
	}
}

void DeduzirAcoesEmpresa(Empresa empresa) {
	for (int i = 0; i < num_empresas; i++) {
		if (_tcscmp(empresas[i].nome, empresa.nome) == 0) {
			empresas[i].num_acoes -= empresa.num_acoes;
			break;
		}
	}
}

void AumentarPrecoAcoes(Empresa empresa) {
	for (int i = 0; i < num_empresas; i++) {
		if (_tcscmp(empresas[i].nome, empresa.nome) == 0) {
			empresas[i].preco_acao *= 1.2;
			return;
		}
	}
}

void AumentarPrecoAcoesVendasPendentes(Empresa empresa) {
	for (int i = 0; i < num_vendas_pendentes; i++) {
		if (_tcscmp(vendas_pendentes[i].nome_empresa, empresa.nome) == 0) {
			vendas_pendentes[i].valor_venda *= 1.2; // Aumenta o pre�o em 20%
		}
	}
}

float ObterPrecoAcao(TCHAR* nomeEmpresa) {
	for (int i = 0; i < sizeof(empresas) / sizeof(empresas[0]); ++i) {
		if (_tcscmp(empresas[i].nome, nomeEmpresa) == 0) {
			// Retorna o pre�o da a��o se encontrar a empresa
			return empresas[i].preco_acao;
		}
	}
	// Se n�o encontrar a empresa, retorna um pre�o padr�o
	return 0.0;
}

Utilizador* EncontrarUtilizador(TCHAR* username) {
	// Percorre a lista de utilizadores para encontrar o utilizador com o nome de utilizador especificado
	for (int i = 0; i < num_utilizadores; i++) {
		if (_tcscmp(utilizadores[i].username, username) == 0) {
			// Retorna o ponteiro para o utilizador encontrado
			return &utilizadores[i];
		}
	}
	// Se o utilizador n�o for encontrado, retorna NULL
	return NULL;
}


BOOL AtualizarCarteiraAcoes(TCHAR* username, Empresa empresa) {
	// Encontrar o utilizador na lista de utilizadores
	Utilizador* utilizador = EncontrarUtilizador(username);

	// Verificar se o utilizador foi encontrado
	if (utilizador != NULL) {
		// Verificar se o utilizador j� possui a��es da empresa
		int indiceEmpresa = -1;
		for (int i = 0; i < utilizador->num_empresas; i++) {
			if (_tcscmp(utilizador->carteira[i].nome_empresa, empresa.nome) == 0) {
				indiceEmpresa = i;
				break;
			}
		}

		// Se o utilizador j� possui a��es da empresa, atualize o n�mero de a��es
		if (indiceEmpresa != -1) {
			utilizador->carteira[indiceEmpresa].num_acoes += empresa.num_acoes;
			_tprintf_s(_T("N�mero de a��es da empresa %s atualizado para %d\n"), empresa.nome, utilizador->carteira[indiceEmpresa].num_acoes);
			return TRUE;
		}
		// Caso contr�rio, adicione a nova empresa � carteira de a��es do utilizador
		else if (utilizador->num_empresas < MAX_EMPRESAS_CARTEIRA) {
			// Verificar se h� espa�o dispon�vel na carteira
			if (utilizador->num_empresas < MAX_EMPRESAS_CARTEIRA) {
				_tcscpy_s(utilizador->carteira[utilizador->num_empresas].nome_empresa, TAM, empresa.nome);
				utilizador->carteira[utilizador->num_empresas].num_acoes = empresa.num_acoes;
				utilizador->num_empresas++;
				_tprintf_s(_T("Nova empresa %s adicionada � carteira de a��es\n"), empresa.nome);
				return TRUE;
			}
			else {
				_tprintf_s(_T("A carteira de a��es est� cheia. N�o � poss�vel adicionar mais empresas.\n"));
				return FALSE;
			}
		}
		else {
			// Lidar com o caso em que o utilizador j� possui o n�mero m�ximo de empresas na carteira de a��es
			_tprintf_s(_T("O utilizador j� possui o n�mero m�ximo de empresas na carteira de a��es.\n"));
			return FALSE;
		}
	}
	else {
		// Lidar com o caso em que o utilizador n�o foi encontrado
		_tprintf_s(_T("O utilizador n�o foi encontrado.\n"));
		return FALSE;
	}
}

void EnviarCarteiraParaCliente(HANDLE hPipe, Utilizador* utilizador) {
	TCHAR mensagem[TAM];
	DWORD bytesWrite;

	if (utilizador != NULL) {
		if (utilizador->num_empresas > 0) {
			// Construir a mensagem contendo todas as informa��es da carteira
			_stprintf_s(mensagem, TAM, _T("A��es na carteira:\n"));
			for (int i = 0; i < utilizador->num_empresas; i++) {
				TCHAR temp[TAM];
				_stprintf_s(temp, TAM, _T("%s: %d a��es\n"), utilizador->carteira[i].nome_empresa, utilizador->carteira[i].num_acoes);
				_tcscat_s(mensagem, TAM, temp);
			}

			// Enviar a mensagem para o cliente
			if (!WriteFile(hPipe, mensagem, (_tcslen(mensagem) + 1) * sizeof(TCHAR), &bytesWrite, NULL)) {
				_tprintf_s(_T("Erro ao escrever no pipe. C�digo de erro: %d\n"), GetLastError());
				return;
			}
		}
		else {
			_stprintf_s(mensagem, TAM, _T("A sua carteira est� vazia.\n"));
			if (!WriteFile(hPipe, mensagem, (_tcslen(mensagem) + 1) * sizeof(TCHAR), &bytesWrite, NULL)) {
				_tprintf_s(_T("Erro ao escrever no pipe. C�digo de erro: %d\n"), GetLastError());
				return;
			}
		}
	}
	else {
		_stprintf_s(mensagem, TAM, _T("Utilizador n�o encontrado.\n"));
		if (!WriteFile(hPipe, mensagem, (_tcslen(mensagem) + 1) * sizeof(TCHAR), &bytesWrite, NULL)) {
			_tprintf_s(_T("Erro ao escrever no pipe. C�digo de erro: %d\n"), GetLastError());
			return;
		}
	}
}



void RegistarVendaPendente(TCHAR* username, TCHAR* nome_empresa, DWORD num_acoes, float valor_venda) {
	if (num_vendas_pendentes < MAX_VENDAS_PENDENTES) {
		_tcscpy_s(vendas_pendentes[num_vendas_pendentes].username, TAM, username);
		_tcscpy_s(vendas_pendentes[num_vendas_pendentes].nome_empresa, TAM, nome_empresa);
		vendas_pendentes[num_vendas_pendentes].num_acoes = num_acoes;
		vendas_pendentes[num_vendas_pendentes].valor_venda = valor_venda;
		num_vendas_pendentes++;
	}
}

int EncontrarVendaPendente(Empresa empresa) {
	for (int i = 0; i < num_vendas_pendentes; i++) {
		if (_tcscmp(vendas_pendentes[i].nome_empresa, empresa.nome) == 0) {
			// Empresa encontrada nas vendas pendentes
			return i; // Retorna o �ndice da venda pendente
		}
	}
	// Se n�o encontrar nenhuma venda pendente correspondente � empresa, retorna -1
	return -1;
}

void RemoverVendaPendente(int index) {
	if (index < 0 || index >= num_vendas_pendentes) {
		// �ndice inv�lido
		return;
	}

	// Deslocar todas as vendas pendentes ap�s o �ndice para uma posi��o anterior
	for (int i = index; i < num_vendas_pendentes - 1; i++) {
		vendas_pendentes[i] = vendas_pendentes[i + 1];
	}

	// Atualizar o n�mero de vendas pendentes
	num_vendas_pendentes--;
}


DWORD DeduzirAcoesEmpresaDisponiveis(TCHAR* username, Empresa empresa) {
	for (int i = 0; i < num_utilizadores; i++) {
		if (_tcscmp(utilizadores[i].username, username) == 0) {
			for (int j = 0; j < utilizadores[i].num_empresas; j++) {
				if (_tcscmp(utilizadores[i].carteira[j].nome_empresa, empresa.nome) == 0) {
					DWORD num_acoes_disponiveis = min(empresa.num_acoes, utilizadores[i].carteira[j].num_acoes);
					utilizadores[i].carteira[j].num_acoes -= num_acoes_disponiveis;
					return num_acoes_disponiveis;
				}
			}
		}
	}
	return 0; // A��es deduzidas com sucesso
}



void AssociarUtilizadorPipe(HANDLE hPipe, TCHAR* username) {
	for (int i = 0; i < num_utilizadores; i++) {
		if (_tcscmp(utilizadores[i].username, username) == 0) {
			// Atribui o identificador do pipe ao utilizador encontrado
			utilizadores[i].hPipe = hPipe;
			return; // Sai da fun��o ap�s associar o pipe ao utilizador
		}
	}

}

TCHAR* ObterNomeUtilizador(HANDLE hPipe) {
	for (int i = 0; i < num_utilizadores; i++) {
		if (utilizadores[i].hPipe == hPipe) {
			return utilizadores[i].username;
			
		}
	}
	return NULL;
}
HANDLE WriteReady;
int writeClientes(HANDLE hPipe, Msg msg) {
	DWORD cbWritten = 0;
	BOOL fSuccess = FALSE;
	OVERLAPPED OverlWr = { 0 };
	
	if (WriteReady == NULL) {
		_tprintf_s(_T("Erro ao criar evento. C�digo de erro: %d\n"), GetLastError());
		return 1;
	}

	

	ZeroMemory(&OverlWr, sizeof(OverlWr));
	ResetEvent(WriteReady);
	OverlWr.hEvent = WriteReady;
	fSuccess = WriteFile(hPipe, &msg, sizeof(Msg), &cbWritten, &OverlWr);
	if (fSuccess == FALSE) {
		if (GetLastError() == ERROR_IO_PENDING) {
			_tprintf_s(_T("Agendei escrita...\n"));
			WaitForSingleObject(WriteReady, INFINITE);
			GetOverlappedResult(hPipe, &OverlWr, &cbWritten, FALSE);
		}
		else {
			_tprintf_s(_T("Erro na escrita. C�digo de erro: %d\n"), GetLastError());
		}
	}
	else {
		_tprintf_s(_T("A enviar: %s\n"), msg.msg);
	}

	CloseHandle(WriteReady);
	return 0;
}


void EnviarMensagemParaTodos(Msg msg) {
	for (int i = 0; i < num_utilizadores; i++) {
		writeClientes(utilizadores[i].hPipe,msg);
	}
}

DWORD WINAPI AtualizarPrecosAcoes(LPVOID lpParam) {
	Empresa* empresas = (Empresa*)lpParam;
	srand((unsigned int)time(NULL));

	while (1) {
		for (int i = 0; i < num_empresas; i++) {
			EnterCriticalSection(&empresas[i].cs);
			float variacao = ((float)rand() / RAND_MAX - 0.5) * 0.4;
			empresas[i].preco_acao *= (1 + variacao); // Varia��o aleat�ria entre -20% e 20%
			_tprintf_s(_T("Pre�o da empresa %s alterado de %.2f para %.2f\n"), empresas[i].nome, empresas[i].preco_acao / (1 + variacao), empresas[i].preco_acao);
			LeaveCriticalSection(&empresas[i].cs);
		}
		Sleep(10000); // Aguarda 5 segundos antes de atualizar novamente
	}
	return 0;
}

DWORD WINAPI TrataCliente(LPVOID dados) {
	HANDLE hPipe = (HANDLE*)dados;
	TCHAR buffer[TAM], resposta[TAM], pergunta[TAM], mensagem[TAM];
	DWORD bytesRead, bytesWrite;
	Utilizador utilizador;
	Empresa empresa;
	Carteira carteira;
	
	

	while (1) {
		if (!ReadFile(hPipe, buffer, TAM * sizeof(TCHAR), &bytesRead, NULL)) {
			_tprintf_s(_T("Erro ao ler do pipe\n"));
			break;
		}

		_tprintf_s(_T("Comando recebido do cliente: %s\n"), buffer);

	
		 if (_tcscmp(buffer, _T("login")) == 0) {
		
			if (!ReadFile(hPipe, &utilizador, sizeof(utilizador), &bytesRead, NULL)) {
				_tprintf_s(_T("Erro ao ler do pipe\n"));
				break;
			}

			if (VerificaUtilizador(utilizador)) {
				_tprintf_s(_T("Credenciais v�lidas.\n"));
				_stprintf_s(resposta, TAM, _T("Bem-vindo, %s"), utilizador.username);
				AssociarUtilizadorPipe(hPipe, utilizador.username);
				
				

			}
			else {
				_tprintf_s(_T("Credenciais inv�lidas.\n"));
				_stprintf_s(resposta, TAM, _T("Username ou password incorretos"));
			}

			if (!WriteFile(hPipe, resposta, (_tcslen(resposta) + 1) * sizeof(TCHAR), &bytesWrite, NULL)) {
				_tprintf_s(_T("Erro ao escrever no pipe. C�digo de erro: %d\n"), GetLastError());
				// Encerra a execu��o da fun��o ou retorna uma mensagem de erro, conforme necess�rio
				break;
			}
			
		}

		else if (_tcscmp(buffer, _T("listc")) == 0) {
			
			// Enviar o n�mero total de empresas para o cliente
			if (!WriteFile(hPipe, &num_empresas, sizeof(num_empresas), &bytesWrite, NULL)) {
				_tprintf_s(_T("Erro ao enviar o n�mero de empresas para o cliente. C�digo de erro: %d\n"), GetLastError());
				return;
			}

			// Enviar cada empresa individualmente para o cliente
			for (int i = 0; i < num_empresas; i++) {
				if (!WriteFile(hPipe, &empresas[i], sizeof(Empresa), &bytesWrite, NULL)) {
					_tprintf_s(_T("Erro ao enviar a empresa para o cliente. C�digo de erro: %d\n"), GetLastError());
					return;
				}
			}

			_tprintf_s(_T("Empresas enviadas para o cliente com sucesso.\n"));

		}

		else if (_tcscmp(buffer, _T("balance")) == 0) {
			
			TCHAR* username = ObterNomeUtilizador(hPipe);
			if (username == NULL) {
				_tprintf_s(_T("Erro ao obter o nome do cliente associado ao pipe.\n"));
				return;
			}
			

			// Obtem o saldo correspondente ao nome de utilizador 
			float saldo = ConsultaSaldo(username);
			
			// Converte o saldo para uma string formatada
			TCHAR saldoStr[TAM];
			_stprintf_s(saldoStr, TAM, _T("%.2f"), saldo);
			

			// Envia o saldo de volta para o cliente
			if (!WriteFile(hPipe, saldoStr, (_tcslen(saldoStr) + 1) * sizeof(TCHAR), &bytesWrite, NULL)) {
				_tprintf_s(_T("Erro ao escrever no pipe. C�digo de erro: %d\n"), GetLastError());
				// Encerra a execu��o da fun��o ou retorna uma mensagem de erro, conforme necess�rio
				return;
			}
			
			
		}

		else if (_tcscmp(buffer, _T("buy")) == 0) {
			
			if (!ReadFile(hPipe, &empresa, sizeof(empresa), &bytesRead, NULL)) {
				_tprintf_s(_T("Erro ao ler do pipe\n"));
				break;
			}
			
			if (pausado) {
				_stprintf_s(resposta, TAM, _T("Erro: As opera��es est�o pausadas no momento. Por favor, tente novamente mais tarde.\n"));
			}
			else {
				float preco_acao = ObterPrecoAcao(empresa.nome);
				empresa.preco_acao = preco_acao;

				TCHAR* username = ObterNomeUtilizador(hPipe);
				if (username == NULL) {
					_tprintf_s(_T("Erro ao obter o nome do cliente associado ao pipe.\n"));
					return;
				}
				_tprintf_s(_T("Cliente %s quer comprar %d a��es da empresa %s\n"), username, empresa.num_acoes, empresa.nome);

				if (VerificaDisponibilidadeAcoes(empresa)) {
					float valorCompra = CalculaValorCompra(empresa);
					if (RetirarSaldoCliente(username, valorCompra)) {
						if (AtualizarCarteiraAcoes(username, empresa)) {
							DeduzirAcoesEmpresa(empresa);
							
							_tcscpy_s(ultima_transacao.nome, TAM, empresa.nome);
							ultima_transacao.num_acoes = empresa.num_acoes;
							ultima_transacao.valor_transacao = valorCompra;
							//_tcscpy_s(ultima_transacao.tipo_transacao, TAM, _T("Compra"));

							_tprintf_s(_T("Cliente %s comprou %d a��es da empresa %s que custou %f\n"), username, empresa.num_acoes, empresa.nome, valorCompra);
							_stprintf_s(resposta, TAM, _T("Compra de %d a��es da empresa %s aceite"), empresa.num_acoes, empresa.nome);
							
							AumentarPrecoAcoes(empresa);
							AumentarPrecoAcoesVendasPendentes(empresa);
					
							
						}
						else {
							_tprintf_s(_T("N�o foi poss�vel atualizar a carteira de a��es.\n"));
							_stprintf_s(resposta, TAM, _T("Erro: N�o foi poss�vel atualizar a carteira de a��es"));
						}
					}
					else {
						_tprintf_s(_T("Cliente %s n�o conseguiu %d a��es da empresa %s\n"), username, empresa.num_acoes, empresa.nome);
						_stprintf_s(resposta, TAM, _T("Erro: Saldo insuficiente para realizar a compra"));
					}
				}
				else {
					int index_venda = EncontrarVendaPendente(empresa);
					if (index_venda != -1 && _tcscmp(username, vendas_pendentes[index_venda].username) != 0) {
						float valorCompra = CalculaValorCompra(empresa);
						if (RetirarSaldoCliente(username, valorCompra)) {
							if (AtualizarCarteiraAcoes(username, empresa)) {
								//_tcscpy_s(ultima_transacao.nome, TAM, empresa.nome);
								//ultima_transacao.num_acoes = empresa.num_acoes;
								//ultima_transacao.valor_transacao = valorCompra;
								//_tcscpy_s(ultima_transacao.tipo_transacao, TAM, _T("Compra"));
								
								AtualizarSaldoAposVenda(vendas_pendentes[index_venda].username, valorCompra);
								
								_tprintf_s(_T("Cliente %s comprou %d a��es da empresa %s ao cliente %s que custou %f\n"), username, empresa.num_acoes, empresa.nome, vendas_pendentes[index_venda].username, valorCompra);
								_stprintf_s(resposta, TAM, _T("Compra de %d a��es da empresa %s a %s aceite"), empresa.num_acoes, empresa.nome, vendas_pendentes[index_venda].username);
								
															
								
								AumentarPrecoAcoes(empresa);
								AumentarPrecoAcoesVendasPendentes(empresa);
								
								_tcscpy_s(ultima_transacao.nome, TAM, empresa.nome);
								ultima_transacao.num_acoes = empresa.num_acoes;
								ultima_transacao.valor_transacao = valorCompra;
								//_tcscpy_s(ultima_transacao.tipo_transacao, TAM, _T("Venda"));
								
								// Atualizar a venda pendente se necess�rio
								if (empresa.num_acoes < vendas_pendentes[index_venda].num_acoes) {
									vendas_pendentes[index_venda].num_acoes -= empresa.num_acoes;
								}
								else {
									RemoverVendaPendente(index_venda);
								}
								
							}
							else {
								_tprintf_s(_T("N�o foi poss�vel atualizar a carteira de a��es.\n"));
								_stprintf_s(resposta, TAM, _T("Erro: N�o foi poss�vel atualizar a carteira de a��es"));
							}
						}
						else {
							_tprintf_s(_T("Cliente %s n�o conseguiu %d a��es da empresa %s\n"), username, empresa.num_acoes, empresa.nome);
							_stprintf_s(resposta, TAM, _T("Erro: Saldo insuficiente para realizar a compra"));
						}
					}
					else {
						_stprintf_s(resposta, TAM, _T("Erro: N�o h� vendas pendentes para essa empresa nem existe a��es que sobrem da empresa"));
					}
				}
			}

			if (!WriteFile(hPipe, resposta, (_tcslen(resposta) + 1) * sizeof(TCHAR), &bytesWrite, NULL)) {
				_tprintf_s(_T("Erro ao enviar resposta para o cliente. C�digo de erro: %d\n"), GetLastError());
				return;
			}
			//Msg mensagem;
		    //_stprintf_s(mensagem.msg, TAM, _T("O preco da a��o da empresa %s subiu para %f"),
		     //empresa.nome, empresa.preco_acao);
			//EnviarMensagemParaTodos(mensagem);
		}

			else if (_tcscmp(buffer, _T("sell"))==0){
			if (!ReadFile(hPipe, &carteira, sizeof(carteira), &bytesRead, NULL)) {
				_tprintf_s(_T("Erro ao ler do pipe\n"));
				break;
			}
			DWORD num_acoes = carteira.num_acoes;
			TCHAR* username = ObterNomeUtilizador(hPipe);
			if (username == NULL) {
				_tprintf_s(_T("Erro ao obter o nome do cliente associado ao pipe.\n"));
				return;
			}
			_tprintf_s(_T("Cliente %s quer vender %d a��es da empresa %s\n"), username, carteira.num_acoes, carteira.nome_empresa);
			


			if (!VerificaDisponibilidadeCarteira(carteira,username)) {
				_tprintf_s(_T("Cliente %s n�o conseguiu vender %d a��es da empresa %s\n"), username, carteira.num_acoes, carteira.nome_empresa);
				_stprintf_s(resposta, TAM, _T("Erro:Nao tem essa quantidade de a��es na carteira ou n�o tem essa empresa"));
				
			}

			else {

				DiminuirPrecoAcoesEmpresa(&carteira);
				DiminuirPrecoVendasPendentes(empresa);
				float valorVenda = ObterPrecoAcaoEmpresa(carteira.nome_empresa);
				DeduzirAcoesCarteira(username, carteira.num_acoes);
				RegistarVendaPendente(username, carteira.nome_empresa, carteira.num_acoes, valorVenda);
			
				
				_tprintf_s(_T("Cliente %s colocou � venda %d a��es da empresa %s\n"), username, carteira.num_acoes, carteira.nome_empresa);
				_stprintf_s(resposta, TAM, _T("Venda de %d a��es da empresa %s registada"), carteira.num_acoes, carteira.nome_empresa);
				
			}


			if (!WriteFile(hPipe, resposta, (_tcslen(resposta) + 1) * sizeof(TCHAR), &bytesWrite, NULL)) {
				_tprintf_s(_T("Erro ao enviar resposta para o cliente. C�digo de erro: %d\n"), GetLastError());
				return;
			}


		}

		else if (_tcscmp(buffer, _T("carteira")) == 0) {

			TCHAR* username = ObterNomeUtilizador(hPipe);
			if (username == NULL) {
				_tprintf_s(_T("Erro ao obter o nome do cliente associado ao pipe.\n"));
				return;
			}

			Utilizador* utilizador = EncontrarUtilizador(username);
			if (utilizador != NULL) {
				EnviarCarteiraParaCliente(hPipe, utilizador);
			}


		}

		else if (_tcscmp(buffer, _T("vendas")) == 0) {
			TCHAR vendas_info[TAM]; // Defina MAX_INFO_LENGTH conforme necess�rio
			vendas_info[0] = _T('\0'); // Inicialize a string vazia

			for (int i = 0; i < num_vendas_pendentes; i++) {
				TCHAR temp[TAM]; // Usaremos uma string tempor�ria para armazenar cada linha de informa��o
				_stprintf_s(temp, TAM, _T("Cliente: %s, Empresa: %s, A��es: %d, Pre�o por a��o: %.2f\n"),
					vendas_pendentes[i].username,
					vendas_pendentes[i].nome_empresa,
					vendas_pendentes[i].num_acoes,
					vendas_pendentes[i].valor_venda);
				_tcscat_s(vendas_info,TAM, temp); // Concatenar a informa��o da venda pendente � string principal
			}

			// Enviar as informa��es das vendas pendentes para o cliente
			DWORD bytesWritten;
			if (!WriteFile(hPipe, vendas_info, (_tcslen(vendas_info) + 1) * sizeof(TCHAR), &bytesWritten, NULL)) {
				_tprintf_s(_T("Erro ao enviar informa��es das vendas pendentes para o cliente. C�digo de erro: %d\n"), GetLastError());
			}
		}

		else if (_tcscmp(buffer, _T("sair")) == 0) {
			char *username = ObterNomeUtilizador(hPipe);
			for (int i = 0; i < num_utilizadores; ++i) {
				if (_tcscmp(utilizadores[i].username, username) == 0) {
					// Atualiza o estado do cliente para desligado
					utilizadores[i].ligado = FALSE;
					_tprintf_s(_T("Cliente %s saiu\n"), username);
					break;
				}
			}
			break;
			
		}
			
	}
	
	FlushFileBuffers(hPipe);
	if (!DisconnectNamedPipe(hPipe)) {
		_tprintf_s(_T("Erro a desligar do pipe\n"));
			
	}

	CloseHandle(hPipe);
	return 0;

}


DWORD WINAPI EscreveMemoria(LPVOID dados) {

	Empresa* pdados = (Empresa*)dados;
	//ControlData* pevento = (ControlData*)dados;

	HANDLE hTrinco, hMap,hMapUltimaTransacao, hWriteSem, hReadSem, hEventoSair;
	Empresa* pEmpresas;
	UltimaTransacao* pUltimaTransacao;
	//ControlData eventos;

	
	hTrinco = CreateMutex(NULL, FALSE, NOME_MUTEX);
	if (hTrinco == NULL) {
		_tprintf_s(_T("Erro ao criar mutex\n"));
		return 1;
	}

	hWriteSem = CreateSemaphore(NULL, TAM_SHN, TAM_SHN, SEM_WRITE_NAME);
	if (hWriteSem == NULL) {
		_tprintf_s(_T("Erro ao criar semaforo para escrita\n"));
		CloseHandle(hTrinco);
		return 1;
	}

	hReadSem = CreateSemaphore(NULL, 0, TAM_SHN, SEM_READ_NAME);
	if (hReadSem == NULL) {
		_tprintf_s(_T("Erro ao criar semaforo para leitura\n"));
		CloseHandle(hWriteSem);
		CloseHandle(hTrinco);
		return 1;
	}

	


	hMap = CreateFileMapping(INVALID_HANDLE_VALUE, NULL, PAGE_READWRITE, 0, TAM_SHN * sizeof(Empresa), NOME_SHN);
	if (hMap == NULL) {
		_tprintf_s(_T("Erro ao criar mapeamento de arquivo\n"));
		return 1;
	}

	hMapUltimaTransacao = CreateFileMapping(INVALID_HANDLE_VALUE, NULL, PAGE_READWRITE, 0, TAM_SHN * sizeof(UltimaTransacao), NOME_SHNM);
	if (hMapUltimaTransacao == NULL) {
		_tprintf_s(_T("Erro ao criar mapeamento de arquivo\n"));
		return 1;
	}
	
	

	pEmpresas = (Empresa*)MapViewOfFile(hMap, FILE_MAP_READ | FILE_MAP_WRITE, 0, 0, TAM_SHN * sizeof(Empresa));
	if (pEmpresas == NULL) {
		_tprintf_s(_T("Erro ao mapear arquivo na mem�ria\n"));
		CloseHandle(hMap);
		CloseHandle(hTrinco);
		return 1;
	}

	pUltimaTransacao = (UltimaTransacao*)MapViewOfFile(hMapUltimaTransacao, FILE_MAP_READ | FILE_MAP_WRITE, 0, 0, sizeof(UltimaTransacao));
	if (pUltimaTransacao == NULL) {
		_tprintf_s(_T("Erro ao mapear arquivo na mem�ria para a �ltima transa��o\n"));
		CloseHandle(hMapUltimaTransacao);
		CloseHandle(hMap);
		CloseHandle(hTrinco);
		return 1;
	}

	while (TRUE) {
		// Espera pelo evento ser sinalizado
		//WaitForSingleObject(pevento->hEventoDadosProntos, INFINITE);

		WaitForSingleObject(hWriteSem, INFINITE);

		WaitForSingleObject(hTrinco, INFINITE);

		for (int i = 0; i < num_empresas; i++) {
			_tcscpy_s(pEmpresas[i].nome, TAM, pdados[i].nome);
			pEmpresas[i].num_acoes = pdados[i].num_acoes;
			pEmpresas[i].preco_acao = pdados[i].preco_acao;
		}


		_tcscpy_s(pUltimaTransacao->nome, TAM, ultima_transacao.nome);
		pUltimaTransacao->num_acoes = ultima_transacao.num_acoes;
		pUltimaTransacao->valor_transacao = ultima_transacao.valor_transacao;
		//_tcscpy_s(pUltimaTransacao->tipo_transacao, TAM, ultima_transacao.tipo_transacao);
		
		ReleaseMutex(hTrinco);

		ReleaseSemaphore(hReadSem, 1, NULL);
	}
	
	
	UnmapViewOfFile(pEmpresas);
	CloseHandle(hMap);
	CloseHandle(hWriteSem);
	CloseHandle(hReadSem);
	CloseHandle(hTrinco);
	return 0;
}



DWORD WINAPI LerComandos(LPVOID lpParam) {
	//HANDLE hPipe = (HANDLE)lpParam;
	
	TCHAR cmd[TAM];
	do {
		_tprintf_s(_T("Comando: "));
		_fgetts(cmd, TAM, stdin);

		verificacomando(cmd);

		_tprintf(_T("\n"));

		if (_tcscmp(cmd, _T("close")) == 0) break;

	} while (1);

	return 0;
}


int _tmain(int argc, LPTSTR argv[]) {
	 WriteReady = CreateEvent(NULL, TRUE, FALSE, NULL);
	
	TCHAR nome_fich_utilizadores[255];
	HKEY hkey;
	LSTATUS res;
	DWORD estado, num_clientes, num=0;
	TCHAR chave_nome[TAM], par_nome[TAM], par_valor[TAM];
	HANDLE  hThreadMemoria, hPipe, hThreadCliente;

	
	#ifdef UNICODE
		_setmode(_fileno(stdin), _O_WTEXT);
		_setmode(_fileno(stdout), _O_WTEXT);
	#endif

	if (argc < 2) {
		_tprintf(_T("\nFalta o nome do  arquivo de clientes\n"));
		return 1;
	}

	
	
	_tcscpy_s(nome_fich_utilizadores, TAM, argv[1]);
	loadUtilizadores(nome_fich_utilizadores);
	
	
	num_clientes = CriarChave();
	
	
	

	HANDLE hThreadComandos = CreateThread(NULL, 0, LerComandos,NULL, 0, NULL);
	if (hThreadComandos == NULL) {
		_tprintf_s(_T("Erro ao criar a thread de leitura de comandos. C�digo de erro: %d\n"), GetLastError());
		return 1;
	}
	
	hThreadMemoria = CreateThread(NULL, 0, EscreveMemoria, empresas, 0, NULL);
	if (hThreadMemoria == NULL) {
		_tprintf_s(_T("Erro ao criar a thread. C�digo de erro: %d\n"), GetLastError());
		return 1;
	}

	//hThreadEventos = CreateThread(NULL, 0, ThreadCriarEvento, &eventos, 0, NULL);
	//if (hThreadEventos == NULL) {
//		_tprintf_s(_T("Erro ao criar thread\n"));
//		return;
	//}

	

		
	while (1) {
		hPipe = CreateNamedPipe(PIPE_NAME, PIPE_ACCESS_DUPLEX | FILE_FLAG_OVERLAPPED, PIPE_WAIT | PIPE_TYPE_MESSAGE | PIPE_READMODE_MESSAGE , num_clientes, TAM, TAM, 10000, NULL);
		if (hPipe == INVALID_HANDLE_VALUE) {
			_tprintf_s(_T("Erro a criar Named Pipe"));
			return 1;
		}

		DWORD dwMode = PIPE_READMODE_MESSAGE;
		BOOL fSuccess = SetNamedPipeHandleState(hPipe, &dwMode, NULL, NULL);
		if (!fSuccess) {
			_tprintf_s(_T("Erro ao configurar o modo de mensagem do Named Pipe. C�digo de erro: %d\n"), GetLastError());
			CloseHandle(hPipe);
		
			return -1;
		}
	

		if (!ConnectNamedPipe(hPipe, NULL)) {
			_tprintf_s(_T("Erro a conectar com o cliente"));
			return 1;
		}
		
		hThreadCliente = CreateThread(NULL, 0, TrataCliente,(LPVOID)hPipe, 0, NULL);
		if (hThreadCliente == NULL) {
			_tprintf_s(_T("Erro ao criar a thread. C�digo de erro: %d\n"), GetLastError());
			CloseHandle(hPipe);
			return 1;
		}

	}
	

	WaitForSingleObject(hThreadMemoria, INFINITE);
	WaitForSingleObject(hThreadComandos, INFINITE);
	WaitForSingleObject(hThreadCliente, INFINITE);
	
	
	CloseHandle(hThreadMemoria);
	CloseHandle(hThreadComandos);
	CloseHandle(hThreadCliente);
	
	return 0;

}