#pragma once
#include "../bolsa/utils.h"


//  FUN��ES DE COMANDOS

void comandos_cmd();
void addEmpresa(TCHAR *input);
void loadEmpresas();
void listEmpresas();
void RedefineCusto(TCHAR* input);
void MostraUtilizadores();
void Pause(TCHAR *input);
void Close(HANDLE hPipe);

static const struct comando comandos[] = {
    {_T("ajuda"),_T("Mostra a lista de comandos permitidos"),&comandos_cmd},
    {_T("addc"),_T("Acrescenta uma empresa"),&addEmpresa},
    {_T("load"),_T("Carrega empresas de um ficheiro de texto"),&loadEmpresas},
    {_T("listc"),_T("Lista todas as empresas"),&listEmpresas},
    {_T("stock"),_T("Redefine o custo das a��es de uma empresa"),&RedefineCusto},
    {_T("users"),_T("Permite listar todos os utilizadores registados"),&MostraUtilizadores},
    {_T("pause"),_T("As opera��es de compra e venda s�o suspensas (ignoradas) durante um per�odo de tempo"),&Pause},
    {_T("close"),_T("Encerra sistema"),&Close}
    

};