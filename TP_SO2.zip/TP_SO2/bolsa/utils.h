#pragma once

#include <windows.h>
#include <tchar.h>
#include <fcntl.h>
#include <io.h>
#include <stdio.h>

#define MAX_EMPRESAS 30
#define MAX_EMPRESAS_CARTEIRA 5
#define MAX_EMPRESAS_UTILIZADOR 5
#define MAX_VENDAS_PENDENTES    5
#define MAX_UTILIZADORES 20
#define TAM 200
#define NOME_MUTEX _T("trinco")
#define TAM_SHN 10
#define NOME_SHN _T("empresas")
#define NOME_SHNM _T("transacao")
#define SEM_WRITE_NAME TEXT("SEM_WRITE")  // nome do semaforo de escrita
#define SEM_READ_NAME TEXT("SEM_READ")    // nome do semaforo de leitura
#define EVENTO_SAIR TEXT("ServidorSairEvento")
#define EVENTO_LISTC TEXT("EventoListc")
#define PIPE_NAME _T("\\\\.\\pipe\\teste")
#define MAX_TENTATIVAS 3


struct comando {
	TCHAR* nome;
	TCHAR* descricao;
	void(*func)(TCHAR*);
};

typedef struct Emp {
	TCHAR nome[TAM];
	DWORD num_acoes;
	float preco_acao;
	CRITICAL_SECTION cs;
}Empresa;

typedef struct carteira {
	TCHAR nome_empresa[TAM];
	DWORD num_acoes;
}Carteira;


typedef struct cliente {
	TCHAR username[TAM];
	TCHAR password[TAM];
	float saldo;
	BOOL ligado;
	HANDLE hPipe;
	int num_empresas; // N�mero atual de empresas na carteira de a��es
	Carteira carteira[MAX_EMPRESAS_CARTEIRA];

}Utilizador;


typedef struct {
	TCHAR username[TAM];
	TCHAR nome_empresa[TAM];
	DWORD num_acoes;
	float valor_venda;
} VendaPendente;



typedef struct Transacao {
	TCHAR nome[TAM];
	int num_acoes;
	float valor_transacao;
	//TCHAR tipo_transacao[TAM];
} UltimaTransacao;

typedef struct Mensagem {
	TCHAR msg[TAM];
}Msg;

typedef struct {
	DWORD limite_superior;
	DWORD limite_inferior;
	DWORD num_empresas;
}DATA;


typedef struct {
	HANDLE hFich, hMap, hMapUltimaTransacao, hTrinco, hWriteSem, hReadSem, hEventoSair, hThread;
	Empresa* pEmpresas;
	UltimaTransacao* pUltimaTransacao;
	DATA data;
	HWND hWnd;
} INFO;




// Vetor para armazenar as empresas
Empresa empresas[MAX_EMPRESAS];
Utilizador utilizadores[MAX_UTILIZADORES];
VendaPendente vendas_pendentes[MAX_VENDAS_PENDENTES];

int num_empresas = 0;
int num_utilizadores = 0;
int num_vendas_pendentes = 0;


UltimaTransacao ultima_transacao;