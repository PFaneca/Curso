#include "../bolsa/utils.h"
#include "cliente.h"


void verificacomando(TCHAR* cmd, HANDLE hPipe) {
	if (_tcsclen(cmd) == 0)
		return;

	TCHAR straux[TAM];
	_tcscpy_s(straux, TAM, cmd);

	TCHAR delim[] = _T(" \n");
	TCHAR* context = NULL; // Inicializando o ponteiro de contexto
	TCHAR* ptr = _tcstok_s(straux, delim, &context); // Usando _tcstok_s para strings wide
	//_tprintf(_T("%s"), ptr);
	int cmd_len = (sizeof comandos / sizeof(struct comando));
	for (DWORD i = 0; i < cmd_len; i++) {
		if (_tcscmp(comandos[i].nome, ptr) == 0) {

			comandos[i].func(cmd,hPipe); // Passando ptr como argumento
			return;
		}
	}

	_tprintf(_T("Comando desconhecido: %s\n"), cmd);

}


void comandos_cmd() {
	_tprintf_s(_T("Lista de comandos permitidos\n"));
	for (DWORD i = 0; i < (sizeof comandos / sizeof(struct comando)); i++) {
		_tprintf_s(_T("%s - %s\n"), comandos[i].nome, comandos[i].descricao);
	}

}

void login(TCHAR* input, HANDLE hPipe) {
	TCHAR resposta[TAM];
	Utilizador utilizador;
	TCHAR nome[TAM], password[TAM];

	// Usar sscanf_s para extrair os par�metros
	if (_stscanf_s(input, _T("login %99s %99s"), nome, TAM, password, TAM) != 2) {
		_tprintf_s(_T("Formato de comando inv�lido. Utilize o seguinte formato para o comando: login <username> <password>\n"));
		return;
	}

	if (num_utilizadores > MAX_UTILIZADORES) {
		_tprintf_s(_T("Limite m�ximo de utilizadores alcan�ado.\n"));
		return;
	}
	


	//_tprintf_s(_T("Login efetuado com sucesso: %s - %s\n"), nome,password);
	_tcscpy_s(utilizador.username, TAM, nome);
	_tcscpy_s(utilizador.password, TAM, password);

	
	
	// Enviar as credenciais para o servidor
	DWORD bytes_written;
	if (!WriteFile(hPipe, &utilizador, sizeof(Utilizador), &bytes_written, NULL)) {
		_tprintf_s(_T("Erro ao enviar dados para o servidor. C�digo de erro: %d\n"), GetLastError());
		CloseHandle(hPipe);
		return;
	}
	_tprintf_s(_T("Credenciais enviadas com sucesso para o servidor.\n"));
	

	DWORD bytes_read;
	if (!ReadFile(hPipe, resposta, sizeof(resposta), &bytes_read, NULL)) {
		_tprintf_s(_T("Erro ao receber dados do servidor. C�digo de erro: %d\n"), GetLastError());
		CloseHandle(hPipe);
		return;
	}

	// Imprimir a resposta do servidor
	_tprintf_s(_T("%s\n"), resposta);

		
}




void listaEmpresas(TCHAR *input,HANDLE hPipe) {
	
	TCHAR buffer[TAM];
	DWORD bytesRead;
	int num_empresas;

	// Ler o n�mero total de empresas do servidor
	if (!ReadFile(hPipe, &num_empresas, sizeof(num_empresas), &bytesRead, NULL)) {
		_tprintf_s(_T("Erro ao ler o n�mero de empresas do servidor. C�digo de erro: %d\n"), GetLastError());
		return;
	}

	_tprintf_s(_T("N�mero total de empresas: %d\n"), num_empresas);

	// Ler cada empresa individualmente
	for (int i = 0; i < num_empresas; i++) {
		Empresa empresa;

		if (!ReadFile(hPipe, &empresa, sizeof(Empresa), &bytesRead, NULL)) {
			_tprintf_s(_T("Erro ao ler a empresa do servidor. C�digo de erro: %d\n"), GetLastError());
			return;
		}

		// Processar a empresa recebida, por exemplo, exibir seus detalhes
		_tprintf_s(_T("Empresa %s: %d a��es, pre�o por a��o: %.2f\n"), empresa.nome, empresa.num_acoes, empresa.preco_acao);
	}

}

void BuyAcoes(TCHAR* input,HANDLE hPipe) {
	TCHAR nomeEmpresa[TAM], mensagem[TAM], resposta[TAM];
	DWORD num_acoes, bytesWrite, bytesRead;
	float preco_total;
	Utilizador *utilizador=NULL;
	Empresa empresa;

	if (_stscanf_s(input, _T("buy %99s %d"), nomeEmpresa, TAM, &num_acoes) != 2) {
		_tprintf_s(_T("Formato de comando inv�lido. Utilize o seguinte formato para o comando: buy <nomeEmpresa> <num_acoes>\n"));
		return;
	}

	_tcscpy_s(empresa.nome, TAM, nomeEmpresa);
	empresa.num_acoes = num_acoes;

	if (!WriteFile(hPipe, &empresa,sizeof(empresa), &bytesWrite, NULL)) {
		_tprintf_s(_T("Erro ao para o servidor. C�digo de erro: %d\n"), GetLastError());
		return;
	}

	if (!ReadFile(hPipe, resposta, TAM * sizeof(TCHAR), &bytesRead, NULL)) {
		_tprintf_s(_T("Erro ao receber resposta do servidor. C�digo de erro: %d\n"), GetLastError());
		return;
	}

	_tprintf_s(_T("%s\n"), resposta);

	
}


void SellAcoes(TCHAR* input,HANDLE hPipe) {
	TCHAR nomeEmpresa[TAM], resposta[TAM];
	DWORD num_acoes, bytesWrite, bytesRead;
	Carteira carteira;

	if (_stscanf_s(input, _T("sell %99s %d"), nomeEmpresa, TAM, &num_acoes) != 2) {
		_tprintf_s(_T("Formato de comando inv�lido. Utilize o seguinte formato para o comando: sell <nomeEmpresa> <num_acoes>\n"));
		return;
	}

	_tcscpy_s(carteira.nome_empresa, TAM, nomeEmpresa);
	carteira.num_acoes = num_acoes;

	if (!WriteFile(hPipe, &carteira, sizeof(carteira), &bytesWrite, NULL)) {
		_tprintf_s(_T("Erro ao para o servidor. C�digo de erro: %d\n"), GetLastError());
		return;
	}

	if (!ReadFile(hPipe, resposta, TAM * sizeof(TCHAR), &bytesRead, NULL)) {
		_tprintf_s(_T("Erro ao receber resposta do servidor. C�digo de erro: %d\n"), GetLastError());
		return;
	}

	_tprintf_s(_T("%s\n"), resposta);

}

void ConsultaSaldo(TCHAR* input,HANDLE hPipe) {
	DWORD bytesWrite;
	TCHAR comando[TAM];
	

	// Aguarda a resposta do servidor
	TCHAR resposta[TAM];
	DWORD bytesRead;
	if (!ReadFile(hPipe, resposta, TAM * sizeof(TCHAR), &bytesRead, NULL)) {
		_tprintf_s(_T("Erro ao receber resposta do servidor. C�digo de erro: %d\n"), GetLastError());
		CloseHandle(hPipe);
		return;
	}

	// Exibe a resposta do servidor (saldo)
	_tprintf_s(_T("Saldo: %s\n"), resposta);
	//CloseHandle(hEvento);
}


void Sair() {
	_tprintf_s(_T("Sair do sistema..."));
	exit(1);
}


void consultaCarteira(TCHAR *input,HANDLE hPipe) {
	DWORD bytesWrite, bytesRead;
	TCHAR resposta[TAM], mensagem[TAM];
	

	if (!ReadFile(hPipe, resposta, TAM * sizeof(TCHAR), &bytesRead, NULL)) {
		_tprintf_s(_T("Erro ao receber resposta do servidor. C�digo de erro: %d\n"), GetLastError());
		CloseHandle(hPipe);
		return;
	}

	_tprintf_s(_T("%s\n"), resposta);

}


void vendasPendentes(TCHAR* input, HANDLE hPipe) {
	DWORD bytesWrite, bytesRead;
	TCHAR resposta[TAM];

	if (!ReadFile(hPipe, resposta, TAM * sizeof(TCHAR), &bytesRead, NULL)) {
		_tprintf_s(_T("Erro ao receber resposta do servidor. C�digo de erro: %d\n"), GetLastError());
		CloseHandle(hPipe);
		return;
	}

	_tprintf_s(_T("%s\n"), resposta);


}


DWORD WINAPI RecebeMsg(LPVOID data) {
	HANDLE hPipe = (HANDLE)data;
	BOOL res;
	DWORD lidos, escritos;
	OVERLAPPED ovLeitura;
	TCHAR buf[TAM];
	HANDLE hEvLeitura = CreateEvent(NULL, TRUE, FALSE, NULL);
	if (hEvLeitura == NULL) {
		_tprintf_s(_T("Erro ao criar evento. C�digo de erro: %d\n"), GetLastError());
		return 1;
	}
	while (1) {
		ZeroMemory(&ovLeitura, sizeof(OVERLAPPED));
		ResetEvent(ovLeitura.hEvent);
		ovLeitura.hEvent = hEvLeitura;
		res = ReadFile(hPipe, buf, TAM, &lidos, &ovLeitura);
		if (!res) {
			if (GetLastError() == ERROR_IO_PENDING) {
				_tprintf_s(_T("Aguardando leitura...\n"));
				WaitForSingleObject(hEvLeitura, INFINITE);
				GetOverlappedResult(hPipe, &ovLeitura, &lidos, FALSE);

			}
			else {
				_tprintf_s(_T("Erro na escrita. C�digo de erro: %d\n"), GetLastError());
				break;
			}
		}
		else {
			_tprintf_s(_T("Mensagem recebida: %s"), buf);
		}

		
	}
	CloseHandle(hEvLeitura);
	return 0;
}


DWORD WINAPI LerComandos(LPVOID lpParam) {
	HANDLE hPipe = (HANDLE)lpParam;
	OVERLAPPED ov, ovLeitura, ovEscrita;
	TCHAR cmd[TAM];
	DWORD bytesWrite;
	BOOL res, resEscrita;
	DWORD lidos, escritos;
	TCHAR buf[TAM];

	
	HANDLE hEvEscrita = CreateEvent(NULL, TRUE, FALSE, NULL);
	if (hEvEscrita == NULL) {
		_tprintf_s(_T("Erro ao criar evento de escrita. C�digo de erro: %d\n"), GetLastError());
		return 1;
	}

	do {

		// Comando de entrada do usu�rio
		_tprintf_s(_T("Comando: "));
		_fgetts(cmd, TAM, stdin);
		cmd[_tcslen(cmd) - 1] = '\0'; // Remover o caractere de nova linha

		// Extrair a primeira palavra do comando
		TCHAR primeiroComando[TAM];
		_stscanf_s(cmd, _T("%s"), primeiroComando, TAM);

		// Opera��o ass�ncrona de escrita no pipe
		ZeroMemory(&ovEscrita, sizeof(OVERLAPPED));
		ovEscrita.hEvent = hEvEscrita;
		resEscrita = WriteFile(hPipe, primeiroComando, (_tcslen(primeiroComando) + 1) * sizeof(TCHAR), &bytesWrite, &ovEscrita);
		if (!resEscrita) {
			if (GetLastError() == ERROR_IO_PENDING) {
				_tprintf_s(_T("Aguardando escrita...\n"));
				WaitForSingleObject(hEvEscrita, INFINITE);
				GetOverlappedResult(hPipe, &ovEscrita, &escritos, FALSE);
			}
			else {
				_tprintf_s(_T("Erro na escrita. C�digo de erro: %d\n"), GetLastError());
				break;
			}
		}
		else {
			verificacomando(cmd, hPipe);
		}

		// Limpar buffer de entrada para evitar problemas
		fflush(stdin);
	} while (TRUE);

	//CloseHandle(hEvLeitura);
	CloseHandle(hEvEscrita);
	

	return 0;
}



int _tmain(int argc, LPTSTR argv[]) {
	HANDLE hPipe;
	HKEY hkey;
	LSTATUS res;
	DWORD estado, num_clientes;
	TCHAR chave_nome[TAM], par_nome[TAM], par_valor[TAM], buf[TAM];
	BOOL continuar = TRUE;;
	DWORD bytesWrite,bytesRead, num_tentativas = 0;


	#ifdef UNICODE
		_setmode(_fileno(stdin), _O_WTEXT);
		_setmode(_fileno(stdout), _O_WTEXT);
	#endif

	while (num_tentativas < MAX_TENTATIVAS) {
		hPipe = CreateFile(PIPE_NAME, GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL | FILE_FLAG_OVERLAPPED, NULL);
		if (hPipe != INVALID_HANDLE_VALUE)
			break;
		else {
			num_tentativas++;
			_tprintf_s(_T("Pipe ocupado. Tentando novamente (%d/%d)...\n"), num_tentativas,MAX_TENTATIVAS);
			WaitNamedPipe(PIPE_NAME, NMPWAIT_USE_DEFAULT_WAIT); // Esperar at� 10 segundos pelo pipe
		}

	}
	if (hPipe == INVALID_HANDLE_VALUE) {
		_tprintf_s(_T("N�mero m�ximo de tentativas excedido. Saindo do programa.\n"));
		return 1; // Sair do programa
	}

	
	//HANDLE hEventoSair = OpenEvent(EVENT_ALL_ACCESS, FALSE, EVENTO_SAIR);
	//if (hEventoSair == NULL) {
	//	_tprintf_s(_T("Erro ao abrir evento\n"));
	//	return 1;
	//}
	
	
	
	HANDLE hThreadComandos = CreateThread(NULL, 0, LerComandos, hPipe, 0, NULL);
	if (hThreadComandos == NULL) {
		_tprintf_s(_T("Erro ao criar a thread. C�digo de erro: %d\n"), GetLastError());
		CloseHandle(hPipe);
		return 1;
	}

	//HANDLE hThread = CreateThread(NULL, 0, RecebeMsg, (LPVOID)hPipe, 0, NULL);

	// Aguarda a thread terminar (n�o deve acontecer neste caso)
	WaitForSingleObject(hThreadComandos, INFINITE);
	//WaitForSingleObject(hThread, INFINITE);

	// Fecha os identificadores das threads e libera recursos
	CloseHandle(hThreadComandos);

	
	//CloseHandle(hThread);
	
	//CloseHandle(hEventoSair);
	CloseHandle(hPipe);
	return 0;


}