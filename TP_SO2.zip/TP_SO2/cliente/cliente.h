#pragma once

#include "../bolsa/utils.h"



//  FUN��ES DE COMANDOS

void comandos_cmd();
void login(TCHAR* input, HANDLE hPipe);
void listaEmpresas(TCHAR* input,HANDLE hPipe);
void BuyAcoes(TCHAR* input,HANDLE hPipe);
void SellAcoes(TCHAR* input,HANDLE hPipe);
void ConsultaSaldo(TCHAR* input,HANDLE hPipe);
void Sair();
void consultaCarteira(TCHAR* input,HANDLE hPipe);
void vendasPendentes(TCHAR* input, HANDLE hPipe);

static const struct comando comandos[] = {
    {_T("ajuda"),_T("Mostra a lista de comandos permitidos"),&comandos_cmd},
    {_T("login"),_T("Lista todas as empresas existentes na bolsa"),&login},
    {_T("listc"),_T("Lista todas as empresas existentes na bolsa"),&listaEmpresas},
    {_T("buy"),_T("Comprar a��es de uma empresa"),&BuyAcoes},
    {_T("sell"),_T("Vender a��es de uma empresa"),&SellAcoes},
    {_T("balance"),_T("Consultar saldo"),&ConsultaSaldo},
    {_T("sair"),_T("Sair do sistema"),&Sair},
    {_T("carteira"),_T("Consultar carteira a��es"),&consultaCarteira},
    {_T("vendas"),_T("Vendas pendentes"),&vendasPendentes}
};
